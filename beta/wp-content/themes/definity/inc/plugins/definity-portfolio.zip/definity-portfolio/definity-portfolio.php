<?php 
/**
 * Plugin Name: Definity Portfolio
 * Plugin URI: http://themes.89elements.com/definity/
 * Text Domain: definity-portfolio
 * Domain Path: /languages/
 * Description: This plugins comes as a part of Deifnity theme for portfolio functionality.
 * Author: 89elements
 * Version: 1.0.0
 * Author URI: http://89elements.com/
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}


/* --------------------------------------------------
	Plugin Constants & Globals
-------------------------------------------------- */

define( 'DEFINITY_PORTFOLIO', plugin_dir_path( __FILE__ ));
define( 'DEFINITY_PORTFOLIO_URI', plugin_dir_url( __FILE__ ));


/* --------------------------------------------------
	Load Textdomain
-------------------------------------------------- */

function definity_portfolio_load_plugin_textdomain() {
    load_plugin_textdomain( 'definity-portfolio', false, dirname( plugin_basename(__FILE__) ) . '/languages/' );
}
add_action( 'plugins_loaded', 'definity_portfolio_load_plugin_textdomain' );


/* --------------------------------------------------
	Portfoio - Custom Post Type
-------------------------------------------------- */

function definity_custom_post_types() {

	$labels = array(
		'name'               => __( 'Portoflio', 'definity-portfolio' ),
		'singular_name'      => __( 'Portfoio Item', 'definity-portfolio' ),
		'add_new'            => _x( 'Add New Portfoio Item', 'definity-portfolio', 'definity-portfolio' ),
		'add_new_item'       => __( 'Add New Portfoio Item', 'definity-portfolio' ),
		'edit_item'          => __( 'Edit Portfoio Item', 'definity-portfolio' ),
		'new_item'           => __( 'New Portfoio Item', 'definity-portfolio' ),
		'view_item'          => __( 'View Portfoio Item', 'definity-portfolio' ),
		'search_items'       => __( 'Search Portoflio', 'definity-portfolio' ),
		'not_found'          => __( 'No portoflio items found', 'definity-portfolio' ),
		'not_found_in_trash' => __( 'No portoflio items found in Trash', 'definity-portfolio' ),
		'parent_item_colon'  => __( 'Parent Portfoio Item:', 'definity-portfolio' ),
		'menu_name'          => __( 'Portoflio', 'definity-portfolio' ),
	);

	$args = array(
		'labels'              => $labels,
		'description'         => 'description',
		'taxonomies'          => array( 'filters', 'categories' ),
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => null,
		'menu_icon'           => 'dashicons-images-alt2',
		'show_in_nav_menus'   => true,
		'publicly_queryable'  => true,
		'exclude_from_search' => true,
		'query_var'           => true,
		'can_export'          => true,
		'rewrite'             => array( 'slug' => 'portfolio' ),
		'capability_type'     => 'page',
		'hierarchical'        => true,
		'has_archive'         => true,
		'supports'            => array(
			'title',
			'editor',
			// 'author',
			'thumbnail',
			// 'excerpt',
			// 'custom-fields',
			// 'trackbacks',
			// 'comments',
			'revisions',
			'page-attributes',
			// 'post-formats',
		),
	);

	register_post_type( 'portfolio', $args );
}

add_action( 'init', 'definity_custom_post_types' );


function definity_portfolio_rewrite_flush() {
    definity_custom_post_types();

    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'definity_portfolio_rewrite_flush' );


/* --------------------------------------------------
	Portfolio - Custom Taxonomy
-------------------------------------------------- */

function definity_custom_taxonomies() {


	/* ---- Custom taxonomy - Filters ---- */

	$labels_filters = array(
		'name'                  => _x( 'Filters', 'Taxonomy filters', 'definity-portfolio' ),
		'singular_name'         => _x( 'Filter', 'Taxonomy filter', 'definity-portfolio' ),
		'search_items'          => __( 'Search Filters', 'definity-portfolio' ),
		'popular_items'         => __( 'Popular Filters', 'definity-portfolio' ),
		'all_items'             => __( 'All Filters', 'definity-portfolio' ),
		'parent_item'           => __( 'Parent Filter', 'definity-portfolio' ),
		'parent_item_colon'     => __( 'Parent Filter', 'definity-portfolio' ),
		'edit_item'             => __( 'Edit Filter', 'definity-portfolio' ),
		'update_item'           => __( 'Update Filter', 'definity-portfolio' ),
		'add_new_item'          => __( 'Add New Filter', 'definity-portfolio' ),
		'new_item_name'         => __( 'New Filter Name', 'definity-portfolio' ),
		'add_or_remove_items'   => __( 'Add or remove filters', 'definity-portfolio' ),
		'choose_from_most_used' => __( 'Choose from most used filters', 'definity-portfolio' ),
		'menu_name'             => __( 'Filters', 'definity-portfolio' ),
	);

	$args_filters = array(
		'labels'            => $labels_filters,
		'public'            => true,
		'show_in_nav_menus' => true,
		'show_admin_column' => true,
		'hierarchical'      => false,
		'show_tagcloud'     => true,
		'show_ui'           => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'filters' ),
		'query_var'         => true,
		// 'capabilities'      => array(),
	);

	register_taxonomy( 'filters', array( 'portfolio' ), $args_filters );


	/* ---- Custom taxonomy - Categories ---- */

	$labels_cat = array(
		'name'                  => _x( 'Categories', 'categories', 'definity-portfolio' ),
		'singular_name'         => _x( 'Category', 'category', 'definity-portfolio' ),
		'search_items'          => __( 'Search Categories', 'definity-portfolio' ),
		'popular_items'         => __( 'Popular Categories', 'definity-portfolio' ),
		'all_items'             => __( 'All Categories', 'definity-portfolio' ),
		'parent_item'           => __( 'Parent Category', 'definity-portfolio' ),
		'parent_item_colon'     => __( 'Parent Category', 'definity-portfolio' ),
		'edit_item'             => __( 'Edit Category', 'definity-portfolio' ),
		'update_item'           => __( 'Update Category', 'definity-portfolio' ),
		'add_new_item'          => __( 'Add New Category', 'definity-portfolio' ),
		'new_item_name'         => __( 'New Category Name', 'definity-portfolio' ),
		'add_or_remove_items'   => __( 'Add or remove Categories', 'definity-portfolio' ),
		'choose_from_most_used' => __( 'Choose from most used Categories', 'definity-portfolio' ),
		'menu_name'             => __( 'Category', 'definity-portfolio' ),
	);
	
	$args_cat = array(
		'labels'            => $labels_cat,
		'public'            => true,
		'show_in_nav_menus' => true,
		'show_admin_column' => true,
		'hierarchical'      => true,
		'show_tagcloud'     => false,
		'show_ui'           => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'categories' ),
		'query_var'         => true,
		// 'capabilities'      => array(),
	);
	
	register_taxonomy( 'categories', array( 'portfolio' ), $args_cat );
}

add_action( 'init', 'definity_custom_taxonomies' );