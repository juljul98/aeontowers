/* --------------------------------------------------
	Dropcap
-------------------------------------------------- */
    
(function() {
    tinymce.PluginManager.add('d_dropcap', function( editor) {
        editor.addButton( 'd_dropcap', {
            title : 'Add dropcap',
            icon: 'icon-dropcap',
            onclick: function() {
                editor.selection.setContent('[d_dropcap]' + editor.selection.getContent() + '[/d_dropcap]');  
            }
        });
    });
})();