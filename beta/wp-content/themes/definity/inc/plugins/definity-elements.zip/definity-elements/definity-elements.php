<?php 
/**
 * Plugin Name: Definity Elements
 * Plugin URI: http://themes.89elements.com/definity/
 * Text Domain: definity-elements
 * Domain Path: /languages/
 * Description: This plugins comes as a part of Deifnity theme for extended functionality. 
 * Author: 89elements
 * Version: 2.0
 * Author URI: http://89elements.com/
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}


/* --------------------------------------------------
	Plugin Constants & Globals
-------------------------------------------------- */

define( 'DEFINITY_ELEMENTS', plugin_dir_path( __FILE__ ));
define( 'DEFINITY_ELEMENTS_URI', plugin_dir_url( __FILE__ ));


/* --------------------------------------------------
	Load Textdomain
-------------------------------------------------- */

function definity_elements_load_plugin_textdomain() {
    load_plugin_textdomain( 'definity-elements', false, dirname( plugin_basename(__FILE__) ) . '/languages/' );
}
add_action( 'plugins_loaded', 'definity_elements_load_plugin_textdomain' );


/* --------------------------------------------------
	Theme Options
-------------------------------------------------- */

if ( ! class_exists( 'ReduxFramework' ) && file_exists( DEFINITY_ELEMENTS . '/options/ReduxCore/framework.php' ) ) {
   require_once('options/ReduxCore/framework.php' );
}
// Theme Options Config
if ( ! isset( $redux_demo ) && file_exists( DEFINITY_ELEMENTS . '/options/definity-options.php' ) ) {
   require_once('options/definity-options.php' );
}


/* --------------------------------------------------
	Requires/Includes
-------------------------------------------------- */

require_once('shortcodes/definity-shortcodes.php' );