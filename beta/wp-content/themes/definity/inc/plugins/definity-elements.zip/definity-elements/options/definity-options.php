<?php
    /**
     * ReduxFramework Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }


    // This is your option name where all the Redux data is stored.
    $opt_name = "definity_options";

    // This line is only for altering the demo. Can be easily removed.
    // $opt_name = apply_filters( 'redux_demo/opt_name', $opt_name );

    /*
     *
     * --> Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
     *
     */

    $sampleHTML = '';
    if ( file_exists( dirname( __FILE__ ) . '/info-html.html' ) ) {
        Redux_Functions::initWpFilesystem();

        global $wp_filesystem;

        $sampleHTML = $wp_filesystem->get_contents( dirname( __FILE__ ) . '/info-html.html' );
    }

    // Background Patterns Reader
    $sample_patterns_path = ReduxFramework::$_dir . '../sample/patterns/';
    $sample_patterns_url  = ReduxFramework::$_url . '../sample/patterns/';
    $sample_patterns      = array();
    
    if ( is_dir( $sample_patterns_path ) ) {

        if ( $sample_patterns_dir = opendir( $sample_patterns_path ) ) {
            $sample_patterns = array();

            while ( ( $sample_patterns_file = readdir( $sample_patterns_dir ) ) !== false ) {

                if ( stristr( $sample_patterns_file, '.png' ) !== false || stristr( $sample_patterns_file, '.jpg' ) !== false ) {
                    $name              = explode( '.', $sample_patterns_file );
                    $name              = str_replace( '.' . end( $name ), '', $sample_patterns_file );
                    $sample_patterns[] = array(
                        'alt' => $name,
                        'img' => $sample_patterns_url . $sample_patterns_file
                    );
                }
            }
        }
    }

    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // Disable tracking
        'disable_tracking' => true,
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => esc_html__( 'Theme Options', 'definity-elements' ),
        'page_title'           => esc_html__( 'Theme Options', 'definity-elements' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => 'AIzaSyDIjnvRq4Q0giARp0DUB2emTT2cxzUMbs4',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => false,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => false,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-portfolio',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => false,
        'forced_dev_mode_off'  => false,
        // Show the time the page took to load, etc
        'update_notice'        => false,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => false,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => null,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '',
        // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
        'use_cdn'              => true,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.
        'system_info'          => false,

        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'red',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );

    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */



    /*
     *
     * ---> START SECTIONS
     *
     */

    /* --------------------------------------------------
        General Settings
    -------------------------------------------------- */
            
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'General Settings', 'definity-elements' ),
        'id'               => 'general_options',
        'customizer_width' => '400px',
        'icon'             => 'el el-home',
        'desc'       => esc_html__( 'For full documentation on this field, please use the help file that comes with the theme downloaded.', 'definity-elements' ),
        'fields'     => array(
            array(
                'id'       => 'header_nav_logo',
                'type'     => 'media',
                'url'      => true,
                'title'    => 'Upload Logo',
                'default'  => array(
                    'url' => get_template_directory_uri() . '/assets/images/logo.png'
                ),
            ),
            array(
                'id'       => 'header_favicon',
                'type'     => 'media',
                'url'      => true,
                'title'    => 'Upload Favicon',
                'subtitle' => 'Favicon is the small icon that shows in the browser tabs, you can upload your personal one from here.',
                'desc' => 'Use this only for WordPress versions before v4.3, else from the WP admin bar navigate Customize > Site Identity > Site Icon > Select/Change Image.',
                'default'  => array(
                    'url' => get_template_directory_uri() . '/favicon.ico'
                ),
            ),
            array(
                'id'       => 'd_perloader',
                'type'     => 'switch',
                'title'    => 'Loading Screen',
                'subtitle' => 'Display loading screen while the website loads the elements.<br/><br/><strong>Tip:</strong> Recommended for media heavy websites.',
                'default'  => true,
            ),
        )
    ) );


    /* --------------------------------------------------
        Header
    -------------------------------------------------- */
    
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Header', 'definity-elements' ),
        'id'         => 'header_options',
        'icon'       => 'el el-compass-alt',
        'desc'       => esc_html__( 'For full documentation on this field, please use the help file that comes with the theme downloaded.', 'definity-elements' ),
        'fields'     => array(
                array(
                    'id'       => 'nav_layout',
                    'type'     => 'image_select',
                    'title'    => 'Choose Navigation Menu - Style',
                    'options'  => array(
                        'nav-inline-left'       => array( 'alt' => 'Navbar Menu - Inline Left', 'img' => DEFINITY_ELEMENTS_URI . 'options/assets/img/nav-inline-left.png' ),
                        'nav-inline-right'      => array( 'alt' => 'Navbar Menu - Inline Right', 'img' => DEFINITY_ELEMENTS_URI . 'options/assets/img/nav-inline-right.png' ),
                        'nav-stacked-left'      => array( 'alt' => 'Navbar Menu - Stacked Left', 'img' => DEFINITY_ELEMENTS_URI . 'options/assets/img/nav-stacked-left.png' ),
                        'nav-stacked-center'    => array( 'alt' => 'Navbar Menu - Stacked Center', 'img' => DEFINITY_ELEMENTS_URI . 'options/assets/img/nav-stacked-center.png' ),
                        'nav-stacked-right'     => array( 'alt' => 'Navbar Menu - Stacked Right', 'img' => DEFINITY_ELEMENTS_URI . 'options/assets/img/nav-stacked-right.png' ),
                        'nav-neue'              => array( 'alt' => 'Navbar Menu - Nav Neue', 'img' => DEFINITY_ELEMENTS_URI . 'options/assets/img/nav-neue.png' ),
                        'nav-full-screen'       => array( 'alt' => 'Navbar Menu - Full Screen', 'img' => DEFINITY_ELEMENTS_URI . 'options/assets/img/nav-full-screen.png' ),
                        ),
                    'default'  => 'nav-inline-left'
                ),
                array(
                    'id'       => 'logo_full_screen',
                    'type'     => 'media',
                    'url'      => true,
                    'title'    => 'Upload Big Logo',
                    'required' => array( 'nav_layout', '=', array( 'nav-full-screen' ) ),
                    'default'  => array(
                        'url' => get_template_directory_uri() . '/assets/images/logo-2-large.png'
                    ),
                ),
                array(
                    'id'       => 'navbar_float_on',
                    'type'     => 'switch',
                    'title'    => 'Navbar Float',
                    'subtitle' => 'Creative way to display the navbar, works only with Navbar Neue (6th option).',
                    'default'  => false,
                    'required' => array( 'nav_layout', '=', array( 'nav-neue' ) )
                ),
                array(
                    'id'       => 'navbar_grid_on',
                    'type'     => 'switch',
                    'title'    => 'Navbar Menu Width',
                    'subtitle' => 'Chose between - navbar menu respecting the grid of the page content, or strech the menu to the ends of the screen.',
                    'on'       => 'Grid',
                    'off'      => 'Strech',
                    'default'  => true,
                    'required' => array( 'nav_layout', '!=', array( 'nav-neue' ) )
                ),
                array(
                    'id'       => 'nav_stacked_social',
                    'type'     => 'switch',
                    'title'    => 'Show Social Icons In The Menu',
                    'subtitle' => 'Show social icons/links in the navigation menu - you can edit the social links from the tab "Social Links". ',
                    'on'       => 'Show',
                    'off'      => 'Hide',
                    'default'  => true,
                    'required' => array( 'nav_layout', '=', array( 'nav-stacked-left', 'nav-stacked-right' ) )
                ),
                array(
                    'id'       => 'nav_extend_show',
                    'type'     => 'switch',
                    'title'    => 'Show Extended Menu',
                    'subtitle' => 'Show extended navbar menu, before(top) the main menu.',
                    'on'       => 'Show',
                    'off'      => 'Hide',
                    'default'  => false,
                ),
                array(
                    'id'       => 'navbar_search_on',
                    'type'     => 'switch',
                    'title'    => 'Search Button',
                    'subtitle' => 'Display search button and serach form in the navigation menu.',
                    'on'       => 'Show',
                    'off'      => 'Hide',
                    'default'  => true,
                ),
                array(
                    'id'       => 'nav_sidepanel_persist',
                    'type'     => 'switch',
                    'title'    => 'Mobile Menu Button - Permanent Visibilty',
                    'subtitle' => 'Hide the menu items and display the mobile menu button <strong>permanently</strong><br/> (even on desktop screens).',
                    'default'  => false,
                    'required' => array( array( 'nav_layout', '=', array( 'nav-inline-left', 'nav-inline-right', 'nav-neue' ) ) )
                ),
                array(
                    'id'       => 'nav_dropdown_event',
                    'type'     => 'switch',
                    'title'    => 'Show Dropdown Menu on',
                    'subtitle' => 'Chose between showing the dropdown menu on "click" or "mouse hover".',
                    'on'       => 'Click',
                    'off'      => 'Hover',
                    'default'  => false,
                    'required' => array( array( 'nav_layout', '!=', array( 'nav-full-screen' ) ) )
                ),
                array(
                    'id'       => 'nav_trans_on',
                    'type'     => 'switch',
                    'title'    => 'Transparent Navigation',
                    'subtitle' => 'The navigation menu background will be transparent when is at the top of the page.',
                    'default'  => true,
                    'required' => array( array( 'nav_layout', '=', array( 'nav-inline-left', 'nav-inline-right', 'nav-full-screen' ) ) )
                ),
                array(
                    'id'       => 'nav_trans_options',
                    'type'     => 'switch',
                    'title'    => 'Transparent Nav. Options',
                    'subtitle' => 'Enable transparent nav. only on front page, or enbale it on all pages.',
                    'on'       => 'Front Page',
                    'off'      => 'All Pages',
                    'default'  => true,
                    'required' => array( array( 'nav_trans_on', '=', array( true ) ) )
                ),
                array(
                    'id'       => 'sticky_nav_on',
                    'type'     => 'switch',
                    'title'    => 'Enable Sticky Navigation',
                    'subtitle' => 'The menu navbar will stay at the top of the browser window as you scroll.',
                    'default'  => false,
                    'required' => array( array( 'nav_layout', '=', array( 'nav-inline-left', 'nav-inline-right', 'nav-neue', 'nav-full-screen' ) ) )
                ),
                array(
                    'id'       => 'onepage_nav_on',
                    'type'     => 'switch',
                    'title'    => 'One Page Navigation',
                    'subtitle' => 'Menu items will highlight as you scroll pass their section on the page, and clicking on the menu items will scroll the page to that section.',
                    'desc'     => 'Be sure to check the help file (documentation) in order to setup correctly the one page navigation.',
                    'default'  => false,
                    'required' => array( array( 'sticky_nav_on', '=', true ) )
                ),
                array(
                    'id'       => 'mobile_menu_footer_heading',
                    'type'     => 'text',
                    'title'    => 'Mobile Menu Footer - Heading',
                    'default'  => 'Defintiy',
                ),
                array(
                    'id'       => 'mobile_menu_footer_subheading',
                    'type'     => 'text',
                    'title'    => 'Mobile Menu Footer - Subheading',
                    'default'  => 'Multi-Purpose WordPress Theme',
                ),
            )
        ) 
    );


    /* --------------------------------------------------
        Footer
    -------------------------------------------------- */
    
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Footer', 'definity-elements' ),
        'id'         => 'footer_options',
        'icon'       => 'el el-asterisk',
        'desc'       => esc_html__( 'For full documentation on this field, please use the help file that comes with the theme downloaded.', 'definity-elements' ),
        'fields'     => array(
                array(
                    'id'       => 'footer_layout',
                    'type'     => 'select',
                    'title'    => 'Choose Footer Layout',
                    'options'  => array(
                        'footer-widgets'   => 'Classic Widgets Footer',
                        'footer-litle'     => 'Litle Footer (social icons only)',
                        ),
                    'default'  => 'footer-widgets'
                ),
                array(
                    'id'       => 'footer_copyright_txt',
                    'type'     => 'text',
                    'title'    => 'Copyright Text',
                    'default'  => '&copy; 2017 All Rights Reserved. Definity - Made by 89elements',
                ),
                array(
                    'id'       => 'footer_totop_on',
                    'type'     => 'switch',
                    'title'    => 'Show/Hide scroll to the top button',
                    'default'  => true,
                ),
                array(
                    'id'       => 'footer_totop_txt',
                    'type'     => 'text',
                    'title'    => 'Scroll to the top - button text',
                    'default'  => 'To the top',
                    'required' => array( 'footer_totop_on', '=', true )
                ),
                array(
                    'id'   => 'footer_sep_1',
                    'type' => 'divide',
                ),
                array(
                    'id'             => 'footer_content_spacing',
                    'type'           => 'spacing',
                    'title'          => 'Content and Footer Spacing',
                    'subtitle'       => 'Change the spacing between the content and the footer.',
                    'desc'           => 'Without units (px) sign.',
                    'left'           => false,
                    'right'          => false,
                    'bottom'         => false,
                    'mode'           => 'margin',
                    'units'          => 'px',
                    'units_extended' => 'false',
                    'output'         => array( 'margin' => '.footer-widgets, .footer-litle' ),
                ),
                array(
                    'id'             => 'footer_widgets_padding',
                    'type'           => 'spacing',
                    'title'          => 'Footer Widgets Top & Bottom Spacing',
                    'subtitle'       => 'Change the top and bottom spacing of <br/>the footer <br/><br/>Default <br/>top 160px, <br/>bottom: 0',
                    'desc'           => 'Without units (px) sign.',
                    'left'           => false,
                    'right'          => false,
                    'mode'           => 'padding',
                    'units'          => 'px',
                    'units_extended' => 'false',
                    'output'         => array( '.footer-widgets .footer-section' ),
                    'required'       => array( 'footer_layout', '=', array( 'footer-widgets' ) )
                ),
            )
        ) 
    );


    /* --------------------------------------------------
        Blog
    -------------------------------------------------- */

    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Blog Settings', 'definity-elements' ),
        'id'               => 'blog_settings',
        'icon'             => 'el el-file-edit',
    ) );
    
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Blog Posts Page', 'definity-elements' ),
        'id'               => 'blog_page',
        'subsection'       => true,
        'desc'       => esc_html__( 'For full documentation on this field, please use the help file that comes with the theme downloaded.', 'definity-elements' ),
        'fields'     => array(
            array(
                'id'       => 'd_blog_layout',
                'type'     => 'image_select',
                'title'    => 'Choose Blog Layout',
                'subtitle' => 'Choose a layout for the blog page.',
                'options'   => array(
                    'classic-sb-right'  => array( 'alt' => 'Classic Layout - Sidebar Right', 'img' => DEFINITY_ELEMENTS_URI . 'options/assets/img/classic-sb-right.png' ),
                    'classic-sb-left'  =>  array( 'alt' => 'Classic Layout - Sidebar Left (1/1)', 'img' => DEFINITY_ELEMENTS_URI . 'options/assets/img/classic-sb-left.png' ),
                    'no-sb'            =>  array( 'alt' => 'Grid Layout - Optional Sidebar (1/3)', 'img'    => DEFINITY_ELEMENTS_URI . 'options/assets/img/gird-3col-optional-sb.png' ),
                    'columns-sb-right' =>  array( 'alt' => 'Grid Layout - Sidebar Right (1/2)', 'img'   => DEFINITY_ELEMENTS_URI . 'options/assets/img/gird-sb-right.png' ),
                    'columns-sb-left'  =>  array( 'alt' => 'Grid Layout - Sidebar Left (1/2)', 'img'    => DEFINITY_ELEMENTS_URI . 'options/assets/img/gird-sb-left.png' ),
                    'masonry-no-sb'    =>  array( 'alt' => 'Masonry Layout - Optional Sidebar (1/3)', 'img' => DEFINITY_ELEMENTS_URI . 'options/assets/img/masonry-3col-optional-sb.png' ),
                    'masonry-sb-right' =>  array( 'alt' => 'Masonry Layout - Right Sidebar (1/2)', 'img'    => DEFINITY_ELEMENTS_URI . 'options/assets/img/masonry-sb-right.png' ),
                    'masonry-sb-left'  =>  array( 'alt' => 'Masonry Layout - Left Sidebar (1/2)', 'img' => DEFINITY_ELEMENTS_URI . 'options/assets/img/masonry-sb-left.png' ),
                ),
                'default'  => 'classic-sb-right'
                ),
            array(
                'id'       => 'd_show_sb',
                'type'     => 'switch',
                'title'    => 'Show/Hide Sidebar',
                'default'  => true,
                'required' => array( 'd_blog_layout', '=', array( 'no-sb', 'masonry-no-sb' ) )
                ),
            array(
                'id'       => 'd_post_author',
                'type'     => 'switch',
                'title'    => 'Post Author',
                'subtitle' => 'Show post author on <b>blog posts</b> page, only available on classic blog layouts.',
                'default'  => false,
                'required' => array( 'd_blog_layout', '=', array( 'classic-sb-right', 'classic-sb-left' ) )
                ),
            array(
                'id'       => 'd_post_comments',
                'type'     => 'switch',
                'title'    => 'Comments Number',
                'subtitle' => 'Show the number of comments for each post on the <b>blog posts</b> page, if there is at least 1 comment.',
                'default'  => true,
                ),
            array(
                'id'       => 'd_post_date',
                'type'     => 'switch',
                'title'    => 'Post Date',
                'subtitle' => 'Show the date of the post on the <b>blog posts</b> page. To change the date <b>format</b> go to: <b>Settings/General</b> from the WP Dashboard sidemenu.',
                'default'  => true,
                ),
            array(
                'id'       => 'd_post_sticky',
                'type'     => 'switch',
                'title'    => 'Sticky Post Mark',
                'subtitle' => 'Mark the sticky posts with a <b>star</b>.',
                'default'  => true,
                ),
            array(
                'id'       => 'd_post_read_more_btn',
                'type'     => 'text',
                'title'    => 'Read More Button',
                'subtitle' => 'Change the text of the Read More button.',
                'default'  => 'Read More'
            ),
            )
        ) );


     /* ---- Single Post ---- */
     Redux::setSection( $opt_name, array(
         'title'      => esc_html__( 'Single Post Page', 'definity-elements' ),
         'id'         => 'single_post',
         'subsection' => true,
         'desc'       => esc_html__( 'For full documentation on this field, please use the help file that comes with the theme downloaded.', 'definity-elements' ),
         'fields'     => array(
            array(
                'id'       => 'single_post_layout',
                'type'     => 'select',
                'title'    => 'Sidebar Position',
                'subtitle' => 'Choose a layout for the single post page.',
                'options'  => array(
                    'sb-right' => 'Sidebar Right',
                    'sb-left'  => 'Sidebar Left',
                    'no-sb'    => 'No Sidebar',
                ),
                'default'  => 'sb-right'
            ),
            array(
                'id'       => 'cat_option',
                'type'     => 'switch',
                'title'    => 'Categories',
                'subtitle' => 'Show the post categories bellow the post.',
                'default'  => true,
            ),
             array(
                 'id'       => 'tags_option',
                 'type'     => 'switch',
                 'title'    => 'Tags',
                 'subtitle' => 'Show the post tags bellow the post.',
                 'default'  => true,
             ),
             array(
                 'id'       => 'author_bio',
                 'type'     => 'switch',
                 'title'    => 'Author Biography',
                 'subtitle' => 'Display the author bio with image and description about the author.<br/>Bio can be edited from WP Sidemenu: <b>Users/All Users/Edit</b><p><b>*Note:</b> The biography will show only if the description filed is <b>not</b> empty.</p>',
                 'default'  => true,
             ),
             array(
                 'id'       => 'comments_single',
                 'type'     => 'switch',
                 'title'    => 'Comments',
                 'subtitle' => 'Display the default WordPress comment form, where users can post comments, on your posts.',
                 'default'  => true,
             ),
             array(
                 'id'       => 'single_posts_nav',
                 'type'     => 'switch',
                 'title'    => 'Post Navigation',
                 'subtitle' => 'Display prev and next links to your posts.',
                 'default'  => true,
             ),
            array(
                'id'       => 'social_links_single_post_check',
                'type'     => 'switch',
                'title'    => 'Social Links',
                'subtitle' => 'Display social links/buttons for sharing the post.',
                'default'  => true,
            )  
        )          
     ) );


     /* ---- Blog Page Title ---- */
     Redux::setSection( $opt_name, array(
         'title'      => esc_html__( 'Blog Page Title', 'definity-elements' ),
         'id'         => 'blog_page_title',
         'subsection' => true,
         'desc'       => esc_html__( 'For full documentation on this field, please use the help file that comes with the theme downloaded.', 'definity-elements' ),
         'fields'     => array(
            array(
                'id'       => 'bpt_size',
                'type'     => 'select',
                'title'    => 'Page Title Size',
                'subtitle' => 'Choose page title size.',
                'options'  => array(
                    'pt-large'  => 'Large',
                    'pt-medium' => 'Medium',
                    'pt-small'  => 'Small',
                ),
                'default'  => 'pt-medium'
            ),
            array(
                'id'       => 'bpt_bg_color',
                'type'     => 'color_rgba',
                'title'    => 'Background Color',
                'subtitle' => 'Pick a page title background color <br/>(default: #f4f4f4).',
                'description' => 'This can also be used as a transparent overlay layer over the bg image if you use one.',
                'output'    => array( 'background-color' => '.bpt-bg:before' ),
                'default'   => '#f4f4f4',
            ),
            array(
                'id'       => 'bpt_bg_img',
                'type'     => 'background',
                'url'      => true,
                'title'    => 'Background Image',
                'subtitle' => 'Upload background image for the blog page title.',
                'required' => array( 'bpt_size', '=', array( 'pt-large', 'pt-medium' ) ),
                'output'   => array( 'background' => '.bpt-bg' ),
            ),
            array(
                'id'             => 'bpt_content_spacing',
                'type'           => 'spacing',
                'title'          => 'Page Title and Content Spacing',
                'subtitle'       => 'Default <br/>bottom 160px',
                'desc'           => 'Without units (px) sign.',
                'left'           => false,
                'right'          => false,
                'top'            => false,
                'mode'           => 'margin',
                'units'          => 'px',
                'units_extended' => 'false',
                'output'         => array( 'header.page-title.bpt' ),
            ),
            array(
                'id'       => 'bpt_parallax_on',
                'type'     => 'switch',
                'title'    => 'Parallax Effect',
                'subtitle' => 'Enable parallax effect for the page title.',
                'required' => array( 'bpt_size', '=', array( 'pt-large', 'pt-medium' ) ),
                'default'  => true,
            ),
            array(
                'id'   => 'bpt_sep_1',
                'type' => 'divide'
            ),
            array(
                'id'       => 'bpt_breadcrumbs_on',
                'type'     => 'switch',
                'title'    => 'Breadcrumbs',
                'subtitle' => 'Show breadcrumbs in the page title <br/>e.g. Home / Blog / Blog Post Name',
                'default'  => true,
            ),
            array(
                'id'       => 'bpt_breadcrumbs_color',
                'type'     => 'color',
                'title'    => 'Breadcrumbs Link Color',
                'subtitle' => 'Change the breadcrumbs link color <br/>(default: #777).',
                'default'  => '#777777',
                'output'   => array( 'color' => '.page-title .breadcrumb li a' ),
                'required' => array( 'bpt_breadcrumbs_on', '=', true ),
            ),
            array(
                'id'       => 'bpt_breadcrumbs_hover_color',
                'type'     => 'color',
                'title'    => 'Breadcrumbs Link Hover Color',
                'subtitle' => 'Change the breadcrumbs link hover color <br/>(default: #111).',
                'default'  => '#111111',
                'output'   => array( 'color' => '.page-title .breadcrumb li a:hover' ),
                'required' => array( 'bpt_breadcrumbs_on', '=', true ),
            ),
            array(
                'id'       => 'bpt_breadcrumbs_current_color',
                'type'     => 'color',
                'title'    => 'Breadcrumbs Current Color',
                'subtitle' => 'Change the breadcrumbs current item color <br/>(default: #999).',
                'default'  => '#999999',
                'output'   => array( 'color' => '.page-title .breadcrumb .item-current' ),
                'required' => array( 'bpt_breadcrumbs_on', '=', true ),
            ),
            array(
                'id'       => 'bpt_breadcrumbs_sep_color',
                'type'     => 'color',
                'title'    => 'Breadcrumbs Separator Color',
                'subtitle' => 'Change the breadcrumbs separator color <br/>(default: #777).',
                'default'  => '#777777',
                'output'   => array( 'color' => '.breadcrumb li + li:before' ),
                'required' => array( 'bpt_breadcrumbs_on', '=', true ),
            ),
            array(
                'id'   => 'bpt_sep_2',
                'type' => 'divide'
            ),
            array(
                'id'       => 'bpt_title',
                'type'     => 'text',
                'title'    => 'Blog Title',
                'default'  => 'Blog',
            ),
            array(
                'id'       => 'bpt_subtitle_on',
                'type'     => 'switch',
                'title'    => 'Show Blog Subtitle',
                'default'  => true,
                'required' => array( 'bpt_size', '=', array( 'pt-large', 'pt-medium' ) ),
            ),
            array(
                'id'       => 'bpt_subtitle',
                'type'     => 'text',
                'title'    => 'Blog Subtitle',
                'default'  => 'Latest blog posts',
                'required' => array( 'bpt_subtitle_on', '=', true ),
            ),
            array(
                'id'       => 'bpt_title_color',
                'type'     => 'color',
                'title'    => 'Title Color',
                'subtitle' => 'Change the title color <br/>(default: #111).',
                'default'  => '#111111',
                'output'   => array( 'color' => '.bpt-title-color' ),
            ),
            array(
                'id'       => 'bpt_subtitle_color',
                'type'     => 'color',
                'title'    => 'Subtitle Color',
                'subtitle' => 'Change the subtitle color <br/>(default: #777).',
                'default'  => '#777777',
                'output'   => array( 'color' => '.page-title .subheading' ),
                'required' => array( 'bpt_subtitle_on', '=', true ),
            ),
        )          
     ) );


    /* --------------------------------------------------
        Portfolio (CPT plugin: definity-portfolio)
    -------------------------------------------------- */

    include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    if ( is_plugin_active( 'definity-portfolio/definity-portfolio.php' ) ) {
        Redux::setSection( $opt_name, array(
            'title'            => esc_html__( 'Portfolio', 'definity-elements' ),
            'id'               => 'pfolio_group',
            'icon'             => 'el el-th-large',
            'fields'     => array(
                array(
                    'id'       => 'pfolio_filters_on',
                    'type'     => 'switch',
                    'title'    => 'Portfolio Filters',
                    'subtitle' => 'Display filters so you can sort the portfolio items.',
                    'default'  => true,
                    ),
                array(
                    'id'       => 'pfolio_filter_all_txt',
                    'type'     => 'text',
                    'title'    => 'Change filter "All" text',
                    'default'  => 'All',
                    'required' => array( 'pfolio_filters_on', '=', true ),
                    ),
                array(
                    'id'       => 'pfolio_title_on',
                    'type'     => 'switch',
                    'title'    => 'Title & Subtitle',
                    'subtitle' => 'Display centered title & subtitle above the portfolio.',
                    'default'  => true,
                    ),
                array(
                    'id'       => 'pfolio_title_txt',
                    'type'     => 'text',
                    'title'    => 'Title',
                    'default'  => 'Our Work',
                    'required' => array( 'pfolio_title_on', '=', true ),
                    ),
                array(
                    'id'       => 'pfolio_subtitle_txt',
                    'type'     => 'text',
                    'title'    => 'Subtitle',
                    'default'  => 'Some of our latest work',
                    'required' => array( 'pfolio_title_on', '=', true ),
                    ),
                array(
                    'id'             => 'pfolio_title_content_spacing',
                    'type'           => 'spacing',
                    'title'          => 'Bottom Title Spacing',
                    'subtitle'       => 'Default: 100px;',
                    'desc'           => 'Without units (px) sign.',
                    'left'           => false,
                    'right'          => false,
                    'top'            => false,
                    'mode'           => 'margin',
                    'units'          => 'px',
                    'units_extended' => 'false',
                    'output'         => array( '.pfolio-header-wrapper' ),
                    'default'        => array( 'margin-bottom' => '100px', 'units' => 'px' ),
                    ),
                )
            )
        );

        Redux::setSection( $opt_name, array(
            'title'            => esc_html__( 'Portfolio Settings', 'definity-elements' ),
            'id'               => 'pfolio_settings',
            'subsection'       => true,
            'fields'     => array(
                array(
                    'id'       => 'pfolio_filters_on',
                    'type'     => 'switch',
                    'title'    => 'Portfolio Filters',
                    'subtitle' => 'Display filters so you can sort the portfolio items.',
                    'default'  => true,
                    ),
                array(
                    'id'       => 'pfolio_filter_all_txt',
                    'type'     => 'text',
                    'title'    => 'Change filter "All" text',
                    'default'  => 'All',
                    'required' => array( 'pfolio_filters_on', '=', true ),
                    ),
                array(
                    'id'       => 'pfolio_title_on',
                    'type'     => 'switch',
                    'title'    => 'Title & Subtitle',
                    'subtitle' => 'Display centered title & subtitle above the portfolio.',
                    'default'  => true,
                    ),
                array(
                    'id'       => 'pfolio_title_txt',
                    'type'     => 'text',
                    'title'    => 'Title',
                    'default'  => 'Our Work',
                    'required' => array( 'pfolio_title_on', '=', true ),
                    ),
                array(
                    'id'       => 'pfolio_subtitle_txt',
                    'type'     => 'text',
                    'title'    => 'Subtitle',
                    'default'  => 'Some of our latest work',
                    'required' => array( 'pfolio_title_on', '=', true ),
                    ),
                array(
                    'id'             => 'pfolio_title_content_spacing',
                    'type'           => 'spacing',
                    'title'          => 'Bottom Title Spacing',
                    'subtitle'       => 'Default: 100px;',
                    'desc'           => 'Without units (px) sign.',
                    'left'           => false,
                    'right'          => false,
                    'top'            => false,
                    'mode'           => 'margin',
                    'units'          => 'px',
                    'units_extended' => 'false',
                    'output'         => array( '.pfolio-header-wrapper' ),
                    'default'        => array( 'margin-bottom' => '100px', 'units' => 'px' ),
                    ),
                )
            )
        );

        Redux::setSection( $opt_name, array(
            'title'            => esc_html__( 'Portfolio Page Title', 'definity-elements' ),
            'id'               => 'pfolio_pt_tab',
            'customizer_width' => '400px',
            'subsection'       => true,
            'fields'     => array(
                array(
                    'id'       => 'pfolio_pt_size',
                    'type'     => 'select',
                    'title'    => 'Page Title Size',
                    'subtitle' => 'Choose page title size.',
                    'options'  => array(
                        'pt-large'  => 'Large',
                        'pt-medium' => 'Medium',
                        'pt-small'  => 'Small',
                        'pt-none'   => 'No Page Title',
                    ),
                    'default'  => 'pt-medium'
                ),
                array(
                    'id'       => 'pfolio_pt_bg_color',
                    'type'     => 'color_rgba',
                    'title'    => 'Background Color',
                    'subtitle' => 'Pick a page title background color <br/>(default: #f4f4f4).',
                    'description' => 'This can also be used as a transparent overlay layer over the bg image if you use one.',
                    'output'    => array( 'background-color' => '.pfolio-pt-bg:before' ),
                    'default'   => '#f4f4f4',
                ),
                array(
                    'id'       => 'pfolio_pt_bg_img',
                    'type'     => 'background',
                    'url'      => true,
                    'title'    => 'Background Image',
                    'subtitle' => 'Upload background image for the blog page title.',
                    'required' => array( 'pfolio_pt_size', '=', array( 'pt-large', 'pt-medium' ) ),
                    'output'   => array( 'background' => '.pfolio-pt-bg' ),
                ),
                array(
                    'id'             => 'pfolio_pt_content_spacing',
                    'type'           => 'spacing',
                    'title'          => 'Page Title and Content Spacing',
                    'subtitle'       => 'Default <br/>bottom 100px',
                    'desc'           => 'Without units (px) sign.',
                    'left'           => false,
                    'right'          => false,
                    'top'            => false,
                    'mode'           => 'margin',
                    'units'          => 'px',
                    'units_extended' => 'false',
                    'output'         => array( 'header.page-title.pfolio-pt' ),
                    'default'        => array( 'margin-bottom' => '100px', 'units' => 'px' ),
                ),
                array(
                    'id'       => 'pfolio_pt_parallax_on',
                    'type'     => 'switch',
                    'title'    => 'Parallax Effect',
                    'subtitle' => 'Enable parallax effect for the page title.',
                    'required' => array( 'pfolio_pt_size', '=', array( 'pt-large', 'pt-medium' ) ),
                    'default'  => true,
                ),
                array(
                    'id'   => 'bpt_sep_1',
                    'type' => 'divide'
                ),
                array(
                    'id'       => 'pfolio_pt_title',
                    'type'     => 'text',
                    'title'    => 'Portfolio Title',
                    'default'  => 'Portfolio',
                ),
                array(
                    'id'       => 'pfolio_pt_subtitle_on',
                    'type'     => 'switch',
                    'title'    => 'Show Blog Subtitle',
                    'default'  => true,
                    'required' => array( 'pfolio_pt_size', '=', array( 'pt-large', 'pt-medium' ) ),
                ),
                array(
                    'id'       => 'pfolio_pt_subtitle',
                    'type'     => 'text',
                    'title'    => 'Portfolio Subtitle',
                    'default'  => 'Some of our latest work',
                    'required' => array( 'pfolio_pt_subtitle_on', '=', true ),
                ),
                array(
                    'id'       => 'pfolio_pt_title_color',
                    'type'     => 'color',
                    'title'    => 'Title Color',
                    'subtitle' => 'Change the title color <br/>(default: #111).',
                    'default'  => '#111111',
                    'output'   => array( 'color' => 'header.pfolio-pt .pfolio-pt-title-color ' ),
                ),
                array(
                    'id'       => 'pfolio_pt_subtitle_color',
                    'type'     => 'color',
                    'title'    => 'Subtitle Color',
                    'subtitle' => 'Change the subtitle color <br/>(default: #777).',
                    'default'  => '#777777',
                    'output'   => array( 'color' => 'header.pfolio-pt.page-title .pfolio-pt-subtitle ' ),
                    'required' => array( 'pfolio_pt_subtitle_on', '=', true ),
                ),
                array(
                    'id'   => 'pfolio_pt_sep_2',
                    'type' => 'divide'
                ),
                array(
                    'id'       => 'pfolio_pt_breadcrumbs_on',
                    'type'     => 'switch',
                    'title'    => 'Breadcrumbs',
                    'subtitle' => 'Show breadcrumbs in the page title <br/>e.g. Home / Blog / Blog Post Name',
                    'default'  => true,
                ),
                array(
                    'id'       => 'pfolio_pt_breadcrumbs_color',
                    'type'     => 'color',
                    'title'    => 'Breadcrumbs Link Color',
                    'subtitle' => 'Change the breadcrumbs link color <br/>(default: #777).',
                    'default'  => '#777777',
                    'output'   => array( 'color' => '.page-title.pfolio-pt .breadcrumb li a' ),
                    'required' => array( 'pfolio_pt_breadcrumbs_on', '=', true ),
                ),
                array(
                    'id'       => 'pfolio_pt_breadcrumbs_hover_color',
                    'type'     => 'color',
                    'title'    => 'Breadcrumbs Link Hover Color',
                    'subtitle' => 'Change the breadcrumbs link hover color <br/>(default: #111).',
                    'default'  => '#111111',
                    'output'   => array( 'color' => '.page-title.pfolio-pt .breadcrumb li a:hover' ),
                    'required' => array( 'pfolio_pt_breadcrumbs_on', '=', true ),
                ),
                array(
                    'id'       => 'pfolio_pt_breadcrumbs_current_color',
                    'type'     => 'color',
                    'title'    => 'Breadcrumbs Current Color',
                    'subtitle' => 'Change the breadcrumbs current item color <br/>(default: #999).',
                    'default'  => '#999999',
                    'output'   => array( 'color' => '.page-title.pfolio-pt .breadcrumb .item-current' ),
                    'required' => array( 'pfolio_pt_breadcrumbs_on', '=', true ),
                ),
                array(
                    'id'       => 'pfolio_pt_breadcrumbs_sep_color',
                    'type'     => 'color',
                    'title'    => 'Breadcrumbs Separator Color',
                    'subtitle' => 'Change the breadcrumbs separator color <br/>(default: #777).',
                    'default'  => '#777777',
                    'output'   => array( 'color' => '.page-title.pfolio-pt .breadcrumb li + li:before' ),
                    'required' => array( 'pfolio_pt_breadcrumbs_on', '=', true ),
                ),
            )
        ) );
    }


    /* --------------------------------------------------
        Social Links
    -------------------------------------------------- */
    
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Social Links', 'definity-elements' ),
        'id'         => 'social_profiles_tab',
        'customizer_width' => '400px',
        'icon'             => 'el el-link',
        'fields'     => array(
           array(
               'id'       => 'social_profiles',
               'type'     => 'sortable',
               'title'    => 'Enter the social links', 'redux-framework-demo',
               'subtitle' => '<p>Enter the url(link) of your social media profiles that you want to display.</p><p><b>* Note: </b>You can change the order the button appear by dragging the cross arrows.</p>',
               'label'    => true,
               'options'  => array(
                   'Facebook'   => 'Enter url here',
                   'Twitter'    => 'Enter url here',
                   'Linkedin'   => 'Enter url here',
                   'Pinterest'  => 'Enter url here',
                   'Instagram'  => 'Enter url here',
                   'Google-plus'=> 'Enter url here',
                   'Flickr'     => 'Enter url here',
                   'YouTube'    => 'Enter url here',
                   'Vimeo'      => 'Enter url here',
                   'SoundCloud' => 'Enter url here',
                   'Dribbble'   => 'Enter url here',
                   'Behance'    => 'Enter url here',
                   'Tumblr'     => 'Enter url here',
                   'Snapchat'   => 'Enter url here',
                   'VK'         => 'Enter url here',
                   'Weibo'      => 'Enter url here',
                   'RSS'        => 'Enter url here',
               ),
           )
        )
    ) );


    /* --------------------------------------------------
        Typography
    -------------------------------------------------- */
    
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Typography', 'definity-elements' ),
        'id'               => 'typography-options',
        'icon'             => 'el el-fontsize',
        'customizer_width' => '500px',
        'fields'           => array(
            array(
                'id'          => 'd_main_typography',
                'type'        => 'typography', 
                'title'       => 'Main Typography',
                'subtitle'    => '<strong>Defaults:</strong> <br/>Open Sans, <br/>font size: 14px, <br/>font weight: 300, <br/>line height: 1.8em <br/>color: #777',
                'google'      => true,
                'color'       => true,
                'font-weight' => true,
                'font-backup' => false,
                'font-style'  => false,
                'text-align'  => false,
                'subsets'     => false,
                'output'      => array( 'body' ),
            ),
            array(
                'id'             => 'd_headings_typography',
                'type'           => 'typography', 
                'title'          => 'Headings Typography',
                'subtitle'       => '<strong>Defaults:</strong> <br/>Montserrat, <br/>Uppercase, <br/>font weight: 400 <br/>color: #111',
                'google'         => true, 
                'text-transform' => true,
                'font-weight'    => true,
                'font-style'     => true,
                'color'          => true,
                'font-backup'    => false,
                'font-size'      => false,
                'line-height'    => false,
                'text-align'     => false,
                'subsets'        => false,
                'output'         => array( 'h1, h2, h3, h4, h5, h6' ),
            ),
            array(
                'id'             => 'd_alt_headings_typography',
                'type'           => 'typography', 
                'title'          => 'Alternative Headings Typography',
                'subtitle'       => '<strong>Defaults:</strong> <br/>Open Sans, <br/>Uppercase, <br/>font weight: 300 <br/>color: #111',
                'google'         => true, 
                'text-transform' => true,
                'font-weight'    => true,
                'font-style'     => true,
                'color'          => true,
                'font-backup'    => false,
                'font-size'      => false,
                'line-height'    => false,
                'text-align'     => false,
                'subsets'        => false,
                'output'         => array( '.h-alt' ),
            ),
            array(
                'id'   => 'typ_sep_1',
                'type' => 'divide'
            ),
            array(
                'id'             => 'd_h1_typography',
                'type'           => 'typography', 
                'title'          => 'H1 Heading',
                'subtitle'       => '<strong>Defaults:</strong> <br/>font size: 1.7em <br/>letter-spacing: 0.21em <br/>line height: /'  ,
                'font-size'      => true,
                'line-height'    => true,
                'letter-spacing' => true,
                'font-family'    => false,
                'font-backup'    => false,
                'font-style'     => false,
                'font-weight'    => false,
                'text-align'     => false,
                'subsets'        => false,
                'color'          => false,
                'units'          => 'em',
                'output'         => array( 'h1' ),
            ),
            array(
                'id'          => 'd_h2_typography',
                'type'        => 'typography', 
                'title'       => 'H2 Heading',
                'subtitle'       => '<strong>Defaults:</strong> <br/>font size: 1.5em <br/>letter-spacing: 0.19em <br/>line height: /'  ,
                'font-size'      => true,
                'line-height'    => true,
                'letter-spacing' => true,
                'font-family'    => false,
                'font-backup'    => false,
                'font-style'     => false,
                'font-weight'    => false,
                'text-align'     => false,
                'subsets'        => false,
                'color'          => false,
                'units'          => 'em',
                'output'      => array( 'h2' ),
            ),
            array(
                'id'          => 'd_h3_typography',
                'type'        => 'typography', 
                'title'       => 'H3 Heading',
                'subtitle'       => '<strong>Defaults:</strong> <br/>font size: 1.3em <br/>letter-spacing: 0.193em <br/>line height: /'  ,
                'font-size'      => true,
                'line-height'    => true,
                'letter-spacing' => true,
                'font-family'    => false,
                'font-backup'    => false,
                'font-style'     => false,
                'font-weight'    => false,
                'text-align'     => false,
                'subsets'        => false,
                'color'          => false,
                'units'          => 'em',
                'output'      => array( 'h3' ),
            ),
            array(
                'id'          => 'd_h4_typography',
                'type'        => 'typography', 
                'title'       => 'H4 Heading',
                'subtitle'       => '<strong>Defaults:</strong> <br/>font size: 1.17em <br/>letter-spacing: 0.20em <br/>line height: /'  ,
                'font-size'      => true,
                'line-height'    => true,
                'letter-spacing' => true,
                'font-family'    => false,
                'font-backup'    => false,
                'font-style'     => false,
                'font-weight'    => false,
                'text-align'     => false,
                'subsets'        => false,
                'color'          => false,
                'units'          => 'em',
                'output'      => array( 'h4' ),
            ),
            array(
                'id'          => 'd_h5_typography',
                'type'        => 'typography', 
                'title'       => 'H5 Heading',
                'subtitle'       => '<strong>Defaults:</strong> <br/>font size: 1em <br/>letter-spacing: 0.14em <br/>line height: /'  ,
                'font-size'      => true,
                'line-height'    => true,
                'letter-spacing' => true,
                'font-family'    => false,
                'font-backup'    => false,
                'font-style'     => false,
                'font-weight'    => false,
                'text-align'     => false,
                'subsets'        => false,
                'color'          => false,
                'units'          => 'em',
                'output'      => array( 'h5' ),
            ),
            array(
                'id'          => 'd_h6_typography',
                'type'        => 'typography', 
                'title'       => 'H6 Heading',
                'subtitle'       => '<strong>Defaults:</strong> <br/>font size: 0.85em <br/>letter-spacing: 0.167em <br/>line height: /'  ,
                'font-size'      => true,
                'line-height'    => true,
                'letter-spacing' => true,
                'font-family'    => false,
                'font-backup'    => false,
                'font-style'     => false,
                'font-weight'    => false,
                'text-align'     => false,
                'subsets'        => false,
                'color'          => false,
                'units'          => 'em',
                'output'      => array( 'h6' ),
            )
        )
    ) );


    /* --------------------------------------------------
        Style
    -------------------------------------------------- */

    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Style', 'definity-elements' ),
        'id'               => 'style_settings',
        'icon'             => 'el el-brush',
    ) );
    
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'General Styles', 'definity-elements' ),
        'id'               => 'style_general',
        'customizer_width' => '500px',
        'subsection'       => true,
        'fields'           => array(
            array(
                'id'       => 'perloader_bg',
                'type'     => 'color',
                'title'    => 'Loading Screen Background',
                'subtitle' => 'Change the background color of <br/>the loading screen <br/>(default: #111).',
                'output'   => array( 'background-color' => '.preloader' ),
                'required' => array( 'd_perloader', '=', true ),
            ),
            array(
                'id'       => 'text_select_color',
                'type'     => 'color',
                'title'    => 'Text Select Color',
                'subtitle' => 'default: #17DA5B',
                'output'   => array( 
                    'background' => '::selection',
                    'background-color' => '::-moz-selection' ),
            ),
            array(
                'id'       => 'text_mark_color',
                'type'     => 'color',
                'title'    => 'Mark Text Color',
                'subtitle' => 'HTML element mark, used for <br/>highlighting text <br/>(default: #cafe48).',
                'output'   => array( 
                    'background' => 'mark' ),
            ),
        )
    ) );

    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Navigation Styles', 'definity-elements' ),
        'id'               => 'style_nav',
        'customizer_width' => '500px',
        'subsection'       => true,
        'fields'           => array(
            array(
                'id'       => 'nav_bg',
                'type'     => 'color_rgba',
                'title'    => 'Menu Background',
                'output'   => array( 'background' => '.d-nav-c-style' ),
            ),
            array(
                'id'       => 'nav_links_color',
                'type'     => 'color_rgba',
                'title'    => 'Menu Links Color',
                'output'   => array( 'color' => '.d-nav-c-style .d-nav-wrapper .d-nav-menu ul.d-nav-menu-items-list li.menu-item a, .d-nav-c-style .d-nav-wrapper .d-nav-menu ul.d-nav-search li.menu-item a' ),
            ),
            array(
                'id'       => 'nav_link_hover_color',
                'type'     => 'color_rgba',
                'title'    => 'Hover Menu Link Color',
                'output'   => array( 'color' => '#navbar.d-nav-menu li a:hover' ),
            ),
            array(
                'id'       => 'nav_link_hover_bg_color',
                'type'     => 'color_rgba',
                'title'    => 'Hover Menu Link Background Color',
                'output'   => array( 'background-color' => '#navbar.d-nav-menu li:hover' ),
                'required' => array( 'nav_layout', '=', array( 'nav-neue' ) )
            ),
            array(
                'id'       => 'nav_link_active_hover_bg_color',
                'type'     => 'color_rgba',
                'title'    => 'Hover Active Menu Link Background Color',
                'output'   => array( 'background-color' => '#navbar.d-nav-menu li.current-menu-parent, #navbar.d-nav-menu li.current-menu-item, #navbar.d-nav-menu li.active' ),
                'required' => array( 'nav_layout', '=', array( 'nav-neue' ) )
            ),
            array(
                'id'       => 'nav_link_active_color',
                'type'     => 'color_rgba',
                'title'    => 'Active Menu Link Color',
                'output'   => array( 'color' => '#navbar.d-nav-menu li.current-menu-item a, #navbar.d-nav-menu li.current-menu-parent > a, #navbar.d-nav-menu li.active > a' ),
            ),
            array(
                'id'       => 'nav_border_color',
                'type'     => 'color_rgba',
                'title'    => 'Menu Border Color',
                'output'   => array( 'border-color' => '.d-nav-c-style.d-nav-stacked .d-nav-wrapper .d-nav-menu' ),
                'required' => array( 'nav_layout', '=', array( 'nav-stacked-left', 'nav-stacked-right', 'nav-stacked-center' ) )
            ),
            array(
                'id'       => 'nav_burger_color',
                'type'     => 'color_rgba',
                'title'    => 'Mobile Menu - Open Button',
                'output'   => array( 'color' => 'nav.d-nav-c-style .d-mobile-nav-open span' ),
            ),
            array(
                'id'       => 'nav_neue_cta_link_bg',
                'type'     => 'color_rgba',
                'title'    => 'Menu CTA link - Background',
                'output'   => array( 'background-color' => '.d-nav-c-style .d-nav-wrapper .d-nav-menu ul.d-nav-menu-items-list li.cta-menu-neue' ),
                'required' => array( 'nav_layout', '=', array( 'nav-neue' ) )
            ),
            array(
                'id'       => 'nav_neue_cta_link_bg_hover',
                'type'     => 'color_rgba',
                'title'    => 'Menu CTA link - Hover Background',
                'output'   => array( 'background-color' => '.d-nav-c-style .d-nav-wrapper .d-nav-menu ul.d-nav-menu-items-list li.cta-menu-neue:hover' ),
                'required' => array( 'nav_layout', '=', array( 'nav-neue' ) )
            ),
            array(
                'id'       => 'nav_neue_cta_link_txt',
                'type'     => 'color_rgba',
                'title'    => 'Menu CTA link - Link Color',
                'output'   => array( 'color' => '.d-nav-c-style .d-nav-wrapper .d-nav-menu ul.d-nav-menu-items-list li.cta-menu-neue > a' ),
                'required' => array( 'nav_layout', '=', array( 'nav-neue' ) )
            ),
            array(
                'id'       => 'nav_neue_cta_link_txt_hover',
                'type'     => 'color_rgba',
                'title'    => 'Menu CTA link - Hover Link Color',
                'output'   => array( 
                    'color'            => '.d-nav-c-style .d-nav-wrapper #navbar.d-nav-menu ul.d-nav-menu-items-list li.cta-menu-neue > a:hover',
                    'border-color'     => '.d-nav-c-style.d-nav-neue .d-nav-wrapper .d-nav-menu ul.d-nav-menu-items-list li.cta-menu-neue > a:after'
                ),
                'required' => array( 'nav_layout', '=', array( 'nav-neue' ) )
            ),
            array(
                'id'   => 'header_style_sep_2.4',
                'type' => 'divide',
            ),
            // Nav Social Links (stacked)
            array(
                'id'       => 'nav_social_color',
                'type'     => 'color_rgba',
                'title'    => 'Menu Social Links - Color',
                'output'   => array( 'color' => '.d-nav-c-style.d-nav-stacked .d-nav-wrapper .d-nav-stacked-top .d-nav-social-links ul li a' ),
                'required' => array( 'nav_layout', '=', array( 'nav-stacked-left', 'nav-stacked-right' ) )
            ),
            array(
                'id'       => 'nav_social_border_color',
                'type'     => 'color_rgba',
                'title'    => 'Menu Social Links - Border Color',
                'output'   => array( 'border-color' => '.d-nav-c-style.d-nav-stacked .d-nav-wrapper .d-nav-stacked-top .d-nav-social-links ul li a' ),
                'required' => array( 'nav_layout', '=', array( 'nav-stacked-left', 'nav-stacked-right' ) )
            ),
            array(
                'id'       => 'nav_social_bg_color',
                'type'     => 'color_rgba',
                'title'    => 'Menu Social Links - Background Color',
                'output'   => array( 'background-color' => '.d-nav-c-style.d-nav-stacked .d-nav-wrapper .d-nav-stacked-top .d-nav-social-links ul li a' ),
                'required' => array( 'nav_layout', '=', array( 'nav-stacked-left', 'nav-stacked-right' ) )
            ),
            array(
                'id'       => 'nav_social_hover_color',
                'type'     => 'color_rgba',
                'title'    => 'Menu Social Links - Hover Color',
                'output'   => array( 'color' => '.d-nav-c-style.d-nav-stacked .d-nav-wrapper .d-nav-stacked-top .d-nav-social-links ul li a:hover' ),
                'required' => array( 'nav_layout', '=', array( 'nav-stacked-left', 'nav-stacked-right' ) )
            ),
            array(
                'id'       => 'nav_social_hover_border_color',
                'type'     => 'color_rgba',
                'title'    => 'Menu Social Links - Hover Border Color',
                'output'   => array( 'border-color' => '.d-nav-c-style.d-nav-stacked .d-nav-wrapper .d-nav-stacked-top .d-nav-social-links ul li a:hover' ),
                'required' => array( 'nav_layout', '=', array( 'nav-stacked-left', 'nav-stacked-right' ) )
            ),
            array(
                'id'       => 'nav_social_hover_bg_color',
                'type'     => 'color_rgba',
                'title'    => 'Menu Social Links - Hover Background Color',
                'output'   => array( 'background-color' => '.d-nav-c-style.d-nav-stacked .d-nav-wrapper .d-nav-stacked-top .d-nav-social-links ul li a:hover' ),
                'required' => array( 'nav_layout', '=', array( 'nav-stacked-left', 'nav-stacked-right' ) )
            ),
            array(
                'id'   => 'header_style_sep_2.2',
                'type' => 'divide',
                'required' => array( 'nav_layout', '=', array( 'nav-stacked-left', 'nav-stacked-right' ) )
            ),
            // Extended Nav
            array(
                'id'       => 'nav_extend_bg_color',
                'type'     => 'color_rgba',
                'title'    => 'Extended Menu Background',
                'subtitle' => 'Change the color of the extended menu background.',
                'output'   => array( 'background-color' => '.d-nav-extend-c-style' ),
                'required' => array( array( 'nav_extend_show', '=', array( true ) ) )
            ),
            array(
                'id'       => 'nav_extend_link_color',
                'type'     => 'color_rgba',
                'title'    => 'Extended Menu Link Color',
                'subtitle' => 'Change the color of the extended menu links.',
                'output'   => array( 'color' => '.d-nav-extend-c-style ul.d-nav-extend-menu li a, .d-nav-extend-c-style ul.d-nav-extend-menu li.fa' ),
                'required' => array( array( 'nav_extend_show', '=', array( true ) ) )
            ),
            array(
                'id'       => 'nav_extend_link_hover_color',
                'type'     => 'color_rgba',
                'title'    => 'Extended Menu Link Hover Color',
                'subtitle' => 'Change the color of the extended hover menu links.',
                'output'   => array( 'color' => '.d-nav-extend-c-style ul.d-nav-extend-menu li a:hover, .d-nav-extend-c-style ul.d-nav-extend-menu li.fa:hover' ),
                'required' => array( array( 'nav_extend_show', '=', array( true ) ) )
            ),
            array(
                'id'             => 'nav_extend_links_font',
                'type'           => 'typography', 
                'title'          => 'Extended Menu - Font Settings',
                'subtitle'       => 'Change the typography for the extended menu link.',
                'google'         => true, 
                'text-transform' => true,
                'font-size'      => true,
                'font-weight'    => true,
                'letter-spacing' => true,
                'font-style'     => true,
                'color'          => false,
                'font-backup'    => false,
                'line-height'    => false,
                'text-align'     => false,
                'subsets'        => false,
                'units'          => 'em',
                'output'         => array( '.d-nav-extend-c-style ul.d-nav-extend-menu li a' ),
                'required' => array( array( 'nav_extend_show', '=', array( true ) ) )
            ),
            array(
                'id'             => 'nav_extend_icon_font',
                'type'           => 'typography', 
                'title'          => 'Extended Menu Icons - Font Size',
                'subtitle'       => 'Change the font size for the icons in the extended menu.',
                'google'         => false, 
                'text-transform' => false,
                'font-family'    => false,
                'font-size'      => true,
                'font-weight'    => false,
                'letter-spacing' => false,
                'font-style'     => false,
                'color'          => false,
                'font-backup'    => false,
                'line-height'    => false,
                'text-align'     => false,
                'subsets'        => false,
                'units'          => 'px',
                'output'         => array( '.d-nav-extend-c-style ul.d-nav-extend-menu li.fa:before' ),
                'required' => array( array( 'nav_extend_show', '=', array( true ) ) )
            ),
            array(
                'id'   => 'header_style_sep_2.3',
                'type' => 'divide',
                'required' => array( array( 'nav_extend_show', '=', array( true ) ) )
            ),
            // Dropdown Menu
            array(
                'id'       => 'nav_dropdown_bg',
                'type'     => 'color_rgba',
                'title'    => 'Dropdown Menu Background',
                'subtitle' => 'Change the dropdown menu background color',
                'output'   => array( 'background' => '.d-nav-c-style .d-nav-menu .d-nav-menu-items-list li.menu-item ul.sub-menu' ),
            ),
            array(
                'id'       => 'nav_dropdown_links_color',
                'type'     => 'color_rgba',
                'title'    => 'Dropdown Menu Links Colors',
                'subtitle' => 'Change the color of dropdown menu links',
                'output'   => array( 'color' => '.d-nav-c-style .d-nav-menu .d-nav-menu-items-list li.menu-item ul.sub-menu li a' ),
            ),
            array(
                'id'       => 'nav_dropdown_link_bg',
                'type'     => 'color_rgba',
                'title'    => 'Dropdown Hover Menu Link Background',
                'subtitle' => 'Change the background color of the dropdown hover menu link.',
                'output'   => array( 'background' => '.d-nav-c-style .d-nav-menu ul.d-nav-menu-items-list li.menu-item ul.sub-menu li.menu-item a:hover' ),
            ),
            array(
                'id'       => 'nav_dropdown_accent',
                'type'     => 'color_rgba',
                'title'    => 'Dropdown Hover Menu Link Accent',
                'subtitle' => 'Change the color of the dropdown menu link accent',
                'output'   => array( 'border-left-color' => '.d-nav-c-style .d-nav-menu ul.d-nav-menu-items-list li.menu-item ul.sub-menu li.menu-item a:hover' ),
            ),
            array(
                'id'   => 'header_sep_2.1',
                'type' => 'divide',
            ),
            // Transparent Nav
            array(
                'id'       => 'nav_trans_bg',
                'type'     => 'color_rgba',
                'title'    => 'Transparent Menu Background',
                'subtitle' => 'Change the background color of the transparent menu',
                'output'   => array( 'background' => 'nav.d-nav-c-style.d-nav-trans' ),
                'required' => array( array( 'nav_trans_on', '=', array( true ) ) )
            ),
            array(
                'id'       => 'nav_trans_links',
                'type'     => 'color_rgba',
                'title'    => 'Transparent Menu Links Color',
                'subtitle' => 'Change the color of the transparent menu links',
                'output'   => array( 'color' => 'nav.d-nav-c-style.d-nav-trans #navbar.d-nav-menu .d-nav-menu-items-list > li > a' ),
                'required' => array( array( 'nav_trans_on', '=', array( true ) ) )
            ),
            array(
                'id'       => 'nav_trans_links_hover',
                'type'     => 'color_rgba',
                'title'    => 'Transparent Hover Menu Links Color',
                'subtitle' => 'Change the color of the transparent menu links for the hover state',
                'output'   => array( 'color' => 'nav.d-nav-c-style.d-nav-trans #navbar.d-nav-menu .d-nav-menu-items-list > li > a:hover' ),
                'required' => array( array( 'nav_trans_on', '=', array( true ) ) )
            ),
            array(
                'id'       => 'nav_trans_links_active',
                'type'     => 'color_rgba',
                'title'    => 'Transparent Active Menu Links Color',
                'subtitle' => 'Change the color of the transparent menu links for the active state',
                'output'   => array( 'color' => 'nav.d-nav-c-style.d-nav-trans #navbar.d-nav-menu .d-nav-menu-items-list > li.current-menu-item > a' ),
                'required' => array( array( 'nav_trans_on', '=', array( true ) ) )
            ),
            array(
                'id'   => 'header_sep_3',
                'type' => 'divide',
                'required' => array( array( 'nav_trans_on', '=', array( true ) ) )
            ),
            // Nav Font
            array(
                'id'             => 'nav_links_font',
                'type'           => 'typography', 
                'title'          => 'Menu Links - Font Settings',
                'subtitle'       => 'Change the typography for the navigation menu (main menu).',
                'desc'           => '* This settings will overwrite the settings from Typography tab.',
                'google'         => true, 
                'text-transform' => true,
                'font-size'      => true,
                'font-weight'    => true,
                'letter-spacing' => true,
                'font-style'     => true,
                'color'          => false,
                'font-backup'    => false,
                'line-height'    => false,
                'text-align'     => false,
                'subsets'        => false,
                'units'          => 'em',
                'output'         => array( '.d-nav-c-style.d-nav-inline .d-nav-menu .d-nav-menu-items-list li.menu-item a' ),
            )
        )
    ) );

    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Footer Styles', 'definity-elements' ),
        'id'               => 'style_footer',
        'customizer_width' => '500px',
        'subsection'       => true,
        'fields'           => array(
            array(
                'id'       => 'footer_bg',
                'type'     => 'color_rgba',
                'title'    => 'Footer Background',
                'subtitle' => 'Change the color of the footer background.',
                'output'   => array( 'background-color' => 'footer.footer-litle .footer-social-links-wrapper, .footer-widgets' ),
            ),
            // Footer Widgets Styles
            array(
                'id'       => 'footer_widgets_heading_color',
                'type'     => 'color_rgba',
                'title'    => 'Widgets Headings Color',
                'subtitle' => 'Change the color of the widget heading.',
                'output'   => array( 'color' => '.footer-widgets .widget .header-widget' ),
                'required' => array( 'footer_layout', '=', array( 'footer-widgets' ) )
            ),
            array(
                'id'       => 'footer_widgets_div_color',
                'type'     => 'color_rgba',
                'title'    => 'Widgets Divider Color',
                'subtitle' => 'Change the color of the widget heading.',
                'output'   => array( 'border-bottom-color' => '.footer-widgets .widget .header-widget' ),
                'required' => array( 'footer_layout', '=', array( 'footer-widgets' ) )
            ),
            array(
                'id'       => 'footer_widgets_txt_color',
                'type'     => 'color_rgba',
                'title'    => 'Widgets Text Color',
                'subtitle'     => 'Change the color of the text widgets (text, twitter, newsletter).',
                'desc'     => 'This may overwrite the widget plugin styles.',
                'output'   => array( 'color' => '.footer-widgets .widget p, #ctf p.ctf-tweet-text, .footer-widgets .newsletter-widget-form i' ),
                'required' => array( 'footer_layout', '=', array( 'footer-widgets' ) )
            ),
            array(
                'id'             => 'footer_widgets_title_font',
                'type'           => 'typography', 
                'title'          => 'Widgets Heading - Font Settings',
                'subtitle'       => 'Change the typography of the widget headings for the footer (widets).',
                'google'         => true, 
                'text-transform' => true,
                'font-size'      => true,
                'font-weight'    => true,
                'letter-spacing' => true,
                'font-style'     => true,
                'color'          => false,
                'font-backup'    => false,
                'line-height'    => false,
                'text-align'     => false,
                'subsets'        => false,
                'units'          => 'em',
                'output'         => array( '.footer-widgets .widget h5.header-widget' ),
                'required' => array( 'footer_layout', '=', array( 'footer-widgets' ) )
            ),
            // Footer Litle Styles
            array(
                'id'       => 'footer_litle_links_color',
                'type'     => 'color_rgba',
                'title'    => 'Footer Social Links Color',
                'subtitle' => 'Change the color of the <br/>social links in the footer.',
                'output'   => array( 'color' => '.footer-social-links-wrapper .footer-social-links ul li a' ),
                'required' => array( 'footer_layout', '=', array( 'footer-litle' ) )
            ),
            array(
                'id'       => 'footer_litle_links_hover_color',
                'type'     => 'color_rgba',
                'title'    => 'Footer Social Links Hover Color',
                'subtitle' => 'Change the color of the <br/>social links hover state in the footer.',
                'output'   => array( 'color' => '.footer-social-links-wrapper .footer-social-links ul li a:hover' ),
                'required' => array( 'footer_layout', '=', array( 'footer-litle' ) )
            ),
            array(
                'id'       => 'footer_litle_links_div_color',
                'type'     => 'color_rgba',
                'title'    => 'Footer Social Links Divider Color',
                'subtitle' => 'Change the color of the divider <br/>between the social links in the footer.',
                'output'   => array( 'border-right-color' => '.footer-social-links-wrapper .footer-social-links ul li' ),
                'required' => array( 'footer_layout', '=', array( 'footer-litle' ) )
            ),
            array(
                'id'             => 'footer_litle_links_font',
                'type'           => 'typography', 
                'title'          => 'Footer Social Links - Font Settings',
                'subtitle'       => 'Change the typography of the social link in the footer (lite).',
                'google'         => true, 
                'text-transform' => true,
                'font-size'      => true,
                'font-weight'    => true,
                'letter-spacing' => true,
                'font-style'     => true,
                'color'          => false,
                'font-backup'    => false,
                'line-height'    => false,
                'text-align'     => false,
                'subsets'        => false,
                'units'          => 'em',
                'output'         => array( '.footer-social-links-wrapper .footer-social-links ul li' ),
                'required' => array( 'footer_layout', '=', array( 'footer-litle' ) )
            ),
            array(
                'id'   => 'footer_sep_2',
                'type' => 'divide',
            ),
            // Footer Copyright Styles
            array(
                'id'       => 'footer_copy_bg',
                'type'     => 'color_rgba',
                'title'    => 'Footer Copyright Background',
                'output'   => array( 'background-color' => 'footer .copyright' ),
            ),
            array(
                'id'       => 'footer_copy_links_color',
                'type'     => 'color_rgba',
                'title'    => 'Footer Copyright Text/Links Color',
                'output'   => array( 'color' => 'footer .copyright small, footer .copyright small a, footer .copyright .to-the-top' ),
            ),
            array(
                'id'       => 'footer_copy_links_hover_color',
                'type'     => 'color_rgba',
                'title'    => 'Footer Copyright Links Hover Color',
                'output'   => array( 'color' => 'footer .copyright small a:hover, footer .copyright a:hover.to-the-top' ),
            ),
            array(
                'id'             => 'footer_copy_font',
                'type'           => 'typography', 
                'title'          => 'Footer Copyright - Font Settings',
                'subtitle'       => 'Change the typography of the copyright section in the footer.',
                'google'         => true, 
                'text-transform' => true,
                'font-size'      => true,
                'font-weight'    => true,
                'letter-spacing' => true,
                'font-style'     => true,
                'color'          => false,
                'font-backup'    => false,
                'line-height'    => false,
                'text-align'     => false,
                'subsets'        => false,
                'units'          => 'em',
                'output'         => array( 'footer .copyright small' ),
            ),
        )
    ) );

    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Buttons Styles', 'definity-elements' ),
        'id'               => 'style_buttons',
        'customizer_width' => '500px',
        'subsection'       => true,
        'fields'           => array(
            array(
                'id'       => 'btn_bg',
                'type'     => 'color',
                'title'    => 'Standard Buttons - Background',
                'subtitle' => 'default: #111',
                'output'   => array( 'background' => '.btn, a.btn, button.btn, input[type="submit"].btn', )
            ),
            array(
                'id'       => 'btn_bg_hover',
                'type'     => 'color_rgba',
                'title'    => 'Standard Buttons - Hover Background',
                'subtitle' => 'default: rgba(17, 17, 17, 0.75)',
                'default'   => array(
                    'color'     => '#111111',
                    'alpha'     => 0.75
                ),
                'output'   => array( 'background' => '.btn:hover, .btn:visited:hover, a.btn:hover, button.btn:hover, input[type="submit"].btn:hover, a.btn:hover:visited, button.btn:hover:visited, input[type="submit"].btn:hover:visited' )
            ),
            array(
                'id'       => 'btn_text_color',
                'type'     => 'color',
                'title'    => 'Standard Buttons - Text Color',
                'subtitle' => 'default: #ececec',
                'output'   => array( 'color' => 'a.btn, button.btn, input[type="submit"].btn, a.btn:visited, button.btn:visited, input[type="submit"].btn:visited', )
            ),
            array(
                'id'       => 'btn_hover_text_color',
                'type'     => 'color',
                'title'    => 'Standard Buttons - Hover Text Color',
                'subtitle' => 'default: #ececec',
                'output'   => array( 'color' => 'a.btn:hover, button.btn:hover, input[type="submit"].btn:hover, a.btn:visited:hover, button.btn:visited:hover, input[type="submit"].btn:visited:hover', )
            ),
            array(
                'id'   => 'btn_sep_1',
                'type' => 'divide'
            ),
            array(
                'id'            => 'btn_ghost_bg',
                'type'          => 'color',
                'title'         => 'Ghost Buttons - Border Color',
                'subtitle'      => 'default: #111',
                'description'   => 'Also affects rounded buttons.',
                'output'        => array( 'border-color' => 'a.btn-ghost, button.btn-ghost, input[type="submit"].btn-ghost, a.btn-ghost:visited, button.btn-ghost:visited, input[type="submit"].btn-ghost:visited', )
            ),
            array(
                'id'            => 'btn_ghost_bg_hover',
                'type'          => 'color_rgba',
                'title'         => 'Ghost Buttons - Hover Background',
                'subtitle'      => 'default: #111',
                'description'   => 'Also affects rounded buttons.',
                'output'        => array( 
                    'background'    => '.btn-ghost:after',
                    'border-color'  => 'a.btn-ghost:hover, button.btn-ghost:hover, input[type="submit"].btn-ghost:hover, a.btn-ghost:hover:visited, button.btn-ghost:hover:visited, input[type="submit"].btn-ghost:hover:visited',
                 )
            ),
            array(
                'id'            => 'btn_ghost_text_color',
                'type'          => 'color',
                'title'         => 'Ghost Buttons - Text Color',
                'subtitle'      => 'default: #111',
                'description'   => 'Also affects rounded buttons.',
                'output'        => array( 'color' => 'a.btn-ghost, button.btn-ghost, input[type="submit"].btn-ghost, a.btn-ghost:visited, button.btn-ghost:visited, input[type="submit"].btn-ghost:visited', )
            ),
            array(
                'id'            => 'btn_ghost_hover_text_color',
                'type'          => 'color',
                'title'         => 'Ghost Buttons - Hover Text Color',
                'subtitle'      => 'default: #ececec',
                'description'   => 'Also affects rounded buttons.',
                'output'        => array( 'color' => 'a.btn-ghost:hover, button.btn-ghost:hover, input[type="submit"].btn-ghost:hover, a.btn-ghost:hover:visited, button.btn-ghost:hover:visited, input[type="submit"].btn-ghost:hover:visited', )
            ),
            array(
                'id'   => 'btn_sep_2',
                'type' => 'divide'
            ),
            array(
                'id'       => 'btn_text_text_color',
                'type'     => 'color_rgba',
                'title'    => 'Text Buttons - Text Color',
                'subtitle' => 'default: #777',
                'output'   => array( 'color' => 'btn-text a.btn-text, button.btn-text, input[type="submit"].btn-text, a.btn-text:visited, button.btn-text:visited, input[type="submit"].btn-text:visited', )
            ),
            array(
                'id'       => 'btn_text_hover_text_color',
                'type'     => 'color',
                'title'    => 'Text Buttons - Hover Text Color',
                'subtitle' => 'default: #111',
                'output'   => array( 'color' => 'btn-text:hover a.btn-text:hover, button.btn-text:hover, input[type="submit"].btn-text:hover, a.btn-text:hover:visited, button.btn-text:hover:visited, input[type="submit"].btn-text:hover:visited', )
            ),
            array(
                'id'       => 'btn_text_bg_hover',
                'type'     => 'color',
                'title'    => 'Text Buttons - Hover Border Color',
                'subtitle' => 'default: #111',
                'output'   => array( 'border-color' => 'btn-text:hover a.btn-text:hover, button.btn-text:hover, input[type="submit"].btn-text:hover, a.btn-text:hover:visited, button.btn-text:hover:visited, input[type="submit"].btn-text:hover:visited', )
            ),
        )
    ) );


    /* --------------------------------------------------
        Custom CSS & JS
    -------------------------------------------------- */
    
    // Redux::setSection( $opt_name, array(
    //     'title'            => esc_html__( 'Custom CSS & JS', 'definity-elements' ),
    //     'id'               => 'custom-css-js',
    //     'icon'             => 'el el-warning-sign',
    //     'customizer_width' => '500px',
    //     'desc'       => esc_html__( 'For full documentation on this field, please use the help file that comes with the theme downloaded.', 'definity-elements' ),
    //     'fields'           => array(
    //         array(
    //             'id'       => 'd_custom_css',
    //             'type'     => 'ace_editor',
    //             'title'    => 'Add Custom CSS',
    //             'subtitle' => 'Add custom CSS to the <br/>head/top of your site.',
    //             'mode'     => 'css',
    //             'theme'    => 'monokai',
    //         ),
    //         array(
    //             'id'       => 'd_custom_js',
    //             'type'     => 'ace_editor',
    //             'title'    => 'Add Custom JS',
    //             'subtitle' => 'Add custom JS to the <br/>footer/bottom of your site.',
    //             'mode'     => 'js',
    //             'theme'    => 'monokai',
    //         ),
    //     )
    // ) );


    
    

    if ( file_exists( dirname( __FILE__ ) . '/../README.md' ) ) {
        $section = array(
            'icon'   => 'el el-list-alt',
            'title'  => esc_html__( 'Documentation', 'redux-framework-demo' ),
            'fields' => array(
                array(
                    'id'       => '17',
                    'type'     => 'raw',
                    'markdown' => true,
                    'content_path' => dirname( __FILE__ ) . '/../README.md', // FULL PATH, not relative please
                    //'content' => 'Raw content here',
                ),
            ),
        );
        Redux::setSection( $opt_name, $section );
    }
    /*
     * <--- END SECTIONS
     */


    /*
     *
     * YOU MUST PREFIX THE FUNCTIONS BELOW AND ACTION FUNCTION CALLS OR ANY OTHER CONFIG MAY OVERRIDE YOUR CODE.
     *
     */

    /*
    *
    * --> Action hook examples
    *
    */

    // If Redux is running as a plugin, this will remove the demo notice and links
    //add_action( 'redux/loaded', 'remove_demo' );

    // Function to test the compiler hook and demo CSS output.
    // Above 10 is a priority, but 2 in necessary to include the dynamically generated CSS to be sent to the function.
    //add_filter('redux/options/' . $opt_name . '/compiler', 'compiler_action', 10, 3);

    // Change the arguments after they've been declared, but before the panel is created
    //add_filter('redux/options/' . $opt_name . '/args', 'change_arguments' );

    // Change the default value of a field after it's been set, but before it's been useds
    //add_filter('redux/options/' . $opt_name . '/defaults', 'change_defaults' );

    // Dynamically add a section. Can be also used to modify sections/fields
    //add_filter('redux/options/' . $opt_name . '/sections', 'dynamic_section');

    /**
     * This is a test function that will let you see when the compiler hook occurs.
     * It only runs if a field    set with compiler=>true is changed.
     * */
    if ( ! function_exists( 'compiler_action' ) ) {
        function compiler_action( $options, $css, $changed_values ) {
            echo '<h1>The compiler hook has run!</h1>';
            echo "<pre>";
            print_r( $changed_values ); // Values that have changed since the last save
            echo "</pre>";
            //print_r($options); //Option values
            //print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )
        }
    }

    /**
     * Custom function for the callback validation referenced above
     * */
    if ( ! function_exists( 'redux_validate_callback_function' ) ) {
        function redux_validate_callback_function( $field, $value, $existing_value ) {
            $error   = false;
            $warning = false;

            //do your validation
            if ( $value == 1 ) {
                $error = true;
                $value = $existing_value;
            } elseif ( $value == 2 ) {
                $warning = true;
                $value   = $existing_value;
            }

            $return['value'] = $value;

            if ( $error == true ) {
                $field['msg']    = 'your custom error message';
                $return['error'] = $field;
            }

            if ( $warning == true ) {
                $field['msg']      = 'your custom warning message';
                $return['warning'] = $field;
            }

            return $return;
        }
    }

    /**
     * Custom function for the callback referenced above
     */
    if ( ! function_exists( 'redux_my_custom_field' ) ) {
        function redux_my_custom_field( $field, $value ) {
            print_r( $field );
            echo '<br/>';
            print_r( $value );
        }
    }

    /**
     * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
     * Simply include this function in the child themes functions.php file.
     * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
     * so you must use get_template_directory_uri() if you want to use any of the built in icons
     * */
    if ( ! function_exists( 'dynamic_section' ) ) {
        function dynamic_section( $sections ) {
            //$sections = array();
            $sections[] = array(
                'title'  => __( 'Section via hook', 'redux-framework-demo' ),
                'desc'   => __( '<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'redux-framework-demo' ),
                'icon'   => 'el el-paper-clip',
                // Leave this as a blank section, no options just some intro text set above.
                'fields' => array()
            );

            return $sections;
        }
    }

    /**
     * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
     * */
    if ( ! function_exists( 'change_arguments' ) ) {
        function change_arguments( $args ) {
            //$args['dev_mode'] = true;

            return $args;
        }
    }

    /**
     * Filter hook for filtering the default value of any given field. Very useful in development mode.
     * */
    if ( ! function_exists( 'change_defaults' ) ) {
        function change_defaults( $defaults ) {
            $defaults['str_replace'] = 'Testing filter hook!';

            return $defaults;
        }
    }

    /**
     * Removes the demo link and the notice of integrated demo from the redux-framework plugin
     */
    if ( ! function_exists( 'remove_demo' ) ) {
        function remove_demo() {
            // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
            if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
                remove_filter( 'plugin_row_meta', array(
                    ReduxFrameworkPlugin::instance(),
                    'plugin_metalinks'
                ), null, 2 );

                // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
                remove_action( 'admin_notices', array( ReduxFrameworkPlugin::instance(), 'admin_notices' ) );
            }
        }
    }

