<?php 
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}


/* --------------------------------------------------
	Button
-------------------------------------------------- */

function definity_button_shortcode( $atts, $content = null ) {
     
    extract(
        shortcode_atts(
            array(
                'title'     		=> 'Button Title',
                'link'      		=> '',
                'type'     			=> 'btn',
                'size'      		=> '',
                'align'     		=> 'left',
                'bg'				=> '',
                'bg_hover'			=> '',
                'border_color'		=> '',
                'border_bg_hover'	=> '',
                'text_btn_border_color'	=> '',
                'text_color'		=> '',
                'text_hover_color'	=> '',
                'css_class' 		=> '',
            ), 
            $atts
        )
    );

    // Parse link
    $link = ( $link == '||' ) ? '' : $link;
    $link = vc_build_link( $link );
    $a_href = $link['url'];
    $a_title_attr = ( strlen( $link['title'] ) > 0 ) ? ' title="' . esc_attr( $link['title'] ) . '"' : '';
    // $a_target_attr = ( strlen( $link['target'] ) > 0 ) ? 'target="' . esc_attr( $link['target'] ) . '"' : '';
    $target = '';
    if ( strlen( $link['target'] ) ) {
        $target = ' target="_blank"';
    }

    // Button Styles
    static $btn_nbr = 0;
    $btn_style_id = 'd-custom-vc-btn-style-' . $btn_nbr++;

    $btn_bg = '';
    if ( strlen( $bg ) > 0 ) {
        $btn_bg = '#' . $btn_style_id . '{background-color: ' . $bg . ';} ';
    }
    $btn_bg_hover = '';
    if ( strlen( $bg_hover ) > 0 ) {
        $btn_bg_hover = '#' . $btn_style_id . ':hover{background-color: ' . $bg_hover . ';} ';
    }

    $btn_border_color = '';
    if ( strlen( $border_color ) > 0 ) {
        $btn_border_color = '#' . $btn_style_id . '{border-color: ' . $border_color . ';} ';
    }
    $btn_border_bg_hover = '';
    if ( strlen( $border_bg_hover ) > 0 ) {
        $btn_border_bg_hover = '#' . $btn_style_id . ':hover{border-color: ' . $border_bg_hover . ';} #' . $btn_style_id . ':after{background-color: ' . $border_bg_hover . ';} ';
    }

    $btn_text_btn_border_color = '';
    if ( strlen( $text_btn_border_color ) > 0 ) {
        $btn_text_btn_border_color = '#' . $btn_style_id . ':hover{border-color: ' . $text_btn_border_color . ';} ';
    }

    $btn_text_color = '';
    if ( strlen( $text_color ) > 0 ) {
        $btn_text_color = '#' . $btn_style_id . '{color: ' . $text_color . ';} ';
    }
    $btn_text_hover_color = '';
    if ( strlen( $text_hover_color ) > 0 ) {
        $btn_text_hover_color = '#' . $btn_style_id . ':hover{color: ' . $text_hover_color . ';} ';
    }
    $btn_style = '';
    if ( strlen( $btn_bg ) > 0 || strlen( $btn_bg_hover ) > 0 || strlen( $btn_text_color ) > 0 || strlen( $btn_text_hover_color ) > 0 ) {
    	$btn_style = '<style type="text/css" class="custom-vc-btn-style">' . $btn_bg .  $btn_bg_hover . $btn_text_color . $btn_text_hover_color . $btn_border_color . $btn_border_bg_hover . $btn_text_btn_border_color . '</style>';
    }
    // Incremental ID
    $btn_id = 'id="' . $btn_style_id . '"';

    $output = 
    	$btn_style . '
        <div class="btn_align_' . $align . ' ' . $css_class . '">
            <a href="' . esc_url( $a_href ) . '" ' . $btn_id . ' class="' . $type . ' ' . $size . '"' . $a_title_attr . $target . '>' . esc_attr( $title ) . '
            </a>
        </div>';
         
    return $output;
} 
add_shortcode( 'd_button', 'definity_button_shortcode' );


/* --------------------------------------------------
	Blockquote
-------------------------------------------------- */

function definity_blockquote_shortcode( $atts, $content = null ) {
     
    extract(
        shortcode_atts(
            array(
                'quote'		=> '',
                'author'    => '',
                'style'     => '',
                'bg_color'  => '',
                'css_class'	=> '',
            ), 
            $atts
        )
    );

    // Background
    $bg_color_style = '';
    if ( strlen( $bg_color ) > 0 ) {
        $bg_color_style = 'style=" background-color: ' . $bg_color . '";';
    }

    // Style
    $bq_class = '';
    if ( $style === 'alt-blockquote' || strlen( $css_class ) > 0 ) {
        $bq_class = ' class="' . $css_class . ' ' . $style . '"';
    }

    $output = '
        <blockquote' . $bq_class . ' ' . $bg_color_style . '>
            ' . $quote . '
            <footer>
                <cite>' . $author . '</cite>
            </footer>
        </blockquote>';
         
    return $output;
}
add_shortcode( 'd_blockquote', 'definity_blockquote_shortcode' );


/* --------------------------------------------------
	Page Title
-------------------------------------------------- */

function definity_page_title_shortcode( $atts, $content = null ) {
     
    extract(
        shortcode_atts(
            array(
                'pt_title'          => 'Enter Title',
                'pt_subtitle'       => '',
                'pt_size'			=> 'pt-medium',
                'pt_breadcrumbs'    => '1',
                'pt_height'         => '',
                'pt_padding_top'    => '',
                'pt_padding_bottom' => '',

                'pt_parallax'		=> '',
                'pt_title_color'	=> '',
                'pt_subtitle_color'	=> '',
                'pt_bg_color'		=> '',

                'pt_bc_color'		=> '',
                'pt_bc_hover_color'	=> '',
                'pt_bc_active_color'=> '',
                'pt_bc_sep'			=> '',

                'pt_bg_img'			=> '',
                'pt_overlay_bg'		=> '',
                'css_class'	        => '',
            ), 
            $atts
        )
    );


    static $vc_pt_nbr = 0;
    $vc_pt_id = 'vc_pt_id_' . $vc_pt_nbr++;

    // Title Color
    $pt_title_color_style = '';
    if ( strlen( $pt_title_color ) > 0 ) {
        $pt_title_color_style = ' .' . $vc_pt_id .' .bpt-title-color{color: ' . $pt_title_color . ';}';
    }
    // Subtitle
    $pt_subtitle_markup = '';
    if ( strlen( $pt_subtitle ) > 0 ) {
        $pt_subtitle_markup = '<span class="subheading">' . $pt_subtitle . '</span>';
    }
    // Subtitle Color
    $pt_subtitle_color_style = '';
    if ( strlen( $pt_subtitle_color ) > 0 ) {
        $pt_subtitle_color_style = ' .' . $vc_pt_id .' .subheading{color: ' . $pt_subtitle_color . ';}';
    }
    // Bg Color
    $pt_bg_color_style = '';
    if ( strlen( $pt_bg_color ) > 0 ) {
        $pt_bg_color_style = ' .' . $vc_pt_id .'{background-color: ' . $pt_bg_color . ';}';
    }
    // Bg Overlay
    $pt_overlay_bg_style = '';
    if ( strlen( $pt_overlay_bg ) > 0 ) {
        $pt_overlay_bg_style = ' .' . $vc_pt_id .':before{background-color: ' . $pt_overlay_bg . ';}';
    }
    // Bg Image
    $pt_bg_img = wp_get_attachment_image_src( $pt_bg_img, 'full' );
    $bg_image = '';
    if ( strlen( $pt_bg_img[0] ) > 0 ) {
        $bg_image = ' .' . $vc_pt_id .'{background-image: url(' . esc_url( $pt_bg_img[0] ) . '); background-size: cover;}';
    }
    // Parallax
    $pt_parallax_markup = '';
    if ( strlen( $pt_parallax ) == '1' ) {
        $pt_parallax_markup = 'data-stellar-background-ratio="0.4"';
    }
    // Breadcrumb active color 
    $pt_bc_active_color_style = '';
    if ( strlen( $pt_bc_active_color ) > 0 ) {
        $pt_bc_active_color_style = ' .' . $vc_pt_id .' .breadcrumb li.item-current{color: ' . $pt_bc_active_color . ';}';
    }
    // Breadcrumbs Links Color
    $pt_bc_color_style = '';
    if ( strlen( $pt_bc_color ) > 0 ) {
        $pt_bc_color_style = ' .' . $vc_pt_id .' .breadcrumb li a{color: ' . $pt_bc_color . ';}';
    }
    // Breadcrumbs Links Hover Color
    $pt_bc_hover_color_style = '';
    if ( strlen( $pt_bc_hover_color ) > 0 ) {
        $pt_bc_hover_color_style = ' .' . $vc_pt_id .' .breadcrumb li a:hover{color: ' . $pt_bc_hover_color . ';}';
    }
    // Breadcrumbs Links Hover Color
    $pt_bc_sep_style = '';
    if ( strlen( $pt_bc_sep ) > 0 ) {
        $pt_bc_sep_style = ' .' . $vc_pt_id .' .breadcrumb li + li:before{color: ' . $pt_bc_sep . ';}';
    }
    // Breadcrumbs Check
    if ( $pt_breadcrumbs == '1' ) {
        $pt_breadcrumbs = definity_breadcrumbs();
    }
    // Custom Height
    $pt_height_style = '';
    if ( strlen( $pt_height ) > 0 ) {
        $pt_height_style = ' .' . $vc_pt_id .'.page-title{min-height: ' . intval( $pt_height ) . 'px;}';
    }
    // PT Padding Top
    $pt_padding_top_style = '';
    if ( strlen( $pt_padding_top ) > 0 ) {
        $pt_padding_top_style = ' .' . $vc_pt_id .'.page-title{padding-top: ' . intval( $pt_padding_top ) . 'px;}';
    }
    // PT Padding Bottom
    $pt_padding_bottom_style = '';
    if ( strlen( $pt_padding_bottom ) > 0 ) {
        $pt_padding_bottom_style = ' .' . $vc_pt_id .'.page-title{padding-bottom: ' . intval( $pt_padding_bottom ) . 'px;}';
    }

    $pt_custom_style = '';
    if ( 
        strlen( $pt_overlay_bg_style )      > 0 || 
        strlen( $bg_image )                 > 0 || 
        strlen( $pt_bg_color_style )        > 0 || 
        strlen( $pt_title_color_style )     > 0 || 
        strlen( $pt_subtitle_color_style )  > 0 || 
        strlen( $pt_bc_active_color_style ) > 0 || 
        strlen( $pt_bc_color_style )        > 0 || 
        strlen( $pt_bc_hover_color_style )  > 0 || 
        strlen( $pt_bc_sep_style )          > 0 ||
        strlen( $pt_height_style )          > 0 ||
        strlen( $pt_padding_top_style )     > 0 ||
        strlen( $pt_padding_bottom_style )  > 0 ) {
        $pt_custom_style .= '<style type="text/css" class="custom-vc-pt-style">' 
                                . $pt_overlay_bg_style 
                                . $bg_image 
                                . $pt_bg_color_style 
                                . $pt_title_color_style 
                                . $pt_subtitle_color_style 
                                . $pt_bc_active_color_style 
                                . $pt_bc_color_style 
                                . $pt_bc_hover_color_style 
                                . $pt_bc_sep_style 
                                . $pt_height_style 
                                . $pt_padding_top_style 
                                . $pt_padding_bottom_style 
                                . '</style>';
    } // endif

    $output = '';
    $output .= 
    	$pt_custom_style .
        '<header class="page-title vc-pt ' . $vc_pt_id . ' ' . $pt_size . ' ' . $css_class . '" ' . $pt_parallax_markup . '>
        	<div class="bg-overlay">
        		<div class="container">
        			<div class="row">
        				<div class="col-md-6">
        					<h1 class="bpt-title-color">' . $pt_title . '</h1>
        					' . $pt_subtitle_markup . '
        				</div>';
	$output .= 			$pt_breadcrumbs;
    $output .=    	'</div>
        		</div>
        	</div>
        </header>';
         
    return $output;
}
add_shortcode( 'd_page_title', 'definity_page_title_shortcode' );


/* --------------------------------------------------
	Section Heading
-------------------------------------------------- */

function definity_sec_heading_shortcode( $atts, $content = null ) {
     
    extract(
        shortcode_atts(
            array(
                'heading'           => 'Enter Heading',
                'subheading'        => 'Enter optional sub-heading so you can be more descriptive about this section',
                'heading_color'     => '',
                'subheading_color'  => '',
                'bot_margin'        => '',
                'heading_gap'       => '',
                'css_class'	        => '',
            ), 
            $atts
        )
    );

    // Heading color
    $heading_color_style = '';
    if ( strlen( $heading_color ) > 0 ) {
        $heading_color_style = 'style=" color: ' . $heading_color . '";';
    }

    // Subheading color
    $subheading_color_style = '';
    if ( strlen( $subheading_color ) > 0 ) {
        $subheading_color_style = ' color: ' . $subheading_color . ';';
    }

    // Subheading padding top
    $heading_gap_size = '';
    if ( strlen( $heading_gap ) > 0 ) {
        $heading_gap_size = ' margin-top: ' . $heading_gap . 'px;';
    }

    // Subheading Style
    $subheading_style = '';
    if ( strlen( $subheading_color_style ) > 0 || strlen( $heading_gap_size ) > 0 ) {
        $subheading_style = ' style="' . $subheading_color_style . ' ' . $heading_gap_size . '"';
    }

    // Subheading
    $subheading_element = '';
    if ( strlen( $subheading ) > 0 ) {
        $subheading_element = '<span class="subheading" ' . $subheading_style . '>' . $subheading . '</span>';
    }

    // Bottom Spacing
    $bottom_spacing = ( strlen( $bot_margin ) > 0 ) ? ' style="margin-bottom: ' . intval( $bot_margin ) . 'px";' : '';

    $output = '
        <header class="sec-heading ' . $css_class . '" ' . $bottom_spacing . '>
          <h2 ' . $heading_color_style . '>' . $heading . '</h2>
          ' . $subheading_element . '
        </header>';
         
    return $output;
}
add_shortcode( 'd_sec_heading', 'definity_sec_heading_shortcode' );


/* --------------------------------------------------
	Feature Box
-------------------------------------------------- */

function definity_ft_box_shortcode( $atts ) {
     
    extract(
        shortcode_atts(
            array(
            	'width'         => '1/2',
                'title'	        => 'Feature Heading',
                'text' 	        => 'Lorem ipsum dolor sit amet, ete elit consectetur adipisicing. Omnis quae, ipsam impedit eius, vero.',
                'style'         => 'ft-material',
                'layout'        => 'ft-centered',
                'icon'          => 'et-tools',
                'image'         => '',
                'top_offset'    => '',
                'left_offset'   => '',
                'right_offset'  => '',
                'css_class'     => '',
                // style
                'icon_color'    => '',
                'bg_color'      => '',
                'border_color'  => '',
                'txt_color'     => '',
            ), 
            $atts
        )
    );

    // Icon color
    $icon_color_style = '';
    if ( strlen( $icon_color ) > 0 ) {
        $icon_color_style = 'color: ' . $icon_color . ';';
    }

    // Left Offset (added on the icon <span>)
    $left_offset_size = '';
    if ( strlen( $left_offset ) > 0 ) {
        $left_offset_size = 'margin-right: ' . $left_offset . 'px;';
    }

    // Right Offset (added on the icon <span>)
    $right_offset_size = '';
    if ( strlen( $right_offset ) > 0 ) {
        $right_offset_size = 'margin-left: ' . $right_offset . 'px;';
    }

    // Top Offset
    $top_offset = ( strlen( $top_offset ) > 0 ) ? ' style="padding-top: ' . intval( $top_offset ) . 'px";' : '';

    // Bg Color
    $bg_color = ( strlen( $bg_color ) > 0 ) ? ' background-color: ' . $bg_color . '; ' : '';

    // Border Color
    $border_color = ( strlen( $border_color ) > 0 ) ? ' border-color: ' . $border_color . '; ' : '';

    // Icon Custom Style
    $icon_custom_style = '';
    if ( strlen( $icon_color ) > 0 || strlen( $left_offset_size ) > 0 || strlen( $right_offset_size ) > 0 || strlen( $bg_color ) > 0 || strlen( $border_color ) > 0 ) {
        $icon_custom_style = ' style="' . $icon_color_style . ' ' . $left_offset_size . ' ' . $right_offset_size . $bg_color . $border_color . '"';
    }

    // Image or Icon
    $image = wp_get_attachment_image_src( $image, 'full' );
    if ( strlen( $image[0] ) > 0 ) {
        $graphic = '<img src="' . esc_url( $image[0] ) . '" alt="' . esc_attr( $title ) . '" />';
    } else {
        $graphic = '<span class="' . $icon . '" ' . $icon_custom_style . '></span>';
    }

    $output = '
        <div class="' . $layout . ' ' . $css_class . '">
            <div class="ft-item ' . $style . '">
                ' . $graphic . '
                <h5 ' . $top_offset . ' ' . $left_offset . '>' . $title . '</h5>
                <p>' . $text . '</p>
            </div>
        </div>';
         
    return $output;
}
add_shortcode( 'd_ft_box', 'definity_ft_box_shortcode' );


/* --------------------------------------------------
	Feature Hover Box
-------------------------------------------------- */

function definity_ft_box_hover_shortcode( $atts, $content = null ) {
	extract(
        shortcode_atts(
            array(
            	// 'width'             => '1/2',
                'heading'           => 'Heading',
                'hover_heading'     => 'Hover Heading',
                'subheading'	    => 'Subheading',
                'text' 	            => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt',
                'icon'              => 'linea-basic-message-multiple',
                'icon_hover'        => 'linea-basic-message-multiple',
                'icon_color'        => '',
                'icon_hover_color'  => '',
                'bg'                => '',
                'bg_hover'          => '',
                'link'              => '',
                'css_class'         => ''
            ), 
            $atts
        )
    );

    // Icon color
    $icon_color_style = '';
    if ( strlen( $icon_color ) > 0 ) {
        $icon_color_style = ' style="color: ' . $icon_color . ';"';
    }

    // Icon hover - color
    $icon_hover_color_style = '';
    if ( strlen( $icon_hover_color ) > 0 ) {
        $icon_hover_color_style = ' style="color: ' . $icon_hover_color . ';"';
    }

    // Hover Bg
    $bg_hover_style = '';
    if ( strlen( $bg_hover ) > 0 ) {
        $bg_hover_style = ' style="background-color: ' . $bg_hover . ';"';
    }

    // Bg
    $bg_style = '';
    if ( strlen( $bg ) > 0 ) {
        $bg_style = ' style="background-color: ' . $bg . ';"';
    }

    // Button (Link)
    $link = vc_build_link( $link );
    if ( strlen( $link['url'] ) > 0 ) {
        $target = '';
        if ( strlen( $link['target'] ) ) {
            $target = ' target="_blank"';
        }

        $button = '<a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '" ' . $target . '>' . esc_attr( $link['title'] ) . '</a>';
    }

    $output = '
        <div class="ft-boxed-hover ' . $css_class . '">
            <div class="ft-item" ' . $bg_style . '>
                <span class="' . $icon . ' ft-icon" ' . $icon_color_style . '></span>
                <h5>' . $heading . '</h5>
                <h6 class="h-alt">' . $subheading . '</h6>

                <div class="hover-content" ' . $bg_hover_style . '>
                  <span class="' . $icon_hover . ' ft-icon" ' . $icon_hover_color_style . '></span>
                  <span class="ft-heading">' . $hover_heading . '</span>
                  <p>' . $text . '</p>' . 
                  $button . '
                </div>
            </div>
        </div>';
         
    return $output;
}
add_shortcode( 'd_ft_box_hover', 'definity_ft_box_hover_shortcode' );


/* --------------------------------------------------
	Feature Image Hover
-------------------------------------------------- */

function definity_ft_image_hover_shortcode( $atts, $content = null ) {
     
    extract(
        shortcode_atts(
            array(
                'heading'           => 'Element Heading',
                'text' 	            => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore',
                'bg'                => '',
                'link'              => '',
                'p_left'            => '',
                'p_right'           => '',
                'css_class'         => '',
                // style
                'bg_overlay'        => '',
                'bg_hover_overlay'  => '',
                'title_color'       => '',
                'btn_txt_color'           => '',
                'btn_txt_hover_color'     => '',
                'btn_border_color'        => '',
            ), 
            $atts
        )
    );

    $title_color = ( strlen( $title_color ) > 0 ) ? ' style="color: ' . $title_color . ';"' : '';

    $bg = wp_get_attachment_image_src( $bg, 'full' );
    if ( strlen( $bg[0] ) > 0 ) {
        $bg_image = ' style="background-image: url(' . esc_url( $bg[0] ) . ');"';
    }

    // Button style
    static $btn_nbr = 0;
    $btn_style_id = 'd-vc-ft-img-btn-ghost-custom-style-' . $btn_nbr++;
    $bg_id = 'd-vc-ft-img-bg-custom-style-' . $btn_nbr++;

    $btn_txt_color = ( strlen( $btn_txt_color ) > 0 ) ? '#' . $btn_style_id . '{color: ' . $btn_txt_color . ';} ' : '';
    $btn_txt_hover_color = ( strlen( $btn_txt_hover_color ) > 0 ) ? '#' . $btn_style_id . ':hover{color: ' . $btn_txt_hover_color . ';} ' : '';
    $btn_border_color = ( strlen( $btn_border_color ) > 0 ) ? '#' . $btn_style_id . '{border-color: ' . $btn_border_color . ';} ' . '#' . $btn_style_id . ':hover{border-color: ' . $btn_border_color . ';} ' . '#' . $btn_style_id . ':after{background-color: ' . $btn_border_color . ';} ' : '';

    // BG Hover (trans)
    $bg_overlay = ( strlen( $bg_overlay ) > 0 ) ? '#' . $bg_id . '{background-color: ' . $bg_overlay . ';} ' : '';
    $bg_hover_overlay = ( strlen( $bg_hover_overlay ) > 0 ) ? '#' . $bg_id . ':hover{background-color: ' . $bg_hover_overlay . ';} ' : '';

    // Button custom style output
    $btn_custom_style = '';
    if ( strlen( $btn_txt_color ) > 0 || strlen( $btn_txt_hover_color ) > 0 || strlen( $btn_border_color ) > 0 || strlen( $bg_overlay ) > 0 || strlen( $bg_hover_overlay ) > 0 ) {

        $btn_custom_style = '<style type="text/css" class="custom-ft-img-btn-style">' . $btn_txt_color .  $btn_txt_hover_color . $btn_border_color . $bg_overlay . $bg_hover_overlay . '</style>';
    }

    $bg_id = ( strlen( $btn_custom_style ) > 0 ) ? 'id="' . $bg_id . '"' : '';

    // Button (Link)
    $link = vc_build_link( $link );
    if ( strlen( $link['url'] ) > 0 ) {
        $target = ( strlen( $link['target'] ) ) ? ' target="_blank"' : '';
        $btn_id = ( strlen( $btn_custom_style ) > 0 ) ? 'id="' . $btn_style_id . '"' : '';

        $button = '<a ' . $btn_id . ' class="btn-ghost btn-ghost-light ft-button" href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '" ' . $target . '>' . esc_attr( $link['title'] ) . '</a>';
    }

    $p_left_size = '';
    if ( strlen( $p_left ) > 0 ) {
        $p_left_size = 'left: ' . $p_left . 'px;';
    }

    $p_right_size = '';
    if ( strlen( $p_right ) > 0 ) {
        $p_right_size = 'right: ' . $p_right . 'px;';
    }

    // Text content left/right spacing
    $custom_content_padding = '';
    if ( strlen( $p_left_size ) > 0 || strlen( $p_right_size ) > 0 ) {
        $custom_content_padding = ' style="' . $p_left_size . ' ' . $p_right_size . '"';
    }

    $output = '
        ' . $btn_custom_style . '
        <div class="ft-image-hover ' . $css_class . '">
            <div class="ft-item" ' . $bg_image . '>
                <div ' . $bg_id . ' class="bg-overlay">

                    <div class="content-wrapper" ' . $custom_content_padding . '>
                        <h3' . $title_color . '>' . $heading . '</h3>
                        <p>' . $text . '</p>' . 
                        $button . '
                    </div>

                </div>
            </div>
        </div>';
         
    return $output;
} 
add_shortcode( 'd_ft_image_hover', 'definity_ft_image_hover_shortcode' );


/* --------------------------------------------------
	Feature Card
-------------------------------------------------- */

function definity_ft_card_shortcode( $atts, $content = null ) {
     
    extract(
        shortcode_atts(
            array(
                // General
                'title'	        => 'Card Title',
                'icon'          => 'et-tools',
                'image'         => '',
                'link'          => '',
                'css_class'     => '',
                // Style
                'bg_color'      => '',
                'broder_color'  => '',
                'title_color'   => '',
                'txt_color'     => '',
                'link_color'    => '',
                'link_arrow_off'=> '',
                'icon_color'    => '',
                'top_offset'    => '',
            ), 
            $atts
        )
    );

    // Top Offset
    $top_offset_css = ( strlen( $top_offset ) > 0 ) ? ' padding-top: ' . intval( $top_offset ) . 'px; ' : '';

    // Title color
    $title_color_css = '';
    if ( strlen( $title_color ) > 0 ) {
        $title_color_css = ' color: ' . $title_color . ';';
    }


    // Title CSS
    $title_css = '';
    if ( strlen( $top_offset ) > 0 || strlen( $title_color ) > 0 ) {
        $title_css = ' style="'. $top_offset_css . $title_color_css . '"';
    }

    // Link Color
    $link_css = '';
    if ( strlen( $link_color ) > 0 ) {
        $link_css = ' style="color:'. $link_color . ';"';
    }

    // Show Arrow in link.
    $link_arrow = ' <span class="linea-arrows-slim-right"></span>';
    if ( strlen( $link_arrow_off ) == '1'  ) {
        $link_arrow = '';
    }

    // Button (Link)
    $link = vc_build_link( $link );
    $button = '';
    if ( strlen( $link['url'] ) > 0 ) {
        $target = '';
        if ( strlen( $link['target'] ) ) {
            $target = ' target="_blank"';
        }

        $button = '<a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '" ' . $target . $link_css . '>' . esc_attr( $link['title'] ) . $link_arrow . '</a>';
    }

    // Icon color
    $icon_color_style = '';
    if ( strlen( $icon_color ) > 0 ) {
        $icon_color_style = ' style="color: ' . $icon_color . '";';
    }

    // Background color
    $bg_color_css = '';
    if ( strlen( $bg_color ) > 0 ) {
        $bg_color_css = ' background-color:' . $bg_color . ';';
    }
    // Border color
    $broder_color_css = '';
    if ( strlen( $broder_color ) > 0 ) {
        $broder_color_css = ' border-color:' . $broder_color . ';';
    }

    // Background & Box Shadow colors
    $card_color_style = '';
    if ( strlen( $bg_color ) > 0 || strlen( $broder_color ) > 0 ) {
        $card_color_style = ' style="'. $bg_color_css . $broder_color_css . '"';
    }

    // Image or Icon
    $image = wp_get_attachment_image_src( $image, 'full' );
    if ( strlen( $image[0] ) > 0 ) {
        $graphic = '<img src="' . esc_url( $image[0] ) . '" alt="' . esc_attr( $title ) . '" />';
    } else {
        $graphic = '<span class="ft-card-icon ' . $icon . '" ' . $icon_color_style . '></span>';
    }


    $output = '
        <div class="ft-cards ' . $css_class . '">
            <div class="ft-item"' . $card_color_style . '>
                ' . $graphic . '
                <h4 ' . $title_css . '>' . $title . '</h4>' . wpb_js_remove_wpautop( $content, true ) . 
                $button . '
            </div>
        </div>';
         
    return $output;
}
add_shortcode( 'd_ft_card', 'definity_ft_card_shortcode' );


/* --------------------------------------------------
	Feature Card Image
-------------------------------------------------- */

function definity_ft_card_img_shortcode( $atts, $content = null ) {
     
    extract(
        shortcode_atts(
            array(
                // General
                'title'	        => 'Card Heading',
                'image'         => '',
                'link'          => '',
                'css_class'     => '',
                // Style
                'bg_color'      => '',
                'title_color'   => '',
                'link_color'    => '',
            ), 
            $atts
        )
    );

    // Image
    $image = wp_get_attachment_image_src( $image, 'full' );
    if ( strlen( $image[0] ) > 0 ) {
        $image_element = '<img src="' . esc_url( $image[0] ) . '" alt="' . esc_attr( $title ) . '" />';
    }

    // Background
    $bg_color_style = '';
    if ( strlen( $bg_color ) > 0 ) {
        $bg_color_style = 'style="background-color: ' . $bg_color . '";';
    }

    // Button (Link) Color
    $link_color = ( strlen( $link_color ) > 0 ) ? ' style="color: ' . $link_color . ';"' : '';

    // Button (Link)
    $link = vc_build_link( $link );
    if ( strlen( $link['url'] ) > 0 ) {
        $target = '';
        if ( strlen( $link['target'] ) ) {
            $target = ' target="_blank"';
        }

        $button = '<a class="link-btn" href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '" ' . $target . $link_color . '>' . esc_attr( $link['title'] ) . ' <span class="linea-arrows-slim-right"></a>';
    } 

    // Title Color
    $title_color = ( strlen( $title_color ) > 0 ) ? ' style="color: ' . $title_color . ';"' : '';

    $output = '
        <div class="ft-cards-2 ' . $css_class . '">
            <div class="ft-card-item" ' . $bg_color_style . '>' . 
                $image_element . '
                <div class="ft-content">
                    <h5' . $title_color . '>' . $title . '</h5>' . 
    				wpb_js_remove_wpautop( $content, true ) . 
                    $button . '
                </div>
            </div>
        </div>';
         
    return $output;
} 
add_shortcode( 'd_ft_card_img', 'definity_ft_card_img_shortcode' );


/* --------------------------------------------------
	Link Card
-------------------------------------------------- */

function definity_ft_link_card( $atts, $content = null ) {
     
    extract(
        shortcode_atts(
            array(
                'image'	        => '',
                'title'	        => 'Card Heading',
                'desc'	        => 'Short description here...',
                'button_title'	=> '',
                'link'          => '',
                'css_class'     => '',
            ), 
            $atts
        )
    );

    // Image
    $link = vc_build_link( $link );
    if ( strlen( $link['url'] ) > 0 ) {
    	// Image
    	$image = wp_get_attachment_image_src( $image, 'full' );
    	if ( strlen( $image[0] ) > 0 ) {
    	    $image_element = '<img src="' . esc_url( $image[0] ) . '" alt="' . esc_attr( $title ) . '" class="img-responsive" />';
    	}

        $img = '<a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '">' . $image_element . '</a>';
    } else {
    	// Image
    	$image = wp_get_attachment_image_src( $image, 'full' );
    	if ( strlen( $image[0] ) > 0 ) {
    	    $img = '<img src="' . esc_url( $image[0] ) . '" alt="' . esc_attr( $title ) . '" class="img-responsive" />';
    	}
    }

    // Button (Link)
    if ( strlen( $link['url'] ) > 0 ) {
        $target = '';
        if ( strlen( $link['target'] ) ) {
            $target = ' target="_blank"';
        }

        $button = '<a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '" class="btn-ghost btn-small cli-btn" ' . $target . '>' . $button_title . '</span></a>';
    }

    $output = '
        <div class="link-cards-wrapper ' . $css_class . '">
            <div class="link-card">
            	' . $img . '
            	<div class="item-content">
            		<h6>' . $title . '</h6>
            		<p>' . $desc . '</p>
            		' . $button . '
            	</div>
            </div>
        </div>';
         
    return $output;
}
add_shortcode( 'd_ft_link_card', 'definity_ft_link_card' );


/* --------------------------------------------------
    Crypto Card
-------------------------------------------------- */

function definity_crypto_card_shortcode( $atts, $content = null ) {
     
    extract(
        shortcode_atts(
            array(
                // General
                'icon'          => '',
                'image'         => '',
                'title'         => 'Bitcoin',
                'crypto'        => 'bitcoin',
                'fiat'          => '',
                'show_marketcap'    => '',
                'show_price_change' => '',
                'show_alt_fiat'     => '',
                'fiat_alt_1'    => 'EUR',
                'fiat_alt_2'    => 'GBP',
                'fiat_alt_3'    => 'JPY',
                'css_class'     => '',
                // Style
                'bg_color'              => '',
                'shadow_color'          => '',
                'icon_color'            => '',
                'icon_hover_color'      => '',
                'icon_border_color'     => '',
                'icon_hover_bg_color'   => '',
                'icon_anim_border_color'=> '',
                'border_details_color'  => '',
                'title_color'           => '',
                'price_color'           => '',
                'marketcap_color'       => '',
                'alt_title_color'       => '',
                'alt_fiat_color'        => '',
            ), 
            $atts
        )
    );

    // Custom Style
    static $crypto_card_nbr = 0;
    $crypto_card_id = 'd-custom-vc-ft-crypto-card-style-' . $crypto_card_nbr++;

    // BG Color
    $bg_color_css = ( strlen( $bg_color ) > 0 ) ? '#' . $crypto_card_id . ' .ft-item{background-color: ' . $bg_color . ';} ' : '';
    // Box Shadow
    $shadow_color = ( strlen( $shadow_color ) > 0 ) ? '#' . $crypto_card_id . ' .ft-item{box-shadow: 0px 1px 1px ' . $shadow_color . ';} #' .  $crypto_card_id . ' .ft-item:hover{box-shadow: 0 22px 43px ' . $shadow_color . ';} ': '';
    // Icon Color
    $icon_color = ( strlen( $icon_color ) > 0 ) ? '#' . $crypto_card_id . ' .ft-item .ft-crypto-icon .crypto-icon-main{color: ' . $icon_color . ';} ' : '';
    // Icon Color - Hover
    $icon_hover_color = ( strlen( $icon_hover_color ) > 0 ) ? '#' . $crypto_card_id . ' .ft-item:hover .ft-crypto-icon .crypto-icon-main{color: ' . $icon_hover_color . ';} ' : '';
    // Icon Border Color
    $icon_border_color = ( strlen( $icon_border_color ) > 0 ) ? '#' . $crypto_card_id . ' .ft-item .ft-crypto-icon{border-color: ' . $icon_border_color . ';} ' : '';
    // Icon Background Color - Hover
    $icon_hover_bg_color = ( strlen( $icon_hover_bg_color ) > 0 ) ? '#' . $crypto_card_id . ' .ft-item:hover .ft-crypto-icon{background-color: ' . $icon_hover_bg_color . ';} ' : '';
    // Icon Anim. Border Color - Hover
    $icon_border_mask = '';
    $icon_border_mask = ( strlen( $bg_color ) > 0 ) ? $bg_color : 'rgba(255,255,255, 1)';
    $icon_anim_border_color = ( strlen( $icon_anim_border_color ) > 0 ) ? '#' . $crypto_card_id . ' .ft-item:hover .ft-crypto-icon:after{box-shadow:
                        0 0 0 1px ' . $icon_anim_border_color . ',
                        0 0 0 11px ' . $icon_border_mask . ',
                        0 0 0 12px ' . $icon_anim_border_color . ';} #' 
        . $crypto_card_id . ' .ft-item .ft-crypto-icon:after{box-shadow:
                        0 0 0 0px ' . $icon_anim_border_color . ',
                        0 0 0 0px ' . $icon_border_mask . ',
                        0 0 0 0px ' . $icon_anim_border_color . ';}' : '';
    // Title Color
    $title_color = ( strlen( $title_color ) > 0 ) ? '#' . $crypto_card_id . ' .ft-item .ft-title-group h2.ft-crypto-title{color: ' . $title_color . ';} ' : '';
    // Price Color
    $price_color = ( strlen( $price_color ) > 0 ) ? '#' . $crypto_card_id . ' .ft-item .ft-price-group .price-main{color: ' . $price_color . ';} ' : '';
    // Marketcap Color
    $marketcap_color = ( strlen( $marketcap_color ) > 0 ) ? '#' . $crypto_card_id . ' .ft-item .ft-crypto-mc{color: ' . $marketcap_color . ';} ' : '';
    // Alt Fiat Ttile Color
    $alt_title_color = ( strlen( $alt_title_color ) > 0 ) ? '#' . $crypto_card_id . ' .ft-item .ft-alt-fiat-group .alt-fiat-group h5{color: ' . $alt_title_color . ';} ' : '';
    // Alt Fiat Price Color
    $alt_fiat_color = ( strlen( $alt_fiat_color ) > 0 ) ? '#' . $crypto_card_id . ' .ft-item .ft-alt-fiat-group .alt-fiat-group p{color: ' . $alt_fiat_color . ';} ' : '';
    // Border (Details) Color
    $border_details_color = ( strlen( $border_details_color ) > 0 ) ? '#' . $crypto_card_id . ' .ft-item .ft-title-group hr{border-color: ' . $border_details_color . ';} #' .  $crypto_card_id . ' .ft-item .ft-alt-fiat-group{border-color: ' . $border_details_color . ';} ': '';

    // Custom CSS Output
    $crypto_card_custom_css = '';
    if ( 
        strlen( $bg_color_css ) > 0 || 
        strlen( $shadow_color ) > 0 || 
        strlen( $icon_color ) > 0 || 
        strlen( $icon_hover_color ) > 0 || 
        strlen( $icon_border_color ) > 0 ||
        strlen( $icon_hover_bg_color ) > 0 ||
        strlen( $icon_anim_border_color ) > 0 ||
        strlen( $title_color ) > 0 ||
        strlen( $price_color ) > 0 ||
        strlen( $marketcap_color ) > 0 ||
        strlen( $alt_title_color ) > 0 ||
        strlen( $alt_fiat_color ) > 0 ||
        strlen( $border_details_color ) > 0
     ) {
        $crypto_card_custom_css = '<style type="text/css">' 
            . $bg_color_css 
            . $shadow_color 
            . $icon_color 
            . $icon_hover_color 
            . $icon_border_color 
            . $icon_hover_bg_color 
            . $icon_anim_border_color 
            . $title_color 
            . $price_color 
            . $marketcap_color 
            . $alt_title_color 
            . $alt_fiat_color 
            . $border_details_color 
        . '</style>';
    }

    // Image or Icon
    $image = wp_get_attachment_image_src( $image, 'full' );
    if ( strlen( $image[0] ) > 0 ) {
        $graphic = '<img src="' . esc_url( $image[0] ) . '" alt="' . esc_attr( $title ) . '" />';
    } else {
        $graphic = '<span class="crypto-icon-main ' . $icon . '"></span>';
    }

    // Shortcodes
    $crypto_price = '[wpcrypto_text coin="' . $crypto . '" type="price" currency="' . $fiat . '"]';
    $crypto_mc = '[wpcrypto_text coin="' . $crypto . '" type="marketcap" currency="' . $fiat . '"]';
    $crypto_change = '[wpcrypto_text coin="' . $crypto . '" type="change_24h" currency="' . $fiat . '"]';
    $crypto_price_alt_1 = '[wpcrypto_text coin="' . $crypto . '" type="price" currency="' . $fiat_alt_1 . '"]';
    $crypto_price_alt_2 = '[wpcrypto_text coin="' . $crypto . '" type="price" currency="' . $fiat_alt_2 . '"]';
    $crypto_price_alt_3 = '[wpcrypto_text coin="' . $crypto . '" type="price" currency="' . $fiat_alt_3 . '"]';
    
    // price change
    $change_24h_el = '';
    if ( strlen( $show_price_change ) == true ) {
        $change_24h_el = '<span class="change-24">' . do_shortcode( $crypto_change ) . '</span>';
    }
    // marketcap
    $marketcap_el = '';
    if ( strlen( $show_marketcap ) == '1' ) {
        $marketcap_el = '<p class="ft-crypto-mc">MC: ' . do_shortcode( $crypto_mc ) . '</p>';
    }
    // alt fiat group
    $alt_fiat_group = '';
    if ( strlen( $show_alt_fiat ) == true && ( strlen( $fiat_alt_1 ) > 0 || strlen( $fiat_alt_2 ) > 0 ||  strlen( $fiat_alt_3 ) > 0 ) ) {

        $alt_fiat_group_1 = ( strlen( $fiat_alt_1 ) > 0 ) ? 
        '<div class="alt-fiat-group">
            <h5>' . $fiat_alt_1 . '</h5>
            <p>' . do_shortcode( $crypto_price_alt_1 ) . '</p>
        </div>' : '';

        $alt_fiat_group_2 = ( strlen( $fiat_alt_2 ) > 0 ) ? 
        '<div class="alt-fiat-group">
            <h5>' . $fiat_alt_2 . '</h5>
            <p>' . do_shortcode( $crypto_price_alt_2 ) . '</p>
        </div>' : '';

        $alt_fiat_group_3 = ( strlen( $fiat_alt_3 ) > 0 ) ? 
        '<div class="alt-fiat-group">
            <h5>' . $fiat_alt_3 . '</h5>
            <p>' . do_shortcode( $crypto_price_alt_3 ) . '</p>
        </div>' : '';

        $alt_fiat_group = '
            <div class="ft-alt-fiat-group">'
                . $alt_fiat_group_1
                . $alt_fiat_group_2
                . $alt_fiat_group_3 .
            '</div>';
    }
    
    // Incremental ID
    $ft_crypto_card_id = 'id="' . $crypto_card_id . '"';

    $output = '
        ' . $crypto_card_custom_css . '
        <div ' . $ft_crypto_card_id . ' class="ft-crypto-card ' . $css_class . '">
            <div class="ft-item">
                <span class="ft-crypto-icon">
                    ' . $graphic . '
                </span>
                <div class="ft-title-group">
                    <hr>
                    <h2 class="ft-crypto-title">' . $title . '</h2>
                    <hr>
                </div>
                <div class="ft-price-group">
                    <p class="price-main">' . do_shortcode( $crypto_price ) . '</p>
                    ' . $change_24h_el . '
                </div>
                ' . $marketcap_el 
                  . $alt_fiat_group . ' 
            </div>
        </div>';
         
    return $output;
}
add_shortcode( 'd_ft_crypto_card', 'definity_crypto_card_shortcode' );


/* --------------------------------------------------
	Feature Step Numbers
-------------------------------------------------- */

function definity_ft_numbers_shortcode( $atts, $content = null ) {
     
    extract(
        shortcode_atts(
            array(
                'number'        => '01',
                'title'	        => 'First Step',
                'text' 	        => 'Lariatur, excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est',
                'top_offset'    => '',
                'left_offset'   => '',
                'css_class'     => '',
            ), 
            $atts
        )
    );

    // Number Offset
    $top_offset = ( strlen( $top_offset ) > 0 ) ? ' top: ' . intval( $top_offset ) . 'px;' : '';
    $left_offset = ( strlen( $left_offset ) > 0 ) ? ' left: ' . intval( $left_offset ) . 'px;' : '';

    $number_offset = '';
    if ( strlen( $top_offset ) > 0 || strlen( $left_offset ) > 0 ) {
        $number_offset = ' style="' . $top_offset . ' ' . $left_offset . '"';
    }

    $output = '
        <div class="ft-steps-numbers ' . $css_class . '">
            <div class="ft-item">
                <span class="ft-nbr" ' . $number_offset . '>' . $number . '</span>
                <h4>' . $title . '</h4>
                <p>' . $text . '</p>
            </div>
        </div>';
         
    return $output;
}
add_shortcode( 'd_ft_numbers', 'definity_ft_numbers_shortcode' );


/* --------------------------------------------------
	Number Counters
-------------------------------------------------- */

function definity_number_counter_shortcode( $atts, $content = null ) {
     
    extract(
        shortcode_atts(
            array(
                'number'        => '457',
                'title'	        => 'Element Title',
                'title_color'   => '',
                'number_color'  => '',
                'css_class'     => '',
            ), 
            $atts
        )
    );

    // Icon color
    $number_color_style = '';
    if ( strlen( $number_color ) > 0 ) {
        $number_color_style = 'style="color: ' . $number_color . '";';
    }

    // Title color
    $title_color_style = '';
    if ( strlen( $title_color ) > 0 ) {
        $title_color_style = 'style="color: ' . $title_color . '";';
    }

    $output = '
        <div class="number-counters ' . $css_class . '">
            <div class="count-item">
                <span class="count-nbr" ' . $number_color_style . '>' . $number . '</span>
                <span class="count-text" ' . $title_color_style . '>' . $title . '</span>
            </div>
        </div>';
         
    return $output;
} 
add_shortcode( 'd_number_counter', 'definity_number_counter_shortcode' );


/* --------------------------------------------------
	Progress Circle
-------------------------------------------------- */

function definity_progress_circle_shortcode( $atts, $content = null ) {
     
    extract(
        shortcode_atts(
            array(
                'progress'      => '75',
                'title'	        => 'Item Heading',
                'title_color'   => '',
                'icon' 	        => 'linea-basic-star',
                'icon_color'    => '#ececec',
                'line_color'    => '#f8f8f8',
                'line_width'    => '2',
                'css_class'     => '',
            ), 
            $atts
        )
    );

    // Icon color
    $icon_color_style = '';
    if ( strlen( $icon_color ) > 0 ) {
        $icon_color_style = 'style="color: ' . $icon_color . '";';
    }

    // Title color
    $title_color_style = '';
    if ( strlen( $title_color ) > 0 ) {
        $title_color_style = 'style="color: ' . $title_color . '";';
    }

    $output = '
        <div class="circles-counters ' . $css_class . '">
            <div class="circle-item">
                <div class="chart" data-line-width="' . $line_width . '" data-bar-color="' . $line_color . '" data-percent="' . $progress . '">
                    <span class="circle-icon ' . $icon . '" ' . $icon_color_style . '></span>
                </div>
                <span class="circle-text" ' . $title_color_style . '>' . $title . '</span>
            </div>
        </div>';
         
    return $output;
}
add_shortcode( 'd_progress_circle', 'definity_progress_circle_shortcode' );


/* --------------------------------------------------
	Pricing Table
-------------------------------------------------- */

function definity_pricing_table_shortcode( $atts, $content = NULL ) {
     
    extract(
        shortcode_atts(
            array(
                // General
                'title'         => 'Starter',
                'subtitle'	    => 'Get the job done',
                'price'         => '',
                'currency'      => '',
                'interval'      => '',
                'featured'      => '',
                // 'content'       => '',
                'link'          => '',
                'css_class'     => '',
                // Style
                'bg_color'      => '',
                // 'accent_color'  => '',
                'title_color'   => '',
                'sep_color'     => '',
                'price_color'   => '',
                'price_info_color'          => '',
                'subtitle_color'            => '',
                'ft_banner_color'           => '',
                'ft_banner_content_color'   => '',
                // button
                'btn_style'                    => 'btn',
                'btn_size'                     => '',
                'pt_btn_bg'                    => '',
                'pt_btn_bg_hover'              => '',
                'pt_btn_border_color'          => '',
                'pt_btn_border_bg_hover'       => '',
                'pt_btn_text_color'            => '',
                'pt_btn_text_hover_color'      => '',
                'pt_btn_text_border_color'     => '',
            ), 
            $atts
        )
    );

    // Button style
    static $btn_nbr = 0;
    $btn_style_id = 'd-vc-pt-btn-custom-style-' . $btn_nbr++;

    $pt_btn_bg = ( strlen( $pt_btn_bg ) > 0 ) ? '#' . $btn_style_id . '{background-color: ' . $pt_btn_bg . ';} ' : '';
    $pt_btn_bg_hover = ( strlen( $pt_btn_bg_hover ) > 0 ) ? '#' . $btn_style_id . ':hover{background-color: ' . $pt_btn_bg_hover . ';} ' : '';
    $pt_btn_border_color = ( strlen( $pt_btn_border_color ) > 0 ) ? '#' . $btn_style_id . '{border-color: ' . $pt_btn_border_color . ';} ' : '';
    $pt_btn_border_bg_hover = ( strlen( $pt_btn_border_bg_hover ) > 0 ) ? '#' . $btn_style_id . ':hover{border-color: ' . $pt_btn_border_bg_hover . ';} #' . $btn_style_id . ':after{background-color: ' . $pt_btn_border_bg_hover . ';} ' : '';
    $pt_btn_text_border_color = ( strlen( $pt_btn_text_border_color ) > 0 ) ? '#' . $btn_style_id . ':hover{border-color: ' . $pt_btn_text_border_color . ';} ' : '';
    $pt_btn_text_color = ( strlen( $pt_btn_text_color ) > 0 ) ? '#' . $btn_style_id . '{color: ' . $pt_btn_text_color . ';} ' : '';
    $pt_btn_text_hover_color = ( strlen( $pt_btn_text_hover_color ) > 0 ) ? '#' . $btn_style_id . ':hover{color: ' . $pt_btn_text_hover_color . ';} ' : '';

    // Button custom style output
    $btn_custom_style = '';
    if ( strlen( $pt_btn_bg ) > 0 || strlen( $pt_btn_bg_hover ) > 0 || strlen( $pt_btn_border_color ) > 0 || strlen( $pt_btn_border_bg_hover ) > 0 || strlen( $pt_btn_text_color ) > 0 || strlen( $pt_btn_text_hover_color ) > 0 || strlen( $pt_btn_text_border_color ) > 0 ) {

        $btn_custom_style = '<style type="text/css" class="custom-pt-btn-style">' . $pt_btn_bg .  $pt_btn_bg_hover . $pt_btn_border_color . $pt_btn_border_bg_hover . $pt_btn_text_color . $pt_btn_text_hover_color . $pt_btn_text_border_color . '</style>';
    }

    // Button (Link)
    $link = vc_build_link( $link );
    if ( strlen( $link['url'] ) > 0 ) {

        $target = ( strlen( $link['target'] ) ) ? ' target="_blank"' : '';
        $btn_style_id = ( strlen( $btn_style_id ) > 0 ) ? 'id="' . $btn_style_id . '" ' : '';

        $button = '<a ' . $btn_style_id . ' class="' . $btn_style . ' ' . $btn_size . '" href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '" '  . $target .'>' . esc_attr( $link['title'] ) . '</a>';
    }

    // Background color
    $bg_color = ( strlen( $bg_color ) > 0 ) ? ' style="background-color: ' . $bg_color . ';"' : '';

    // Title color
    $title_color = ( strlen( $title_color ) > 0 ) ? ' style="color: ' . $title_color . ';"' : '';

    // Subtitle color
    $subtitle_color = ( strlen( $subtitle_color ) > 0 ) ? ' style="color: ' . $subtitle_color . ';"' : '';

    // Sep/Border color
    $sep_color = ( strlen( $sep_color ) > 0 ) ? ' style="border-color: ' . $sep_color . ';"' : '';

    // Price color
    $price_color = ( strlen( $price_color ) > 0 ) ? ' style="color: ' . $price_color . ';"' : '';

    // Price Info color
    $price_info_color = ( strlen( $price_info_color ) > 0 ) ? ' style="color: ' . $price_info_color . ';"' : '';
    // Currency
    $currency_element = '';
    if ( strlen( $currency ) > 0 ) {
        $currency_element = '<span class="currency"' . $price_info_color . '>' . $currency . '</span>';
    }
    // Interval
    $interval_element = '';
    if ( strlen( $interval ) > 0 ) {
        $interval_element = '<span class="type"' . $price_info_color . '>' . $interval . '</span>';
    }

    // Featured Banner Bg
    $ft_banner_color = ( strlen( $ft_banner_color ) > 0 ) ? ' style="background-color: ' . $ft_banner_color . ';"' : '';
    // Featured Banner Content Color
    $ft_banner_content_color = ( strlen( $ft_banner_content_color ) > 0 ) ? ' style="color: ' . $ft_banner_content_color . ';"' : '';
    // Featured Banner - markup
    $featured_el = '';
    if ( strlen( $featured ) == true ) {
        $featured_el = '
            <div class="banner" ' . $ft_banner_color . '>
                <span class="star"><i class="fa fa-star" ' . $ft_banner_content_color . '></i></span>
            </div>';
    }


    $output = '
        ' . $btn_custom_style . '
        <div class="pricing-table ' . $css_class . '">
            <div class="p-table ' . $featured . '" ' . $bg_color . '>

                ' . $featured_el . '

                <h4 ' . $title_color . '>' . $title . '</h4>
                <div class="price">
                    ' . $currency_element . '
                    <span class="value"' . $price_color . '>' . $price . '</span>
                    ' . $interval_element . '
                </div>
                <p class="desc"' . $subtitle_color . '>' . $subtitle . '</p>
                <hr' . $sep_color . '>
                
                ' . wpb_js_remove_wpautop( $content, true ) . '
                <hr' . $sep_color . '>
                
                ' . $button . '
            </div>
        </div>';
         
    return $output;
} 
add_shortcode( 'd_pricing_table', 'definity_pricing_table_shortcode' );


/* --------------------------------------------------
	Team Member
-------------------------------------------------- */

function definity_team_member_shortcode( $atts, $content = NULL ) {
     
    extract(
        shortcode_atts(
            array(
                'layout'        => '',
                'fc_layout_type'=> '',
                'name'          => 'Jonathan Doe',
                'position'	    => 'CEO, Facebook',
                'image'         => '',
                'cta_title'		=> '',
                // 'content'       => '',
                'no_social'  	=> '',
                'social_links'  => '',
                'sp_facebook'   => '',
                'sp_instagram'  => '',
                'sp_twitter'    => '',
                'sp_linkedin'   => '',
                'sp_dribbble'   => '',
                'sp_behance'    => '',
                'sp_youtube'    => '',
                'sp_googleplus' => '',
                'sp_rss'        => '',
                // options for cta join
                'bg_icon'       => 'fa fa-user',
                'height'        => '',
                'link'          => '',
                'name_link'     => '',
                'css_class'     => '',
                // style
                'bg_color'          => '',
                'card_bg_color'     => '',
                'icon_color'        => '',
                'title_color'       => '',
                'subtitle_color'    => '',
                's_icons_color'     => '',
            ), 
            $atts
        )
    );

    // Image
    $image = wp_get_attachment_image_src( $image, 'full' );
    if ( strlen( $image[0] ) > 0 ) {
        $image_element = '<img class="img-responsive" src="' . esc_url( $image[0] ) . '" alt="' . esc_attr( $name ) . '" />';
    }

    // Icon color
    $icon_color_style = '';
    if ( strlen( $icon_color ) > 0 ) {
        $icon_color_style = ' style="color: ' . $icon_color . '";';
    }

    // Bg color
    $bg_color_style = '';
    if ( strlen( $bg_color ) > 0 ) {
        $bg_color_style = ' background: ' . $bg_color . ';';
    }

    // Card Bg color
    $card_bg_color = ( strlen( $card_bg_color ) > 0 ) ? ' style="background-color: ' . $card_bg_color . '";' : '';

    // Title color
    $title_color = ( strlen( $title_color ) > 0 ) ? ' style="color: ' . $title_color . '";' : '';

    // Sub-Title color
    $subtitle_color = ( strlen( $subtitle_color ) > 0 ) ? ' style="color: ' . $subtitle_color . '";' : '';

    // Social Icons color
    $s_icons_color = ( strlen( $s_icons_color ) > 0 ) ? ' style="color: ' . $s_icons_color . '";' : '';

    // Item height
    $height_size = '';
    if ( strlen( $height ) > 0 ) {
        $height_size = ' height: ' . $height . ';';
    }

    // T-Image Styles
    $timg_style = '';
    if ( strlen( $bg_color_style ) > 0 || strlen( $height_size ) > 0 ) {
        $timg_style = ' style="' . $bg_color_style . ' ' . $height_size . '";';
    }

    // Button (Link)
    $link = vc_build_link( $link );
    if ( strlen( $link['url'] ) > 0 ) {
        $target = '';
        if ( strlen( $link['target'] ) ) {
            $target = ' target="_blank"';
        }
        $button = '<a class="btn btn-small" href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '" ' . $target . '>' . esc_attr( $link['title'] ) . '</a>';
    } 

    // Flip card link
    $name_link = vc_build_link( $name_link );
    if ( strlen( $name_link['url'] ) > 0 ) {
        $target = '';
        if ( strlen( $name_link['target'] ) ) {
            $target = ' target="_blank"';
        }
        $name_link_el = '<a href="' . esc_url( $name_link['url'] ) . '" title="' . $name . '" ' . $target . '>' . $name . '</a>';
        
    } else {
        $name_link_el = $name;
    }

    // Show social Links
    if ( strlen( $social_links ) > 0 ) {

        $social_profiles = array(
            'facebook'      => array( 'title' => 'Facebook', 'url'  => $sp_facebook ),
            'instagram'     => array( 'title' => 'Instagram', 'url' => $sp_instagram ),
            'twitter'       => array( 'title' => 'Twitter', 'url'   => $sp_twitter ),
            'linkedin'      => array( 'title' => 'LinkedIn', 'url'  => $sp_linkedin ),
            'google-plus'   => array( 'title' => 'Google+', 'url'   => $sp_googleplus ),
            'dribbble'      => array( 'title' => 'Dribbble', 'url'  => $sp_dribbble ),
            'behance'       => array( 'title' => 'Behance', 'url'   => $sp_behance ),
            'youtube'       => array( 'title' => 'YouTube', 'url'   => $sp_youtube ),
            'rss-square'    => array( 'title' => 'RSS', 'url'       => $sp_rss )
        );

        $sp_output = '';
        foreach ( $social_profiles as $service => $details ) {
            if ( $details['url'] !== '' ) {
                 $sp_output .= '<li><a href="' . esc_url( $details['url'] ) . '" target="_blank" title="' . $details['title'] . '"><i class="fa fa-' . $service . '"></i></a></li>';
            }
        }
        $social_links_html = '<ul class="social-links" ' . $s_icons_color . '>' . $sp_output . '</ul>';
    }

    switch ( $layout ) {
    	case 'tm_2':
        	$output = '
        	<div class="team-member-img ' . $css_class . '">
        		<div class="t-item ' . $no_social . '"' . $card_bg_color . '>
        			<div class="t-image">
        				' . $image_element . '
        			</div>
        			<div class="t-info">
        				<h4 class="t-name"' . $title_color . '>' . $name . '</h4>
        				<span class="t-role"' . $subtitle_color . '>' . $position . '</span>
        				' . $social_links_html . '
        			</div>
        		</div>
        	</div>';
        break;

        case 'tm_3':
	        $output = '
	        <div class="t-join ' . $css_class . '">
	        	<div class="t-image" ' . $timg_style . '>
	        		<i class="' . $bg_icon . ' bg-icon" ' . $icon_color_style . '></i>
	        		<div class="t-description">
	        			' . wpb_js_remove_wpautop( $content, true ) . '
	        		</div>
	        	</div>
	        	<div class="t-info">
	        		<h4 class="t-name">' . $cta_title . '</h4>
	        		<span class="t-role">' . $position . '</span>
	        		' . $button . ' 
	        	</div>
	        </div>';
        break;

        case 'tm_4':
            $output = '
            <div class="t-flip-card ' . $fc_layout_type . $css_class . '">
                <div class="t-flipper">
                    <div class="tfc-front">
                        <div class="t-image">
                            ' . $image_element . '
                        </div>
                        <div class="t-info">
                            <h4 class="t-name">' . $name . '</h4>
                            <span class="t-role">' . $position . '</span>
                        </div>
                    </div>
                    <div class="tfc-back">
                        <div class="content-wrapper">
                            ' . wpb_js_remove_wpautop( $content, true ) . '
                            <div class="t-info">
                                <h4 class="t-name">' . $name_link_el . '</h4>
                                <span class="t-role">' . $position . '</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>';
        break;
    	
    	default:
        	$output = '
        	<div class="team-member ' . $css_class . '">
        		<div class="t-item">
        			<div class="t-image">
        				' . $image_element . '
        				<div class="t-description">
        					<div class="content-wrapper">
        						' . wpb_js_remove_wpautop( $content, true ) . '
        					</div>
        				</div>
        			</div>
        			<div class="t-info">
        				<h4 class="t-name">' . $name . '</h4>
        				<span class="t-role">' . $position . '</span>
        				' . $social_links_html . '
        			</div>
        		</div>
        	</div>';
    	break;
    }
         
    return $output;
}
add_shortcode( 'd_team_member', 'definity_team_member_shortcode' );


/* --------------------------------------------------
	Testimonials Card
-------------------------------------------------- */

function definity_testimonial_cards_shortcode( $atts, $content = NULL ) {
     
    extract(
        shortcode_atts(
            array(
                // General
                'image'         => '',
                'author'	    => 'Jon Doe',
                'company' 	    => 'ACME INC',
                'testimonial'   => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae',
                'css_class'         => '',
                // Style
                'border_color'      => '',
                'txt_color'         => '',
                'author_color'      => '',
                'company_color'     => '',
                'icon_color'        => '',
                'img_border_color'  => '',
                'bg_color'          => '',
            ), 
            $atts
        )
    );

    // Text Color
    $txt_color = ( strlen( $txt_color ) > 0 ) ? ' style=" color: ' . $txt_color . '"' : '';

    // Author Color
    $author_color = ( strlen( $author_color ) > 0 ) ? ' style=" color: ' . $author_color . '"' : '';

    // Info/Company Color
    $company_color = ( strlen( $company_color ) > 0 ) ? ' style=" color: ' . $company_color . '"' : '';
    $company = ( strlen( $company ) > 0 ) ? '<span' . $company_color . '>' . $company . '</span>' : '';

    // Icon Color
    $icon_color = ( strlen( $icon_color ) > 0 ) ? ' style=" color: ' . $icon_color . '"' : '';

    // Image Border Color
    $img_border_color = ( strlen( $img_border_color ) > 0 ) ? ' style=" border-color: ' . $img_border_color . '"' : '';
    // Image
    $image = wp_get_attachment_image_src( $image, 'full' );
    if ( strlen( $image[0] ) > 0 ) {
        $image_element = '<img src="' . esc_url( $image[0] ) . '" alt="' . esc_attr( $author ) . '" ' . $img_border_color . ' />';
    }

    // Card Background Color
    $bg_color = ( strlen( $bg_color ) > 0 ) ? ' style=" background-color: ' . $bg_color . '"' : '';


    // START OF 'CSS style element insert'
    static $tcard_nbr = 0;
    $tcard_style_id = 'd-vc-tcard-custom-style-' . $tcard_nbr++;

    // Sep/Border Color
    $border_color = ( strlen( $border_color ) > 0 ) ? '#' . $tcard_style_id . ' .t-item blockquote p:before{border-color: ' . $border_color . ';} #' . $tcard_style_id . ' .t-item blockquote p:after{border-color: ' . $border_color . ';}' : '';

    $tcard_style = '';
    if ( strlen( $border_color ) > 0 ) {
        $tcard_style = '<style type="text/css">' . $border_color . '</style>';
    }
    // Incremental ID
    $tcard_id = 'id="' . $tcard_style_id . '"';
    // END OF 'CSS style element insert'


    $output = '
        ' . $tcard_style . '
        <div ' . $tcard_id . ' class="testimonial-cards ' . $css_class . '">
            <div class="t-item"' . $bg_color . '>' . 
                $image_element . '
                <blockquote>
                    <p' . $txt_color . '>' . $testimonial . '</p>
                    <footer>
                        <cite' . $author_color . '>' . $author . ' ' . $company . '</cite>
                    </footer>
                </blockquote>
                <span class="t-icon et-quote"' . $icon_color . '></span>
            </div>
        </div>';
         
    return $output;
} 
add_shortcode( 'd_testimonial_cards', 'definity_testimonial_cards_shortcode' );


/* --------------------------------------------------
	Testimonials Slider
-------------------------------------------------- */

function definity_testimonials_slider_shortcode( $atts, $content = NULL ) {
     
    extract(
        shortcode_atts(
            array(
                // General
                'arrows'            => '',
                'arrows_hover'      => '',
                'autoplay'          => '',
                'autoplay_speed'    => '',
                'animation'         => '',
                'speed'             => '',
                'adaptive_height'   => '',
                'css_class'         => '',
                // Style
                't_bg'                  => '',
                'nav_border_color'      => '',
                'nav_hover_border_color'=> '',
                'nav_hover_bg_color'    => '',
                'arrow_color'           => '',
                'arrow_hover_color'     => '',
            ), 
            $atts
        )
    );

    // Arrows
    $d_arrows = '';
    if ( strlen( $arrows ) > 0 ) {
        $d_arrows = 'data-arrows="' . $arrows . '"';
    }
    // Arrows hover
    $d_arrows_hover = '';
    if ( strlen( $arrows_hover ) == '1'  ) {
        $d_arrows_hover = 'arrows-hover-only ';
    }
    // Speed
    $d_speed = '';
    if ( strlen( $speed ) > 0 ) {
        $d_speed = 'data-speed="' . $speed . '"';
    }
    // Autoplay
    $d_autoplay = '';
    if ( strlen( $autoplay ) > 0 ) {
        $d_autoplay = ' data-autoplay="' . $autoplay . '"';
    }
    // Autoplay speed
    $d_autoplay_speed = '';
    if ( strlen( $autoplay_speed ) > 0 ) {
        $d_autoplay_speed = ' data-autoplay_speed="' . $autoplay_speed . '"';
    }
    // Fade
    $d_animation = '';
    if ( strlen( $animation ) > 0 ) {
        $d_animation = ' data-animation="' . $animation . '"';
    }
    // Adaptive height
    $d_adaptive_height = '';
    if ( strlen( $adaptive_height ) > 0 ) {
        $d_adaptive_height = ' data-adaptive_height="' . $adaptive_height . '"';
    }

    // Data Attributes
    $slick_data_atts = '';
    if ( strlen( $d_speed ) > 0 || strlen( $d_autoplay ) > 0 || strlen( $autoplay_speed ) > 0 || strlen( $d_animation ) > 0 || strlen( $d_adaptive_height ) > 0 || strlen( $d_arrows ) > 0 ) {
        $slick_data_atts = $d_speed . $d_autoplay . $d_autoplay_speed . $d_animation . $d_adaptive_height . $d_arrows;
    }

    // Background Color
    $t_bg = ( strlen( $t_bg ) > 0 ) ? ' .t-slider-wrapper{background-color:' . $t_bg . ';}' : '';

    // Nav Border Color
    $nav_border_color = ( strlen( $nav_border_color ) > 0 ) ? ' .t-slider .t-slider-nav{border-color:' . $nav_border_color . ';}' : '';

    // Nav Hover Border Color
    $nav_hover_border_color = ( strlen( $nav_hover_border_color ) > 0 ) ? ' .t-slider .t-slider-nav:hover{border-color:' . $nav_hover_border_color . ';}' : '';

    // Nav Background Hover Color
    $nav_hover_bg_color = ( strlen( $nav_hover_bg_color ) > 0 ) ? ' .t-slider .t-slider-nav:hover{background-color:' . $nav_hover_bg_color . ';}' : '';

    // Nav Arrow Color
    $arrow_color = ( strlen( $arrow_color ) > 0 ) ? ' .t-slider .t-slider-nav span{color:' . $arrow_color . ';}' : '';

    // Nav Arrow Hover Color
    $arrow_hover_color = ( strlen( $arrow_hover_color ) > 0 ) ? ' .t-slider .t-slider-nav:hover > span{color:' . $arrow_hover_color . ';}' : '';

    // Background & Box Shadow colors
    $arrows_css = '';
    if ( strlen( $t_bg ) > 0 || strlen( $nav_border_color ) > 0 || strlen( $nav_hover_border_color ) > 0 || strlen( $nav_hover_bg_color ) > 0 || strlen( $arrow_color ) > 0 || strlen( $arrow_hover_color ) > 0 ) {
        $arrows_css = '<style>' . $t_bg . $nav_border_color . $nav_hover_border_color . $nav_hover_bg_color . $arrow_color . $arrow_hover_color . '</style>';
    }


    $output = '
    ' . $arrows_css . '
    <div class="t-slider-wrapper">
        <div class="t-slider ' . $d_arrows_hover . '' . $css_class . '" ' . $slick_data_atts . '>' . do_shortcode( $content ) . '</div>
    </div>';
    

    return $output;
} 
add_shortcode( 'd_testimonials_slider', 'definity_testimonials_slider_shortcode' );


function definity_testimonial_slide_shortcode( $atts, $content = NULL ) {
     
    extract(
        shortcode_atts(
            array(
                // General
            	'author'		=> '',
            	'company'		=> '',
                'icon_off'      => '',
                'css_class'     => '',
                // Style
                'name_color'    => '',
                'company_color' => '',
                'icon_color'    => '',
            ), 
            $atts
        )
    );

    // Name Color
    $name_color = ( strlen( $name_color ) > 0 ) ? ' style="color: ' . $name_color . ';"; ' : '';

    // Company Color
    $company_color = ( strlen( $company_color ) > 0 ) ? ' style="color: ' . $company_color . ';"; ' : '';

    // Icon Color
    $icon_color = ( strlen( $icon_color ) > 0 ) ? ' style="color: ' . $icon_color . ';"; ' : '';

    // Hide Icon
    $quotes_icon = ( strlen( $icon_off ) == '1'  ) ? '' : '<span class="et-quote t-type"' . $icon_color . '></span>';

    // CSS Class
    $css_class = ( strlen( $css_class ) > 0  ) ? ' class="' . $css_class . '"' : ''; 

    $output = '<blockquote' . $css_class . '>' . 
    			wpb_js_remove_wpautop( $content, true ) . '
                ' . $quotes_icon . '
		        <footer>
		        	<cite>
		        		<h5 class="h-alt"' . $name_color . '>' . $author . '</h5>
		        		<h5' . $company_color . '>' . $company . '</h5>
		        	</cite>
		        </footer>
		    </blockquote>';

    return $output;
} 
add_shortcode( 'd_testimonial_slide', 'definity_testimonial_slide_shortcode' );


/* --------------------------------------------------
	Logos Slider
-------------------------------------------------- */

function definity_logos_slider_shortcode( $atts, $content = NULL ) {
     
    extract(
        shortcode_atts(
            array(
                // General
                'autoplay'          => '',
                'autoplay_speed'    => '',
                'speed'             => '',
                'slides_to_show'    => '5',
                'slides_to_scroll'  => '1',
                'adaptive_height'   => '',
                'css_class'         => '',
                // Style
                'ls_bg'             => '',
                'ls_padding_top'    => '',
                'ls_padding_bottom' => '',
            ), 
            $atts
        )
    );

    // Speed
    $d_speed = '';
    if ( strlen( $speed ) > 0 ) {
        $d_speed = 'data-speed="' . $speed . '"';
    }
    // Autoplay
    $d_autoplay = '';
    if ( strlen( $autoplay ) > 0 ) {
        $d_autoplay = ' data-autoplay="' . $autoplay . '"';
    }
    // Autoplay speed
    $d_autoplay_speed = '';
    if ( strlen( $autoplay_speed ) > 0 ) {
        $d_autoplay_speed = ' data-autoplay_speed="' . $autoplay_speed . '"';
    }
    // Slides to show
    $d_slides_to_show = '';
    if ( strlen( $slides_to_show ) > 0 ) {
        $d_slides_to_show = ' data-slides_to_show="' . $slides_to_show . '"';
    }
    // Slides to scroll
    $d_slides_to_scroll = '';
    if ( strlen( $slides_to_scroll ) > 0 ) {
        $d_slides_to_scroll = ' data-slides_to_scroll="' . $slides_to_scroll . '"';
    }
    // Adaptive height
    $d_adaptive_height = '';
    if ( strlen( $adaptive_height ) > 0 ) {
        $d_adaptive_height = ' data-adaptive_height="' . $adaptive_height . '"';
    }

    // Data Attributes
    $slick_data_atts = '';
    if ( strlen( $d_speed ) > 0 || strlen( $d_autoplay ) > 0 || strlen( $autoplay_speed ) > 0 || strlen( $d_slides_to_show ) > 0 || strlen( $d_slides_to_scroll ) > 0 || strlen( $d_adaptive_height ) > 0 ) {
        $slick_data_atts = $d_speed . $d_autoplay . $d_autoplay_speed . $d_slides_to_show . $d_slides_to_scroll . $d_adaptive_height;
    }


    // Background Color
    $ls_bg = ( strlen( $ls_bg ) > 0 ) ? ' .t-clients-wrapper{background-color: ' . $ls_bg . ';} ' : '';
    // Padding Top
    $ls_padding_top = ( strlen( $ls_padding_top ) > 0 ) ? ' .t-clients-wrapper{padding-top: ' . intval( $ls_padding_top ) . 'px;} ' : '';
    // Padding Bottom
    $ls_padding_bottom = ( strlen( $ls_padding_bottom ) > 0 ) ? ' .t-clients-wrapper{padding-bottom: ' . intval( $ls_padding_bottom ) . 'px;} ' : '';

    // Background & Box Shadow colors
    $ls_wrapper_css = '';
    if ( strlen( $ls_bg ) > 0 || strlen( $ls_padding_top ) > 0 || strlen( $ls_padding_bottom ) > 0 ) {
        $ls_wrapper_css = '<style>' . $ls_bg . $ls_padding_top . $ls_padding_bottom . '</style>';
    }


    $output = '
    ' . $ls_wrapper_css . '
    <div class="t-clients-wrapper">
        <ul class="t-clients clients-slider ' . $css_class . '" ' . $slick_data_atts . '>
			' . do_shortcode( $content ) . 
		'</ul>
    </div>';

    return $output;
} 
add_shortcode( 'd_logos_slider', 'definity_logos_slider_shortcode' );


function definity_logo_slide_shortcode( $atts, $content = NULL ) {
     
    extract(
        shortcode_atts(
            array(
                'image'			=> '',
                'link' 			=> '',
                'css_class'     => ''
            ), 
            $atts
        )
    );

    // Button (Link)
    $link = vc_build_link( $link );
    if ( strlen( $link['url'] ) > 0 ) {
        $target = '';
        if ( strlen( $link['target'] ) ) {
            $target = ' target="_blank"';
        }

    	// Image
    	$image = wp_get_attachment_image_src( $image, 'full' );
    	if ( strlen( $image[0] ) > 0 ) {
            $image_title = get_the_title( $image[0] );
    	    $image_element = '<img src="' . esc_url( $image[0] ) . '" alt="' . esc_attr( $image_title ) . '" />';
    	}

        $img = '<a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '" ' . $target . '>' . $image_element . '</a>';
    } else {
    	// Image
    	$image = wp_get_attachment_image_src( $image, 'full' );
    	if ( strlen( $image[0] ) > 0 ) {
            $image_title = get_the_title( $image[0] );
    	    $img = '<img src="' . esc_url( $image[0] ) . '" alt="' . esc_attr( $image_title ) . '" />';
    	}
    }

    $output = '<li>' . $img . '</li>';

    return $output;
} 
add_shortcode( 'd_logo_slide', 'definity_logo_slide_shortcode' );


/* --------------------------------------------------
	Single Image Slider
-------------------------------------------------- */

function definity_single_img_slider_shortcode( $atts, $content = NULL ) {
     
    extract(
        shortcode_atts(
            array(
            	'arrows'            => '',
            	'dots'            	=> 'false',
            	'arrows_hover'      => '',
                'autoplay'          => '',
                'autoplay_speed'    => '',
                'speed'             => '',
                'slides_to_show'    => '1',
                'slides_to_scroll'  => '1',
                'animation'			=> '',
                'adaptive_height'   => 'true',
                'css_class'         => ''
            ), 
            $atts
        )
    );

    // Arrows
    $d_arrows = '';
    if ( strlen( $arrows ) > 0 ) {
        $d_arrows = 'data-arrows="' . $arrows . '"';
    }
    // Arrows hover
    $d_arrows_hover = '';
    if ( strlen( $arrows_hover ) == '1'  ) {
        $d_arrows_hover = 'arrows-hover-only ';
    }
    // Dots
    $d_dots = '';
    if ( strlen( $dots ) > 0 ) {
        $d_dots = 'data-dots="' . $dots . '"';
    }
    // Speed
    $d_speed = '';
    if ( strlen( $speed ) > 0 ) {
        $d_speed = 'data-speed="' . $speed . '"';
    }
    // Autoplay
    $d_autoplay = '';
    if ( strlen( $autoplay ) > 0 ) {
        $d_autoplay = ' data-autoplay="' . $autoplay . '"';
    }
    // Autoplay speed
    $d_autoplay_speed = '';
    if ( strlen( $autoplay_speed ) > 0 ) {
        $d_autoplay_speed = ' data-autoplay_speed="' . $autoplay_speed . '"';
    }
    // Slides to show
    $d_slides_to_show = '';
    if ( strlen( $slides_to_show ) > 0 ) {
        $d_slides_to_show = ' data-slides_to_show="' . $slides_to_show . '"';
    }
    // Slides to scroll
    $d_slides_to_scroll = '';
    if ( strlen( $slides_to_scroll ) > 0 ) {
        $d_slides_to_scroll = ' data-slides_to_scroll="' . $slides_to_scroll . '"';
    }
    // Fade
    $d_animation = '';
    if ( strlen( $animation ) > 0 ) {
        $d_animation = ' data-animation="' . $animation . '"';
    }
    // Adaptive height
    $d_adaptive_height = '';
    if ( strlen( $adaptive_height ) > 0 ) {
        $d_adaptive_height = ' data-adaptive_height="' . $adaptive_height . '"';
    }

    // Data Attributes
    $slick_data_atts = '';
    if ( strlen( $d_speed ) > 0 
    	|| strlen( $d_autoplay ) > 0 
    	|| strlen( $autoplay_speed ) > 0 
    	|| strlen( $d_slides_to_show ) > 0 
    	|| strlen( $d_slides_to_scroll ) > 0 
    	|| strlen( $d_arrows ) > 0 
    	|| strlen( $d_dots ) > 0 
    	|| strlen( $d_animation ) > 0 
    	|| strlen( $d_adaptive_height ) > 0 ) {
        $slick_data_atts = $d_arrows . 
    						$d_dots . 
    						$d_speed . 
    						$d_autoplay . 
    						$d_autoplay_speed . 
    						$d_slides_to_show . 
    						$d_slides_to_scroll . 
    						$d_animation . 
    						$d_adaptive_height;
    }

    $output = '<ul class="single-img-slider ' . $d_arrows_hover . '' . $css_class . '" ' . $slick_data_atts . '>
    				' . do_shortcode( $content ) . 
    			'</ul>';

    return $output;
} 
add_shortcode( 'd_single_img_slider', 'definity_single_img_slider_shortcode' );


function definity_single_img_slide( $atts, $content = NULL ) {
     
    extract(
        shortcode_atts(
            array(
                'image'			=> '',
                'link' 			=> '',
                'lightbox'		=> '',
                'css_class'     => ''
            ), 
            $atts
        )
    );

    // Button (Link)
    $link = vc_build_link( $link );
    if ( strlen( $link['url'] ) > 0 ) {
    	// Image
    	$image = wp_get_attachment_image_src( $image, 'full' );
    	if ( strlen( $image[0] ) > 0 ) {
            $image_title = get_the_title( $image[0] );
    	    $image_element = '<img src="' . esc_url( $image[0] ) . '" alt="' . esc_attr( $image_title ) . '" />';
    	}

        $img = '<a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '">' . $image_element . '</a>';

    } elseif ( $lightbox == '1' ) {
    	// Image
    	$image = wp_get_attachment_image_src( $image, 'full' );
    	if ( strlen( $image[0] ) > 0 ) {
            $image_title = get_the_title( $image[0] );
    	    $image_element = '<img src="' . esc_url( $image[0] ) . '" alt="' . esc_attr( $image_title ) . '" />';
    	}

    	$img = '<a href="' . esc_url( $image[0] ) . '" title="' . esc_attr( $link['title'] ) . '" class="sis-open-gallery">' . $image_element . '</a>';
    } else {
    	// Image
    	$image = wp_get_attachment_image_src( $image, 'full' );
    	if ( strlen( $image[0] ) > 0 ) {
            $image_title = get_the_title( $image[0] );
    	    $img = '<img src="' . esc_url( $image[0] ) . '" alt="' . esc_attr( $image_title ) . '" />';
    	}
    }

    $output = '<li>' . $img . '</li>';

    return $output;
} 
add_shortcode( 'd_single_img_slide', 'definity_single_img_slide' );


/* --------------------------------------------------
	CTA
-------------------------------------------------- */

function definity_d_cta_shortcode( $atts, $content = NULL ) {
     
    extract(
        shortcode_atts(
            array(
            	'cta_type'			=> '',
                'heading'          	=> 'Join our newsletter',
                'heading_style'     => '',
                'heading_color'     => '',
                'link'          	=> '',
                // cta float
                'image'             => '',
                'img_position'      => '',
                'top_offset'        => '',

                'bg'                => '',
                'bg_color'			=> '',
                'css_class'         => '',
                // cf7
                'id'				=> '',
                // popup btn
                'popup_link'        => '',
                'popup_btn'        	=> 'play-btn',
                'show_btn_icon'     => '',
                'icon'        		=> 'linea-music-play-button',
                'icon_color'        => '',
                // btn type
                'btn_size'				=> '',
                'btn_type'				=> 'btn',
                // btn styles
                'cta_btn_bg'					=> '',
                'cta_btn_bg_hover'				=> '',
                'cta_btn_border_color'			=> '',
                'cta_btn_border_bg_hover'		=> '',
                'cta_btn_text_btn_border_color'	=> '',
                'cta_btn_text_color'			=> '',
                'cta_btn_text_hover_color'      => '',

                'cta_height'                    => '',
                'cta_p_left'                    => '',
                'cta_p_right'		            => '',
            ), 
            $atts
        )
    );

    // CF7
    $title_attr = '';
    $cf7 = '[contact-form-7 id="' . intval( $id ) . '"' . $title_attr . ']';

    // Bg image
    $bg = wp_get_attachment_image_src( $bg, 'full' );
    $bg_image = '';
    if ( strlen( $bg[0] ) > 0 ) {
        $bg_image = ' style="background-image: url(' . esc_url( $bg[0] ) . ');"';
    }

    // Image (CTA Float)
    $image = wp_get_attachment_image_src( $image, 'full' );
    if ( strlen( $image[0] ) > 0 ) {
        $image_element = '<img src="' . esc_url( $image[0] ) . '" alt="' . esc_attr( $heading ) . '" />';
        $image_url = esc_url( $image[0] );
    }

    // Top Offset (CTA Float)
    $top_offset_output = '';
    if ( strlen( ! $top_offset == 0 ) ) {
        $top_offset_output = ' style="margin-top:' . intval( $top_offset ) . 'px;"';
    }

    // CTA Bg color
    $bg_color_style = '';
    if ( strlen( $bg_color ) > 0 ) {
        $bg_color_style = ' style="background: ' . $bg_color . ';"';
    }

    // >>> START - BUTTON STYLES <<<
    static $btn_nbr = 0;
    if ( strlen( $cta_type == 'cta_join' ) ) {
        $btn_style_id = ' input[type="submit"].wpcf7-submit.wpcf7-form-control.cta-btn-light';
    } elseif( strlen( $cta_type == 'cta_float' ) ) {
        $btn_style_id = ' input[type="submit"].btn.wpcf7-submit';
    } else {
        $btn_style_id = 'd-vc-cta-btn-custom-style-' . $btn_nbr++;
    }
    $id_sign = ( strlen( $cta_type == 'cta_join' ) || strlen( $cta_type == 'cta_float' ) ) ? '' : '#';

    // Button Style
    $btn_bg = '';
    if ( strlen( $cta_btn_bg ) > 0 ) {
        $btn_bg = $id_sign . $btn_style_id . '{background-color: ' . $cta_btn_bg . '!important;} ';
    }
    $btn_bg_hover = '';
    if ( strlen( $cta_btn_bg_hover ) > 0 ) {
        $btn_bg_hover = $id_sign . $btn_style_id . ':hover{background-color: ' . $cta_btn_bg_hover . '!important;} ';
    }

    $btn_border_color = '';
    if ( strlen( $cta_btn_border_color ) > 0 ) {
        $btn_border_color = $id_sign . $btn_style_id . '{border-color: ' . $cta_btn_border_color . ';} ';
    }
    $btn_border_bg_hover = '';
    if ( strlen( $cta_btn_border_bg_hover ) > 0 ) {
        $btn_border_bg_hover = $id_sign . $btn_style_id . ':hover{border-color: ' . $cta_btn_border_bg_hover . ';} #' . $btn_style_id . ':after{background-color: ' . $cta_btn_border_bg_hover . ';} ';
    }

    $btn_text_btn_border_color = '';
    if ( strlen( $cta_btn_text_btn_border_color ) > 0 ) {
        $btn_text_btn_border_color = $id_sign . $btn_style_id . ':hover{border-color: ' . $cta_btn_text_btn_border_color . ';} ';
    }

    $btn_text_color = '';
    if ( strlen( $cta_btn_text_color ) > 0 ) {
        $btn_text_color = $id_sign . $btn_style_id . '{color: ' . $cta_btn_text_color . '!important;} ';
    }
    $btn_text_hover_color = '';
    if ( strlen( $cta_btn_text_hover_color ) > 0 ) {
        $btn_text_hover_color = $id_sign . $btn_style_id . ':hover{color: ' . $cta_btn_text_hover_color . '!important;} ';
    }
    $cta_btn_style = '';
    if ( strlen( $btn_bg ) > 0 || strlen( $btn_bg_hover ) > 0 || strlen( $btn_text_color ) > 0 || strlen( $btn_text_hover_color ) > 0 || ( strlen( $cta_type == 'cta_float' ) ) ) {

        $cta_btn_style = '<style type="text/css" class="custom-vc-btn-style">' . $btn_bg .  $btn_bg_hover . $btn_text_color . $btn_text_hover_color . $btn_border_color . $btn_border_bg_hover . $btn_text_btn_border_color . '</style>';        
    }

    // Incremental ID
    $btn_id = 'id="' . $btn_style_id . '"';
    //  >>> END - BUTTON STYLES <<<

    // Button (Link)
	$link = vc_build_link( $link );
    $button = '';
    if ( strlen( $link['url'] ) > 0 ) {
        $target = ( strlen( $link['target'] ) ) ? ' target="_blank"' : '';

        $button = $cta_btn_style . '<a ' . $btn_id . ' class="' . $btn_type . $btn_size . '" href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '" ' . $target . '>' . esc_attr( $link['title'] ) . '</a>';
    }

    // Icon Custom Style
    $icon_custom_style = '';
    if ( strlen( $icon_color ) > 0 ) {
        $icon_custom_style = ' style="color: ' . $icon_color . ';"';
    }

    // Button (Popup link)
	$popup_link = vc_build_link( $popup_link );
    if ( strlen( $popup_link['url'] ) > 0 ) {
        $btn_popup = '<a class="' . $popup_btn . $btn_size . ' popup-video" href="' . esc_url( $popup_link['url'] ) . '" title="' . esc_attr( $popup_link['title'] ) . '">
        <span class="play-icon ' . $icon . '"' . $icon_custom_style . '></span>
        <h5>' . esc_attr( $popup_link['title'] ) . '</h5></a>';

        if ( $popup_btn === 'btn' || $popup_btn === 'btn-ghost' || $popup_btn === 'btn-ghost btn-round' || $popup_btn === 'btn-text' ) {
        	$btn_popup = '<a class="' . $popup_btn . $btn_size . ' popup-video" href="' . esc_url( $popup_link['url'] ) . '" title="' . esc_attr( $popup_link['title'] ) . '">' . esc_attr( $popup_link['title'] ) . '</a>';
        }
    }

    //  Heading Color
    $heading_color_css = '';
    if ( strlen( $heading_color ) > 0 ) {
        $heading_color_css = ' style="color: ' . $heading_color . ';"';
    }

    // CTA Compact - Height
    $cta_height = ( strlen( $cta_height ) > 0 ) ? ' height:' . intval( $cta_height ) . 'px;' : '';
    // CTA Compact - Padding Left
    $cta_p_left = ( strlen( $cta_p_left ) > 0 ) ? ' padding-left:' . intval( $cta_p_left ) . 'px;' : '';
    // CTA Compact - Padding Left
    $cta_p_right = ( strlen( $cta_p_right ) > 0 ) ? ' padding-right:' . intval( $cta_p_right ) . 'px;' : '';
    // CTA Compact - Wrapper CSS
    $cta_wrapper_css = ( strlen( $cta_height ) > 0 ) || ( strlen( $cta_p_left ) > 0 ) || ( strlen( $cta_p_right ) > 0 ) ? ' style="' . $cta_height . $cta_p_left . $cta_p_right . '"' : '';
    

    switch ( $cta_type ) {
    	case 'cta_join':
	        $output = '
                ' . $cta_btn_style . '
		        <div class="cta-newsletter ' . $css_class . '" ' . $bg_image . '>
		        	<div class="bg-overlay" ' . $bg_color_style . '>
		        		<div class="cta-wrapper">
		        			<h3 class="' . $heading_style . '"  ' . $heading_color_css . '>' . $heading . '</h3>
		        			' . do_shortcode( $cf7 ) . '
		        		</div>
		        	</div>
		        </div>';
        break;

        case 'cta_popup':
	        $output = '
		        <div class="cta-link cta-popup' . $css_class . '" ' . $bg_image . '>
		        	<div class="bg-overlay" ' . $bg_color_style . '>
		        		<div class="cta-wrapper">
		        			<h3 class="' . $heading_style . '"  ' . $heading_color_css . '>' . $heading . '</h3>
		        			' . $btn_popup . '
		        		</div>
		        	</div>
		        </div>';
        break;

        case 'cta_float':
            $output = '
                <div class="cta-float ' . $img_position . $css_class . '"' . $top_offset_output . '>
                    <div class="img-wrapper">
                        ' . $image_element . '
                    </div>
                    <div class="form-wrapper">
                        <div class="col-lg-12">
                            <h2 class="' . $heading_style . '" ' . $heading_color_css . '>' . $heading . '</h2>
                        </div>
                        ' . $cta_btn_style 
                          . do_shortcode( $cf7 ) . '
                    </div>
                </div>';
        break;

        case 'cta_link_compact':
            $output = '
            <div class="cta-link-compact ' . $css_class . '" ' . $bg_image . '>
                <div class="bg-overlay" ' . $bg_color_style . '>
                    <div class="cta-wrapper"' . $cta_wrapper_css . '>
                        <h3 class="' . $heading_style . '"  ' . $heading_color_css . '>' . $heading . '</h3>
                        ' . $button . '
                    </div>
                </div>
            </div>';
        break;
    	
    	default:
    	$output = '
        	<div class="cta-link ' . $css_class . '" ' . $bg_image . '>
        		<div class="bg-overlay" ' . $bg_color_style . '>
        			<div class="cta-wrapper">
        				<h3 class="' . $heading_style . '"  ' . $heading_color_css . '>' . $heading . '</h3>
        				' . $button . '
        			</div>
        		</div>
        	</div>';
    	break;
    }

    return $output;
} 
add_shortcode( 'd_cta', 'definity_d_cta_shortcode' );


/* --------------------------------------------------
	Portfolio
-------------------------------------------------- */

function definity_portfolio_wrapper_shortcode( $atts, $content = NULL ) {
    extract(
        shortcode_atts(
            array(
                'show_filters'		=> '0',
                'all_filter_text' 	=> 'All',
                'filter_1'		  	=> '',
                'filter_2'		  	=> '',
                'filter_3'			=> '',
                'filter_4'			=> '',
                'filter_5'			=> '',
                'filter_6'			=> '',
                'filter_7'			=> '',
                'filter_8'			=> '',
                'filter_9'			=> '',
                'filter_10'			=> '',
                'css_class'			=> ''
            ), 
            $atts
        )
    );

    $filters_list_html = '';
    // Filters
    if ( $show_filters == '1' ) {
    	$filters_list = array(
            'filter_1'      => array( 'text'  => $filter_1 ),
            'filter_2'      => array( 'text'  => $filter_2 ),
            'filter_3'      => array( 'text'  => $filter_3 ),
            'filter_4'      => array( 'text'  => $filter_4 ),
            'filter_5'      => array( 'text'  => $filter_5 ),
            'filter_6'      => array( 'text'  => $filter_6 ),
            'filter_7'      => array( 'text'  => $filter_7 ),
            'filter_8'      => array( 'text'  => $filter_8 ),
            'filter_9'      => array( 'text'  => $filter_9 ),
            'filter_10'     => array( 'text'  => $filter_10 ),
        );
        $filter_output = '';
        foreach ( $filters_list as $filter => $details ) {
            if ( $details['text'] !== '' ) {
                 $filter_output .= '<li><a href="#" data-filter=".' . $details['text'] . '">' . $details['text'] . '</a></li>';
            }
        }
        $filters_list_html .= '
        <ul id="pfolio-filters" class="portfolio-filters">
        	<li class="active"><a href="#" data-filter="*">' . $all_filter_text . '</a></li>
			' . $filter_output . '
		</ul>';
    }

    $output = '
    	' . $filters_list_html . '
    	<div id="pfolio" class="portfolio-columns-fw ' . $css_class . '">'
			. do_shortcode( $content ) . 
		'</div>';

    return $output;
} 
add_shortcode( 'd_portfolio_wrapper', 'definity_portfolio_wrapper_shortcode' );


function definity_portfolio_item_shortcode( $atts, $content = NULL ) {
     
    extract(
        shortcode_atts(
            array(
                'media_type'       	=> 'img',
                'image'				=> '',
                'video_image'		=> '',
                'grid_layout'       => 'col-md-4',
                'hover_effect'      => 'hover-default',
                'p_content_align'   => '',
                'open_lightbox'     => '',
                'title'				=> '',
                'subtitle'         	=> '',
                'filters_option'    => '',
                'filter'     		=> '',
                'link'				=> '',
                'video_url'			=> '',
            ), 
            $atts
        )
    );

    $open_link = '';
    $open_link_2 = '';
    $open_link_3 = '';
    $image_element = '';

    // Image
	$image = wp_get_attachment_image_src( $image, 'full' );
	if ( strlen( $image[0] ) > 0 ) {
	    $image_element = '<img src="' . esc_url( $image[0] ) . '" alt="' . esc_attr( $title ) . '" />';
	    $image_url = esc_url( $image[0] );
	}

	// Video Image
	$video_image = wp_get_attachment_image_src( $video_image, 'full' );
	if ( strlen( $video_image[0] ) > 0 ) {
        $image_element = '<img src="' . esc_url( $video_image[0] ) . '" alt="' . esc_attr( $title ) . '" />';
	}

	// Video URL
	if ( $media_type == 'video' ) {

        $link_2_title = '';
        if ( isset( $link['title'] ) ) $link_2_title = esc_attr( $link['title'] );

		$open_link = '<a class="open-btn popup-video" href="' . $video_url . '"><i class="fa fa-play"></i></a>';

		$open_link_2 = '<a class="popup-video" href="' . esc_url( $video_url ) . '" title="' . $link_2_title . '"><i class="fa fa-play"></i></a>';
	}

	// Popup/Lightbox
	if ( $open_lightbox == '1' ) {
		$open_link = '<a class="open-btn open-gallery" href="' . $image_url . '"><i class="fa fa-expand"></i></a>';
	}

    // Button (Link)
    $link = vc_build_link( $link );
    if ( strlen( $link['url'] ) > 0 ) {
        $open_link = '<a class="open-btn" href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '"><i class="fa fa-expand"></i></a>';

        $open_link_2 = '<a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '"><i class="fa fa-share"></i></a>';

        $open_link_3 = '<a class="hover-more-btn" href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '"><span class="linea-arrows-slim-right"></span></a>';
    }

    // Portoflio Simple text align
    $p_content_align_class = '';
    if ( $p_content_align !== '' ) {
        $p_content_align_class = ' class="' . $p_content_align . '"';
    }

    // Portoflio Style
    switch ( $hover_effect ) {
    	case 'hover-bottom':
    		if ( $media_type != 'video' ) {
    			$gallery_btn = '<li><a class="open-gallery" href="' . $image_url . '"><i class="fa fa-arrows-alt"></i></a></li>';
    		}
        	$output = '
        	<div class="portfolio-item hover-bottom ' . $grid_layout . ' ' .  $filter .'">
        		<figure>
        			' . $image_element . '
        			<figcaption>
        				<h4 class="hover-heading">' . $title . '</h4>
        				<ul class="hover-btns">
        					' . $gallery_btn . '
        					<li>' . $open_link_2 . '</li>
        				</ul>
        			</figcaption>
        		</figure>
        	</div>';
        break;

        case 'hover-bottom hover-light':
        	if ( $media_type != 'video' ) {
        		$gallery_btn = '<li><a class="open-gallery" href="' . $image_url . '"><i class="fa fa-arrows-alt"></i></a></li>';
        	}
        	$output = '					
        	<div class="portfolio-item hover-bottom hover-light ' . $grid_layout . ' ' .  $filter .'">
        		<figure>
        			' . $image_element . '
        			<figcaption>
        				<h4 class="hover-heading">' . $title . '</h4>
        				<ul class="hover-btns">
        					' . $gallery_btn . '
        					<li>' . $open_link_2 . '</li>
        				</ul>
        			</figcaption>
        		</figure>
        	</div>';
        break;

        case 'hover-side':
        	if ( $media_type != 'video' ) {
        		$gallery_btn = '<li><a href="' . $image_url . '" class="open-gallery"><span class="linea-arrows-expand"></span></a></li>';
        	} elseif ( $media_type == 'video' ) {
        		$gallery_btn = '<li><a class="popup-video" href="' . esc_url( $video_url ) . '"><span class="linea-music-play-button"></span></a></li>';
        	}
        	$output = '
        	<div class="portfolio-item hover-side ' . $grid_layout . ' ' .  $filter .'">
        		<figure>
        			' . $image_element . '
        			<figcaption>
        				<h5 class="hover-heading">' . $title . '</h5>
        				<p class="hover-text">' . $subtitle . '</p>
        				' . $open_link_3 . '
        				<ul class="hover-btns">
        					' . $gallery_btn . '
        				</ul>
        			</figcaption>
        		</figure>
        	</div>';
        break;

    	case 'hover-side hover-light':
    		if ( $media_type != 'video' ) {
        		$gallery_btn = '<li><a href="' . $image_url . '" class="open-gallery"><span class="linea-arrows-expand"></span></a></li>';
        	} elseif ( $media_type == 'video' ) {
        		$gallery_btn = '<li><a class="popup-video" href="' . esc_url( $video_url ) . '"><span class="linea-music-play-button"></span></a></li>';
        	}
        	$output = '
        	<div class="portfolio-item hover-side hover-light ' . $grid_layout . ' ' .  $filter .'">
        		<figure>
        			' . $image_element . '
        			<figcaption>
        				<h5 class="hover-heading">' . $title . '</h5>
        				<p class="hover-text">' . $subtitle . '</p>
        				' . $open_link_3 . '
        				<ul class="hover-btns">
        					' . $gallery_btn . '
        				</ul>
        			</figcaption>
        		</figure>
        	</div>';
        break;

        case 'hover-simple':
            $gallery_btn = '';
            if ( $media_type == 'video' ) {
                $gallery_btn = '<a class="popup-video" href="' . esc_url( $video_url ) . '"><span class="linea-music-play-button"></span></a>';
            }
            $output = '
            <div class="portfolio-simple hover-simple ' . $grid_layout . ' ' .  $filter .'">
                <figure>
                    <div class="img-wrapper">
                        ' . $gallery_btn . $image_element . $open_link . '
                    </div>
                    <figcaption' . $p_content_align_class . '>
                        <h5 class="p-title">' . $title . '</h5>
                        <p class="p-subtitle">' . $subtitle . '</p>
                    </figcaption>
                </figure>
            </div>';
        break;
    	
    	default:
    		$output = '
	        <div class="portfolio-item ' . $grid_layout . ' ' .  $filter .'">
	        	<div class="p-wrapper ' . $hover_effect . '">
	        		' . $image_element . '
	        		<div class="p-hover">
	        			<div class="p-content">
	        				<h4>' . $title . '</h4>
	        				<h6 class="subheading">' . $subtitle . '</h6>
	        			</div>
	        		</div>
	        		' . $open_link . '
	        	</div>
	        </div>';
    	break;
    }

    return $output;
} 
add_shortcode( 'd_portfolio_item', 'definity_portfolio_item_shortcode' );


/* --------------------------------------------------
	Portfolio Masonry
-------------------------------------------------- */

function definity_portfolio_masonry_wrapper_shortcode( $atts, $content = NULL ) {
    extract(
        shortcode_atts(
            array(
                'masonry_layout'	=> 'portfolio-masonry',
                'show_filters'		=> '0',
                'all_filter_text' 	=> 'All',
                'filter_1'		  	=> '',
                'filter_2'		  	=> '',
                'filter_3'			=> '',
                'filter_4'			=> '',
                'filter_5'			=> '',
                'filter_6'			=> '',
                'filter_7'			=> '',
                'filter_8'			=> '',
                'filter_9'			=> '',
                'filter_10'			=> '',
                'css_class'			=> ''
            ), 
            $atts
        )
    );

    // Filters
    $filter_output = '';
    if ( $show_filters == '1' ) {
    	$filters_list = array(
            'filter_1'      => array( 'text'  => $filter_1 ),
            'filter_2'      => array( 'text'  => $filter_2 ),
            'filter_3'      => array( 'text'  => $filter_3 ),
            'filter_4'      => array( 'text'  => $filter_4 ),
            'filter_5'      => array( 'text'  => $filter_5 ),
            'filter_6'      => array( 'text'  => $filter_6 ),
            'filter_7'      => array( 'text'  => $filter_7 ),
            'filter_8'      => array( 'text'  => $filter_8 ),
            'filter_9'      => array( 'text'  => $filter_9 ),
            'filter_10'     => array( 'text'  => $filter_10 ),
        );
        foreach ( $filters_list as $filter => $details ) {
            if ( $details['text'] !== '' ) {
                 $filter_output .= '<li><a href="#" data-filter=".' . $details['text'] . '">' . $details['text'] . '</a></li>';
            }
        }

        $filters_list_html = '
        <ul id="pfolio-filters" class="portfolio-filters">
        	<li class="active"><a href="#" data-filter="*">' . $all_filter_text . '</a></li>
			' . $filter_output . '
		</ul>';
    }

    $output = '
    <div class="portfolio-layout ' . $masonry_layout . ' ' . $css_class . '">
    	' . $filters_list_html . '
    	<div class="pfolio-items">
        	<div class="grid-sizer"></div>'
			. do_shortcode( $content ) . 
		'</div>
	</div>';

    return $output;
} 
add_shortcode( 'd_portfolio_masonry_wrapper', 'definity_portfolio_masonry_wrapper_shortcode' );


function definity_portfolio_masonry_item_shortcode( $atts, $content = NULL ) {
     
    extract(
        shortcode_atts(
            array(
                'media_type'    	=> '',
                'image'				=> '',
                'video_image'		=> '',
                'hover_effect'      => 'hover-default',
                'title'				=> '',
                'subtitle'         	=> '',
                'open_lightbox'     => '',
                'filters_option'    => '',
                'filter'     		=> '',
                'link'				=> '',
                'video_url'			=> '',
            ), 
            $atts
        )
    );

    // Image
	$image = wp_get_attachment_image_src( $image, 'full' );
	if ( strlen( $image[0] ) > 0 ) {
	    $image_element = '<img src="' . esc_url( $image[0] ) . '" alt="' . esc_attr( $title ) . '" />';
	    $image_url = esc_url( $image[0] );

	}

	// Video Image
	$video_image = wp_get_attachment_image_src( $video_image, 'full' );
	if ( strlen( $video_image[0] ) > 0 ) {
		$image_element = '<img src="' . esc_url( $video_image[0] ) . '" alt="' . esc_attr( $title ) . '" />';
	}

	// Video URL
	if ( $media_type == 'video' ) {
		$open_link = '<a class="open-btn popup-video" href="' . $video_url . '"><i class="fa fa-play"></i></a>';
	}

	// Popup/Lightbox
	if ( $open_lightbox == '1' ) {
		$open_link = '<a class="open-btn open-gallery" href="' . $image_url . '"><i class="fa fa-expand"></i></a>';
	}

    // Button (Link)
    $link = vc_build_link( $link );
    if ( strlen( $link['url'] ) > 0 ) {
        $open_link = '<a class="open-btn" href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '"><i class="fa fa-expand"></i></a>';
    }

    $output = '
    <div class="p-item ' .  $filter .'">
    	<div class="p-wrapper ' . $hover_effect . '">
    		' . $image_element . '
    		<div class="p-hover">
    			<div class="p-content">
    				<h4>' . $title . '</h4>
    				<h6 class="subheading">' . $subtitle . '</h6>
    			</div>
    		</div>
    		' . $open_link . '
    	</div>
    </div>';

    return $output;
} 
add_shortcode( 'd_portfolio_masonry_item', 'definity_portfolio_masonry_item_shortcode' );


/* --------------------------------------------------
	Recent Posts
-------------------------------------------------- */

function definity_posts_shortcode( $atts, $content = NULL ) {
     
    extract(
        shortcode_atts(
            array(
                // General
                'posts_number'      => '3',
                'posts_cat'     	=> '',
                'post_tag'			=> '',
                'post_name'         => '',
                'comments_off'      => '',
                // Style
                'bg_color'          => '',
                'title_color'       => '',
                'txt_color'         => '',
                'meta_color'        => '',
                'btn_bg_color'      => '',
                'btn_bg_hover_color'    => '',
                'btn_txt_color'         => '',
                'btn_txt_hover_color'   => '',
            ), 
            $atts
        )
    );

    global $post;

    $recent_posts = new WP_Query( array( 'orderby' => 'date', 'posts_per_page' => absint( $posts_number ), 'category_name' => $posts_cat, 'tag' => $post_tag, 'name' => $post_name, 'post_status' => 'publish','ignore_sticky_posts' => true ) );

    // Comments on/off
    $bp_comments = '';
    if ( ! strlen( $comments_off ) == 'comments_off'  ) {
        $bp_comments = '
        <a href="' . get_the_permalink() . '#comments" class="post-comments">
            <i class="fa fa-comments-o"></i>
            <span>' . get_comments_number() . '</span>
        </a>';
    }

    // Title Color
    $title_color = ( strlen( $title_color ) > 0 ) ? ' style="color:' . $title_color . '"' : '';

    // Exceprt Color
    $txt_color = ( strlen( $txt_color ) > 0 ) ? ' style="color:' . $txt_color . '"' : '';

    // Card Background Color
    $bg_color = ( strlen( $bg_color ) > 0 ) ? ' style="background-color:' . $bg_color . '"' : '';


    // START OF 'CSS style element insert'
    static $bp_nbr = 0;
    $bp_preview_custom_css = 'd-vc-bp-preview-custom-css-' . $bp_nbr++;

    // Meta Info Color
    $meta_color = ( strlen( $meta_color ) > 0 ) ? 
    '.' . $bp_preview_custom_css . ' .post-meta .post-date i{color: ' . $meta_color . ';} ' . 
    '.' . $bp_preview_custom_css . ' .post-meta .post-date span{color: ' . $meta_color . ';border-color:' . $meta_color . '} ' . 
    '.' . $bp_preview_custom_css . ' .post-meta .post-comments i{color: ' . $meta_color . ';} ' . 
    '.' . $bp_preview_custom_css . ' .post-meta .post-comments span{color: ' . $meta_color . ';border-color:' . $meta_color . '}' 
    : '';

    // Button Background Color
    $btn_bg_color = ( strlen( $btn_bg_color ) > 0 ) ? '.' . $bp_preview_custom_css . ' .bp-content .read-more-btn{background-color: ' . $btn_bg_color . ';} ' : '';
    // Button Hover Background Color
    $btn_bg_hover_color = ( strlen( $btn_bg_hover_color ) > 0 ) ? '.' . $bp_preview_custom_css . ' .bp-content .read-more-btn:hover{background-color: ' . $btn_bg_hover_color . ' !important;} ' : '';
    // Button Text Color
    $btn_txt_color = ( strlen( $btn_txt_color ) > 0 ) ? '.' . $bp_preview_custom_css . ' .bp-content .read-more-btn{color: ' . $btn_txt_color . ';} ' : '';
    // Button Hover Text Color
    $btn_txt_hover_color = ( strlen( $btn_txt_hover_color ) > 0 ) ? '.' . $bp_preview_custom_css . ' .bp-content .read-more-btn:hover{color: ' . $btn_txt_hover_color . ';} ' : '';

    $bp_preview_style = '';
    if ( strlen( $meta_color ) > 0 || strlen( $btn_bg_color ) > 0 ) {
        $bp_preview_style = '<style type="text/css">' . $meta_color . $btn_bg_color . $btn_bg_hover_color . $btn_txt_color . $btn_txt_hover_color . '</style>';
    }
    // END OF 'CSS style element insert'


    $output = '';
    if ( $recent_posts -> have_posts() ) {
        $output .= $bp_preview_style;
    	$output .= '<div class="row blog-columns blog-preview">';
    		while( $recent_posts -> have_posts() ) {
    			$recent_posts -> the_post();
    			$output .= '
    			<div class="col-lg-4 col-md-6">
					<div class="blog-post ' . $bp_preview_custom_css . '"' . $bg_color . '>
						<a href="' . get_the_permalink() . '" class="post-img">' . get_the_post_thumbnail() . '</a>
						<div class="bp-content">
							<div class="post-meta">
								<p class="post-date">
									<i class="fa fa-calendar-o"></i>
									<span>' . get_the_date() . '</span>
								</p>
								' . $bp_comments . '
							</div>
							<a href="' . get_the_permalink() . '" class="post-title">
								<h4' . $title_color . '>' . get_the_title() . '</h4>
							</a>
							<p' . $txt_color . '>' . get_the_excerpt() . '</p>
						</div>
					</div>
				</div>';
    		} 
		$output .= '</div>';
		wp_reset_postdata();
    }
    return $output;
} 
add_shortcode( 'd_posts', 'definity_posts_shortcode' );


/* --------------------------------------------------
	Contact Layouts
-------------------------------------------------- */

function definity_contact_shortcode( $atts, $content = NULL ) {
     
    extract(
        shortcode_atts(
            array(
                // General
            	'contact_layout'	=> '',
                // Contact Form
            	'cf_id'				=> '',
            	'cf_heading'		=> '',
            	'cf_subheading' 	=> '',
            	'cfh_top_gap' 		=> '100',
            	'cfh_bot_gap' 		=> '50',
            	'cf_style' 			=> 'form-minimal',
            	'cf_info' 			=> '',
                'css_class'         => '',
                // Map Options
				'address'			=> '',
				'map_type'			=> 'roadmap_custom',
				'map_style'			=> 'styles',
				'height'			=> '750px',
				'zoom'				=> '13',
	            'min_zoom'			=> '1',
				'zoom_controls'		=> '0',
				'scroll_zoom'		=> '0',
				'touch_drag'		=> '0',
				'marker_icon'		=> '',
	            'api_key'       	=> '',
	            'show_map_btn'  	=> 'Show on map',
	            'show_info_btn' 	=> 'Show info',
	            'cf2_show_map'		=> '1',
	            'adr_c2_bg'			=> '',
	            'adr_c2_txt'		=> '',
                // Style
                'cl4_cf_heading_color'      => '',
                'cl4_cf_subheading_color'   => '',
                'cl4_bg_color'              => '',
                'cl4_map_btn_color'         => '',
                'cl4_ag_title_color'        => '',
                'cl4_ag_txt_color'          => '',
                'cl4_ag_border_color'       => '',
                // Address Group 1
	            'ag_1_icon' 		=> '',
            	'ag_1_title' 		=> '',
            	'ag_11_field' 		=> '',
            	'ag_12_field' 		=> '',
            	'ag_13_field' 		=> '',
            	'ag_14_field' 		=> '',
                // Address Group 2
            	'ag_2_icon' 		=> '',
            	'ag_2_title' 		=> '',
            	'ag_21_field' 		=> '',
            	'ag_22_field' 		=> '',
            	'ag_23_field' 		=> '',
            	'ag_24_field' 		=> '',
                // Address Group 3
            	'ag_3_icon' 		=> '',
            	'ag_3_title' 		=> '',
            	'ag_31_field' 		=> '',
            	'ag_32_field' 		=> '',
            	'ag_33_field' 		=> '',
            	'ag_34_field' 		=> '',
                // Address Group 4
            	'ag_4_icon' 		=> '',
            	'ag_4_title' 		=> '',
            	'ag_41_field' 		=> '',
            	'ag_42_field' 		=> '',
            	'ag_43_field' 		=> '',
            	'ag_44_field' 		=> '',
            ), 
            $atts
        )
    );

    $api_version = 'v=3';
    $api_key = ( strlen( $api_key ) > 0 ) ? '&key=' . $api_key : '';
    
	// Enqueue Google Map scripts
    wp_enqueue_script( 'google_maps_api', '//maps.google.com/maps/api/js?' . $api_version . $api_key . '', '', '', true );
	wp_enqueue_script( 'google_maps_js', DEFINITY_URI . '/assets/js/google-maps.js', array( 'jquery', 'google_maps_api' ), 'v1.0', true );
	
	static $i = 0;
	$i++;
	
	$marker_icon_url = ( strlen( $marker_icon ) > 0 ) ? wp_get_attachment_url( $marker_icon ) : '';
	
	$map_data = '
		data-address="' . esc_attr( $address ) . '"
		data-map-type="' . esc_attr( $map_type ) . '"
		data-map-style="' . esc_attr( $map_style ) . '"
		data-zoom="' . esc_attr( $zoom ) . '"
        data-min-zoom="' . esc_attr( $min_zoom ) . '"
		data-zoom-controls="' . esc_attr( $zoom_controls ) . '"
		data-scroll-zoom="' . esc_attr( $scroll_zoom ) . '"
		data-touch-drag="' . esc_attr( $touch_drag ) . '"
		data-marker-icon="' . esc_url( $marker_icon_url ) . '"
	';

	$map_classes = 'definity-gmap aspect-ratio';
	$map_styles = ' style="height: 500px;"';

	if ( $contact_layout === 'contact_2' || $contact_layout === 'contact_4' ) {

		$map_classes = 'definity-gmap';
		$map_styles = '';
		
		if ( strlen( $height > 0 ) ) {
			$map_styles = ' style="height:' . intval( $height ) . 'px;"';
		} else {
			$map_classes .= ' aspect-ratio';
		}
	}

	// Bg color (contact 2)
    $adr_c2_bg_style = '';
    if ( strlen( $adr_c2_bg ) > 0 ) {
        $adr_c2_bg_style = ' style="background: ' . $adr_c2_bg . ';"';
    }

    // Title color (contact 2)
    $adr_c2_txt_style = '';
    if ( strlen( $adr_c2_txt ) > 0 ) {
        $adr_c2_txt_style = ' style="color: ' . $adr_c2_txt . ';"';
    }

    // CL4 - Map Background Color
    $cl4_bg_color = ( strlen( $cl4_bg_color ) > 0 ) ? '  style="background-color: ' . $cl4_bg_color . ';" ' : '';
    // CL4 - Map Button Color
    $cl4_map_btn_color = ( strlen( $cl4_map_btn_color ) > 0 ) ? '  style="color: ' . $cl4_map_btn_color . ';" ' : '';

    // CL4 Address Group - Title Color
    $cl4_ag_title_color = ( strlen( $cl4_ag_title_color ) > 0 ) ? '  style="color: ' . $cl4_ag_title_color . ';" ' : '';
    // CL4 Address Group - Title Color
    $cl4_ag_txt_color = ( strlen( $cl4_ag_txt_color ) > 0 ) ? '  style="color: ' . $cl4_ag_txt_color . ';" ' : '';
    // CL4 Address Group - Border Color
    $cl4_ag_border_color = ( strlen( $cl4_ag_border_color ) > 0 ) ? '  style="border-color: ' . $cl4_ag_border_color . ';" ' : '';

	// Address group 1
	$adr_group_1 = '';
	if ( strlen( $ag_1_title ) > 0 || strlen( $ag_11_field ) > 0 || strlen( $ag_12_field ) > 0 || strlen( $ag_13_field ) > 0 || strlen( $ag_14_field ) > 0 ) {
        $ag_1_title = ( strlen( $ag_1_title ) > 0 ) ? '<span' . $cl4_ag_title_color . '>' . $ag_1_title . '</span>' : '';
        $ag_11_field = ( strlen( $ag_11_field ) > 0 ) ? '<p' . $cl4_ag_txt_color . '>' . $ag_11_field . '</p>' : '';
        $ag_12_field = ( strlen( $ag_12_field ) > 0 ) ? '<p' . $cl4_ag_txt_color . '>' . $ag_12_field . '</p>' : '';
        $ag_13_field = ( strlen( $ag_13_field ) > 0 ) ? '<p' . $cl4_ag_txt_color . '>' . $ag_13_field . '</p>' : '';
        $ag_14_field = ( strlen( $ag_14_field ) > 0 ) ? '<p' . $cl4_ag_txt_color . '>' . $ag_14_field . '</p>' : '';
		$adr_group_1 = '
        <div class="col-sm-6 address-group">'
		    . $ag_1_title
            . $ag_11_field
            . $ag_12_field
            . $ag_13_field
            . $ag_14_field .
	    '</div>';
		if ( $contact_layout === 'contact_4' ) {
            $ag_1_title = ( strlen( $ag_1_title ) > 0 ) ? '<span class="adr-heading"' . $cl4_ag_title_color . '>' . $ag_1_title . '</span>' : '';
            $ag_11_field = ( strlen( $ag_11_field ) > 0 ) ? '<span class="adr-info"' . $cl4_ag_txt_color . '>' . $ag_11_field . '</span>' : '';
            $ag_12_field = ( strlen( $ag_12_field ) > 0 ) ? '<span class="adr-info"' . $cl4_ag_txt_color . '>' . $ag_12_field . '</span>' : '';
            $ag_13_field = ( strlen( $ag_13_field ) > 0 ) ? '<span class="adr-info"' . $cl4_ag_txt_color . '>' . $ag_13_field . '</span>' : '';
            $ag_14_field = ( strlen( $ag_14_field ) > 0 ) ? '<span class="adr-info"' . $cl4_ag_txt_color . '>' . $ag_14_field . '</span>' : '';
			$adr_group_1 = '
			<li class="contact-group"' . $cl4_ag_border_color . '>'
                . $ag_1_title
                . $ag_11_field
                . $ag_12_field
                . $ag_13_field
				. $ag_14_field .
			'</li>';
		} elseif ( $contact_layout === 'contact_2' ) {
			$adr_group_1 = '
			<li>
				<span class="' . $ag_1_icon . ' adr-icon"' . $adr_c2_txt_style . '></span>
				<div class="adr-group">
					<span class="adr-heading"' . $adr_c2_txt_style . '>' . $ag_1_title . '</span>
					<span class="adr-info">' . $ag_11_field . '</span>
				</div>
			</li>'; 
		}
	}
	// Address group 2
	$adr_group_2 = '';
	if ( strlen( $ag_2_title ) > 0 || strlen( $ag_21_field ) > 0 || strlen( $ag_22_field ) > 0 || strlen( $ag_23_field ) > 0 || strlen( $ag_24_field ) > 0 ) {
        $ag_2_title = ( strlen( $ag_2_title ) > 0 ) ? '<span' . $cl4_ag_title_color . '>' . $ag_2_title . '</span>' : '';
        $ag_21_field = ( strlen( $ag_21_field ) > 0 ) ? '<p' . $cl4_ag_txt_color . '>' . $ag_21_field . '</p>' : '';
        $ag_22_field = ( strlen( $ag_22_field ) > 0 ) ? '<p' . $cl4_ag_txt_color . '>' . $ag_22_field . '</p>' : '';
        $ag_23_field = ( strlen( $ag_23_field ) > 0 ) ? '<p' . $cl4_ag_txt_color . '>' . $ag_23_field . '</p>' : '';
        $ag_24_field = ( strlen( $ag_24_field ) > 0 ) ? '<p' . $cl4_ag_txt_color . '>' . $ag_24_field . '</p>' : '';
        $adr_group_2 = '
        <div class="col-sm-6 address-group">'
            . $ag_2_title
            . $ag_21_field
            . $ag_22_field
            . $ag_23_field
            . $ag_24_field .
        '</div>';
		if ( $contact_layout === 'contact_4' ) {
            $ag_2_title = ( strlen( $ag_2_title ) > 0 ) ? '<span class="adr-heading"' . $cl4_ag_title_color . '>' . $ag_2_title . '</span>' : '';
            $ag_21_field = ( strlen( $ag_21_field ) > 0 ) ? '<span class="adr-info"' . $cl4_ag_txt_color . '>' . $ag_21_field . '</span>' : '';
            $ag_22_field = ( strlen( $ag_22_field ) > 0 ) ? '<span class="adr-info"' . $cl4_ag_txt_color . '>' . $ag_22_field . '</span>' : '';
            $ag_23_field = ( strlen( $ag_23_field ) > 0 ) ? '<span class="adr-info"' . $cl4_ag_txt_color . '>' . $ag_23_field . '</span>' : '';
            $ag_24_field = ( strlen( $ag_24_field ) > 0 ) ? '<span class="adr-info"' . $cl4_ag_txt_color . '>' . $ag_24_field . '</span>' : '';
			$adr_group_2 = '
            <li class="contact-group"' . $cl4_ag_border_color . '>' 
                . $ag_2_title
                . $ag_21_field
                . $ag_22_field
                . $ag_23_field
                . $ag_24_field .
            '</li>';
		} elseif ( $contact_layout === 'contact_2' ) {
			$adr_group_2 = '
			<li>
				<span class="' . $ag_2_icon . ' adr-icon"' . $adr_c2_txt_style . '></span>
				<div class="adr-group">
					<span class="adr-heading"' . $adr_c2_txt_style . '>' . $ag_2_title . '</span>
					<span class="adr-info">' . $ag_21_field . '</span>
				</div>
			</li>'; 
		}
	}
	// Address group 3
	$adr_group_3 = '';
	if ( strlen( $ag_3_title ) > 0 || strlen( $ag_31_field ) > 0 || strlen( $ag_32_field ) > 0 || strlen( $ag_33_field ) > 0 || strlen( $ag_34_field ) > 0 ) {
            $ag_3_title = ( strlen( $ag_3_title ) > 0 ) ? '<span' . $cl4_ag_title_color . '>' . $ag_3_title . '</span>' : '';
            $ag_31_field = ( strlen( $ag_31_field ) > 0 ) ? '<p' . $cl4_ag_txt_color . '>' . $ag_31_field . '</p>' : '';
            $ag_32_field = ( strlen( $ag_32_field ) > 0 ) ? '<p' . $cl4_ag_txt_color . '>' . $ag_32_field . '</p>' : '';
            $ag_33_field = ( strlen( $ag_33_field ) > 0 ) ? '<p' . $cl4_ag_txt_color . '>' . $ag_33_field . '</p>' : '';
            $ag_34_field = ( strlen( $ag_34_field ) > 0 ) ? '<p' . $cl4_ag_txt_color . '>' . $ag_34_field . '</p>' : '';
            $adr_group_3 = '
            <div class="col-sm-6 address-group">'
                . $ag_3_title
                . $ag_31_field
                . $ag_32_field
                . $ag_33_field
                . $ag_34_field .
            '</div>';
		if ( $contact_layout === 'contact_4' ) {
            $ag_3_title = ( strlen( $ag_3_title ) > 0 ) ? '<span class="adr-heading"' . $cl4_ag_title_color . '>' . $ag_3_title . '</span>' : '';
            $ag_31_field = ( strlen( $ag_31_field ) > 0 ) ? '<span class="adr-info"' . $cl4_ag_txt_color . '>' . $ag_31_field . '</span>' : '';
            $ag_32_field = ( strlen( $ag_32_field ) > 0 ) ? '<span class="adr-info"' . $cl4_ag_txt_color . '>' . $ag_32_field . '</span>' : '';
            $ag_33_field = ( strlen( $ag_33_field ) > 0 ) ? '<span class="adr-info"' . $cl4_ag_txt_color . '>' . $ag_33_field . '</span>' : '';
            $ag_34_field = ( strlen( $ag_34_field ) > 0 ) ? '<span class="adr-info"' . $cl4_ag_txt_color . '>' . $ag_34_field . '</span>' : '';
			$adr_group_3 = '
			<li class="contact-group"' . $cl4_ag_border_color . '>' 
                . $ag_3_title
                . $ag_31_field
                . $ag_32_field
                . $ag_33_field
                . $ag_34_field .
            '</li>';
		} elseif ( $contact_layout === 'contact_2' ) {
			$adr_group_3 = '
			<li>
				<span class="' . $ag_3_icon . ' adr-icon"' . $adr_c2_txt_style . '></span>
				<div class="adr-group">
					<span class="adr-heading"' . $adr_c2_txt_style . '>' . $ag_3_title . '</span>
					<span class="adr-info">' . $ag_31_field . '</span>
				</div>
			</li>'; 
		}
	}
	// Address group 4
	$adr_group_4 = '';
	if ( strlen( $ag_4_title ) > 0 || strlen( $ag_41_field ) > 0 || strlen( $ag_42_field ) > 0 || strlen( $ag_43_field ) > 0 || strlen( $ag_44_field ) > 0 ) {
            $ag_4_title = ( strlen( $ag_4_title ) > 0 ) ? '<span' . $cl4_ag_title_color . '>' . $ag_4_title . '</span>' : '';
            $ag_41_field = ( strlen( $ag_41_field ) > 0 ) ? '<p' . $cl4_ag_txt_color . '>' . $ag_41_field . '</p>' : '';
            $ag_42_field = ( strlen( $ag_42_field ) > 0 ) ? '<p' . $cl4_ag_txt_color . '>' . $ag_42_field . '</p>' : '';
            $ag_43_field = ( strlen( $ag_43_field ) > 0 ) ? '<p' . $cl4_ag_txt_color . '>' . $ag_43_field . '</p>' : '';
            $ag_44_field = ( strlen( $ag_44_field ) > 0 ) ? '<p' . $cl4_ag_txt_color . '>' . $ag_44_field . '</p>' : '';
            $adr_group_4 = '
            <div class="col-sm-6 address-group">'
                . $ag_4_title
                . $ag_41_field
                . $ag_42_field
                . $ag_43_field
                . $ag_44_field .
            '</div>';
		if ( $contact_layout === 'contact_4' ) {
            $ag_4_title = ( strlen( $ag_4_title ) > 0 ) ? '<span class="adr-heading"' . $cl4_ag_title_color . '>' . $ag_4_title . '</span>' : '';
            $ag_41_field = ( strlen( $ag_41_field ) > 0 ) ? '<span class="adr-info"' . $cl4_ag_txt_color . '>' . $ag_41_field . '</span>' : '';
            $ag_42_field = ( strlen( $ag_42_field ) > 0 ) ? '<span class="adr-info"' . $cl4_ag_txt_color . '>' . $ag_42_field . '</span>' : '';
            $ag_43_field = ( strlen( $ag_43_field ) > 0 ) ? '<span class="adr-info"' . $cl4_ag_txt_color . '>' . $ag_43_field . '</span>' : '';
            $ag_44_field = ( strlen( $ag_44_field ) > 0 ) ? '<span class="adr-info"' . $cl4_ag_txt_color . '>' . $ag_44_field . '</span>' : '';
			$adr_group_4 = '
			<li class="contact-group"' . $cl4_ag_border_color . '>' 
                . $ag_4_title
                . $ag_41_field
                . $ag_42_field
                . $ag_43_field
                . $ag_44_field .
            '</li>';
		}
	}


	// CF7
    $title_attr = '';
    $cf7 = '[contact-form-7 html_class="' . $cf_style . '" id="' . intval( $cf_id ) . '"' . $title_attr . ']';

    // Heading
    $cf_heading_el = '';
	if ( strlen( $cf_heading ) > 0 ) {
		$cf_heading_el .= '<h2>' . $cf_heading . '</h2>';
	}

	// Description
    $cf_info_el = '';
	if ( strlen( $cf_info ) > 0 ) {
		$cf_info_el .= '<p>' . $cf_info . '</p>';
	}

    // CL4 - CF title color
    $cl4_cf_heading_color = ( strlen( $cl4_cf_heading_color ) > 0 ) ? '  style="color: ' . $cl4_cf_heading_color . ';" ' : '';
    // CL4 - CF subtitle color
    $cl4_cf_subheading_color = ( strlen( $cl4_cf_subheading_color ) > 0 ) ? '  style="color: ' . $cl4_cf_subheading_color . ';" ' : '';

	// CL4 - CF title
    $cl_heading_sec = '';
    if ( strlen( $cf_heading ) > 0 || strlen( $cf_subheading ) > 0 ) {

    	$cf_subheading_el = '';
    	if ( strlen( $cf_subheading ) > 0 ) {
    		$cf_subheading_el .= '<span class="subheading" ' . $cl4_cf_subheading_color . '>' . $cf_subheading . '</span>';
    	}
    	
        $cl2_heading_sec = '';
    	$cl2_heading_sec .=	'
		<header class="sec-heading">
			<h2' . $cl4_cf_heading_color . '>' . $cf_heading . '</h2>
			'. $cf_subheading_el .'
		</header>';
    }

    // CL 4 (cf) spacing
    $cfh_top_gap_val = '';
	if ( strlen( $cfh_top_gap ) > 0 ) {
		$cfh_top_gap_val .= 'padding-top:' . intval( $cfh_top_gap ) . 'px;';
	}

	$cfh_bot_gap_val = '';
	if ( strlen( $cfh_bot_gap ) > 0 ) {
		$cfh_bot_gap_val .= 'padding-bottom:' . intval( $cfh_bot_gap ) . 'px;';
	}

    $cfh_gap_val = '';
    if ( strlen( $cfh_top_gap ) > 0 && strlen( $cfh_bot_gap ) > 0 ) {
    	$cfh_gap_val = 'style="' . $cfh_top_gap_val . ' ' . $cfh_bot_gap_val . '"';
    }


    // CF2 show map
    $cf2_gmap = '';
    if ( $cf2_show_map === '1' ) {
    	$cf2_gmap = '<div id="definity-gmap-' . $i . '" ' . $map_data . ' class="' . $map_classes . '"' . $map_styles . '></div>';
    }

	// Contact Layout
    $output = '';
    switch ( $contact_layout ) {

    	case 'contact_2':
    		$output .= '
    		<div class="contact-2 ' . $css_class . '">
    			' . $cf2_gmap . '
    			<div class="address-info"' . $adr_c2_bg_style . '>
    				<address>
						<ul>
							' . $adr_group_1 . '
							' . $adr_group_2 . '
							' . $adr_group_3 . '
						</ul>
					</address>
    			</div>
    		</div>';
    	break;

    	case 'contact_3':
        	$output .= '
			<div class="contact-3">
				<div class="col-md-12 col-lg-offset-2 col-lg-8">
					<div class="form-wrapper">
						<div class="from-header">
							' . $cf_heading_el . '
							' . $cf_info_el . '
						</div>
						' . do_shortcode( $cf7 ) . '
					</div>
				</div>
			</div>';
        break;
    	
        case 'contact_4':
        	$output .= '
			<div class="contact-4">
				<div class="vc_col-lg-6 no-gap contact-info">
					<a href="#" class="show-info-link"><i class="fa fa-info"></i>' . $show_map_btn . '</a>
					<div id="definity-gmap-' . $i . '" ' . $map_data . ' class="' . $map_classes . '"' . $map_styles . '></div>
					<address class="contact-info-wrapper"' . $cl4_bg_color . '>
						<ul>
							' . $adr_group_1 . '
							' . $adr_group_2 . '
						</ul>
						<ul>
							' . $adr_group_3 . '
							' . $adr_group_4 . '
						</ul>                  
						<a href="#" class="show-map"' . $cl4_map_btn_color . '><span class="linea-basic-geolocalize-05"></span>' . $show_info_btn . '</a>
					</address>
				</div>
				<div class="vc_col-lg-6 contact-form" ' . $cfh_gap_val . '>
					' . $cl2_heading_sec . '
					' . do_shortcode( $cf7 ) . '
				</div>
			</div>';
        break;
    	
    	default:
    		$output .= '
			<div class="contact-1">
				<div class="contact-wrapper">
					<div id="definity-gmap-' . $i . '" ' . $map_data . ' class="' . $map_classes . '"' . $map_styles . '></div>

					<div class="show-info-link">
						<a href="#" class="show-info"' . $cl4_bg_color . '><i class="fa fa-info"' . $cl4_map_btn_color . '></i><h6' . $cl4_map_btn_color . '>' . $show_map_btn . '</h6></a>
					</div>

					<div class="container">
						<div class="row">

							<div class="col-xs-offset-1 col-xs-11 col-md-offset-2 col-md-6 contact-info-wrapper"' . $cl4_bg_color . '>
								<address>
									<div class="row">
										' . $adr_group_1 . '
										' . $adr_group_2 . '
									</div>
									<div class="row">
										' . $adr_group_3 . '
										' . $adr_group_4 . '
									</div>
									<div class="row show-map-link">
										<a href="#" class="show-map"' . $cl4_map_btn_color . '><span class="et-map-pin"></span>' . $show_info_btn . '</a>
									</div>
								</address>
							</div>
						</div>
					</div>
				</div>
			</div>';
    	break;
    }		

	return $output;
} 
add_shortcode( 'd_contact', 'definity_contact_shortcode' );


/* --------------------------------------------------
	Dropcap
-------------------------------------------------- */

function definity_dropcaps_shortcode( $atts, $content = null ) {

    $output = '<p class="dropcaps">' . do_shortcode( $content ) . '</p>';
         
    return $output;
} 
add_shortcode( 'd_dropcap', 'definity_dropcaps_shortcode' );


/* --------------------------------------------------
	TinyMCE 	
-------------------------------------------------- */

function definity_tinyMCE_more_buttons($buttons) {
    array_push( $buttons, 'fontselect', 'fontsizeselect', 'styleselect' );
    return $buttons;
}

function definity_alt_h_styles_dropdown( $settings ) {

	$items = array( 
		array( 'title'	=> 'Alt H1', 'block' => 'h1', 'classes' => 'h-alt' ),
		array( 'title'	=> 'Alt H2', 'block' => 'h2', 'classes' => 'h-alt' ),
		array( 'title'	=> 'Alt H3', 'block' => 'h3', 'classes' => 'h-alt' ),
		array( 'title'	=> 'Alt H4', 'block' => 'h4', 'classes' => 'h-alt' ),
		array( 'title'	=> 'Alt H5', 'block' => 'h5', 'classes' => 'h-alt' ),
		array( 'title'	=> 'Alt H6', 'block' => 'h6', 'classes' => 'h-alt' ),
	);

	$new_styles = array(
		array(
			'title'	=> esc_html__( 'Alt Headings', 'definity' ),
			'items'	=> $items
		),
	);

	$settings['style_formats_merge'] = true;
	$settings['style_formats'] = json_encode( $new_styles );
	return $settings;

}
add_filter( 'tiny_mce_before_init', 'definity_alt_h_styles_dropdown' );


function definity_register_tinymce_plugins($buttons) { 
	array_push(
		$buttons,
		'd_dropcap',
		'table'
	);  
	return $buttons;  
}

function definity_add_tinymce_plugins($plugin_array) {
	$plugin_array['d_dropcap']  = plugin_dir_url( __FILE__ ) . '/tinymce/plugins.js';
	$plugin_array['table']   	= plugin_dir_url( __FILE__ ) . '/tinymce/table.min.js';
   return $plugin_array;
}

function definity_add_tinymce_button() { 
	if( ! current_user_can( 'edit_posts' ) && ! current_user_can( 'edit_pages' ) ) {return;}
	if ( get_user_option( 'rich_editing' ) == 'true' ) {
		add_filter( 'mce_external_plugins', 'definity_add_tinymce_plugins' );
		add_filter( 'mce_buttons', 'definity_register_tinymce_plugins' );
		add_filter( 'mce_buttons_2', 'definity_tinyMCE_more_buttons' );
	}
}
add_action( 'admin_head', 'definity_add_tinymce_button' );


/* --------------------------------------------------
    Animation Wrapper
-------------------------------------------------- */

function definity_animation_wrapper_shortcode( $atts, $content = null ) {

    extract(
        shortcode_atts(
            array(
                'anim_type'     => '',
                'anim_distance' => '',
                'anim_duration' => '',
                'anim_delay'    => '',
                'anim_offset'   => '',
                'anim_iteration'=> '',
                'anim_infinite' => '',
            ), 
            $atts
        )
    );

    // Animations
    $anim_class = '';
    if ( strlen( $anim_type ) > 0 ) {
        $anim_class = $anim_type . $anim_distance;

        if ( $anim_infinite == 'enable' ) {
            $anim_infinite_class = ' infinite';
            $anim_class = $anim_type . $anim_distance . $anim_infinite_class;
        }
    }
    $anim_atts = '';
    if ( strlen( $anim_duration ) > 0 ) {
        $anim_duration_attr = ' data-wow-duration="' . floatval( $anim_duration ) . 's"';
        $anim_delay_attr = ' data-wow-delay="' . floatval( $anim_delay ) . 's"';

        $anim_offset_attr = '';
        if ( strlen( $anim_offset ) > 0 ) {
            $anim_offset_attr = ' data-wow-offset="' . intval( $anim_offset ) . '"';
        }
        $anim_iteration_attr = '';
        if ( strlen( $anim_iteration ) > 0 ) {
            $anim_iteration_attr = ' data-wow-iteration="' . intval( $anim_iteration ) . '"';
        }
        $anim_atts = $anim_duration_attr . $anim_delay_attr . $anim_offset_attr . $anim_iteration_attr;
    }

    $output = '
        <div class="wow ' . $anim_class . '" ' . $anim_atts . '>'
            . do_shortcode( $content ) . 
        '</div>';

    return $output;
}
add_shortcode( 'd_animation_wrapper', 'definity_animation_wrapper_shortcode' );


/* --------------------------------------------------
    Portfolio (custom post type)
-------------------------------------------------- */
if ( is_plugin_active( 'definity-portfolio/definity-portfolio.php' ) ) {
    function definity_pfolio_cpt_shortcode( $atts, $content = NULL ) {
         
        extract(
            shortcode_atts(
                array(
                    'posts_number'      => '6',
                    'post_name'         => '',
                    'post_filters'      => '',
                    'post_category'     => '',
                    'filters_on'        => '',
                    'filter_all_txt'    => 'All',
                    'filter_spacing'    => '',
                    'portfolio_style'   => '',
                    'grid'              => 'col-md-4',
                    'css_class'         => '',
                ), 
                $atts
            )
        );

        global $post;
        $args = array(
            'post_type'           => 'portfolio',
            'posts_per_page'      => absint( $posts_number ),
            'name'                => $post_name,
            'filters'             => $post_filters,
            'categories'          => $post_category,
            'post_status'         => 'publish',
            'ignore_sticky_posts' => true
        );
        $portfolio_cpt_query = new WP_Query( $args );

        $output = '';
        if ( $portfolio_cpt_query->have_posts() ) {

            // Grid
            switch ( $grid ) {
                case 'col-md-3':
                    $grid_layout = $grid;
                break;

                case 'col-md-6':
                    $grid_layout = $grid;
                break;

                case 'col-md-12':
                    $grid_layout = $grid;
                break;
                
                default: // col-md-4
                    $grid_layout = $grid;
                break;
            }

            // Filters
            if ( $filters_on == '1' ) {
                $terms = get_terms( array( 
                    'taxonomy' => 'filters',
                    'parent'   => 0
                ) );
                
                $filter_spacing_el = '';            
                if ( ! empty( $filter_spacing ) ) {
                    $filter_spacing_el = ' style="margin-bottom:' . intval( $filter_spacing ) . 'px;"';
                }

                if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
                    $output .= '<ul id="pfolio-cpt-filters" class="portfolio-filters"' . $filter_spacing_el . '>';
                    $output .= '<li class="active"><a href="#" data-filter="*">';
                    $output .= $filter_all_txt;
                    $output .= '</a></li>';
                    foreach ( $terms as $term ) {
                         $output .= '<li><a href="#" data-filter=".filters-' . $term->name . '">' . $term->name . '</a></li>';
                    }
                    $output .= '</ul>';
                }
            }
            
            // Portfolio items
            $output .= '<div id="pfolio-cpt" class="portfolio-columns-fw ' . $css_class . '">';

                // The loop
                while( $portfolio_cpt_query->have_posts() ) {
                    $portfolio_cpt_query->the_post();
                    
                    // Open Button
                    if ( get_field( 'lightbox_on' ) == 'Lightbox' ) {
                       $open_btn = '
                        <a class="open-btn open-gallery" href="' . get_the_post_thumbnail_url() . '">
                            <i class="fa fa-expand"></i>
                        </a>';

                        $open_link = '
                        <a class="post-img open-gallery" href="' . get_the_post_thumbnail_url() . '">
                            ' . get_the_post_thumbnail() . '
                        </a>';
                    } elseif ( get_field( 'lightbox_on' ) == 'Lightbox Video' ) {
                        $open_btn = '
                         <a class="open-btn popup-video" href="' . get_field( 'video_url' ) . '">
                            <i class="fa fa-play"></i>
                         </a>';

                         $open_link = '
                         <a class="popup-video" href="' . get_field( 'video_url' ) . '">
                            <span class="linea-music-play-button"></span>
                         </a>
                         ' . get_the_post_thumbnail();
                    } else {
                        $open_btn = '
                         <a class="open-btn" href="' . get_the_permalink() . '">
                             <i class="fa fa-expand"></i>
                         </a>';

                         $open_link = '
                         <a class="post-img" href="' . get_the_permalink() . '">
                             ' . get_the_post_thumbnail() . '
                         </a>';
                    } // endif

                    // Gallery Button (hover bottom, hover side)
                    if ( get_field( 'lightbox_on' ) == 'Lightbox Video' ) {
                        $gallery_btn = '
                        <li><a class="popup-video" href="' . get_field( 'video_url' ) . '"><i class="fa fa-play"></i></a></li>';

                        $gallery_btn_2 = '<li><a href="' . get_field( 'video_url' ) . '" class="open-gallery popup-video"><span class="linea-music-play-button"></span></a></li>';
                    } else {
                        $gallery_btn = '<li><a class="open-gallery" href="' . get_the_post_thumbnail_url() . '"><i class="fa fa-arrows-alt"></i></a></li>';

                        $gallery_btn_2 = '<li><a href="' . get_the_post_thumbnail_url() . '" class="open-gallery"><span class="linea-arrows-expand"></span></a></li>';
                    } // endif
                    
                    // Portfolio Style
                    switch ( $portfolio_style ) {
                        case 'pfolio-simple':
                            $post_class = get_post_class( array( 'pfolio-cpt-item portfolio-simple hover-simple', $grid_layout ) );
                            $output .= '
                            <div class="' . implode( ' ',$post_class ) . '">
                                <figure>
                                    <div class="img-wrapper">
                                        ' . $open_link . '
                                    </div>
                                    <figcaption>
                                        <h5 class="p-title">' . get_the_title() . '</h5>
                                        <p class="p-subtitle">' . get_field( 'subtitle' ) . '</p>
                                    </figcaption>
                                </figure>
                            </div>';
                        break;

                        case 'pfolio-side pfolio-light':
                            $post_class = get_post_class( array( 'hover-side hover-light pfolio-cpt-item portfolio-item', $grid_layout ) );
                            $output .= '
                            <div class="' . implode( ' ', $post_class ) . '">
                                <figure>
                                    ' . get_the_post_thumbnail() . '
                                    <figcaption>
                                        <h5 class="hover-heading">' . get_the_title() . '</h5>
                                        <p class="hover-text">' . get_field( 'subtitle' ) . '</p>
                                        <a class="hover-more-btn" href="' . get_the_permalink() . '"><span class="linea-arrows-slim-right"></span></a>
                                        <ul class="hover-btns">
                                            ' . $gallery_btn_2 . '
                                        </ul>
                                    </figcaption>
                                </figure>
                            </div>';
                        break;

                        case 'pfolio-side':
                            $post_class = get_post_class( array( 'hover-side pfolio-cpt-item portfolio-item', $grid_layout ) );
                            $output .= '
                            <div class="' . implode( ' ', $post_class ) . '">
                                <figure>
                                    ' . get_the_post_thumbnail() . '
                                    <figcaption>
                                        <h5 class="hover-heading">' . get_the_title() . '</h5>
                                        <p class="hover-text">' . get_field( 'subtitle' ) . '</p>
                                        <a class="hover-more-btn" href="' . get_the_permalink() . '"><span class="linea-arrows-slim-right"></span></a>
                                        <ul class="hover-btns">
                                            ' . $gallery_btn_2 . '
                                        </ul>
                                    </figcaption>
                                </figure>
                            </div>';
                        break;

                        case 'pfolio-bottom pfolio-light':
                            $post_class = get_post_class( array( 'hover-bottom hover-light pfolio-cpt-item portfolio-item', $grid_layout ) );
                            $output .= '
                            <div class="' . implode( ' ', $post_class ) . '">
                                <figure>
                                    ' . get_the_post_thumbnail() . '
                                    <figcaption>
                                        <h4 class="hover-heading">' . get_the_title() . '</h4>
                                        <ul class="hover-btns">
                                            <li><a href="' . get_the_permalink() . '"><i class="fa fa-share"></i></a></li>
                                            ' . $gallery_btn . '
                                        </ul>
                                    </figcaption>
                                </figure>
                            </div>';
                        break;

                        case 'pfolio-bottom':
                            $post_class = get_post_class( array( 'hover-bottom pfolio-cpt-item portfolio-item', $grid_layout ) );
                            $output .= '
                            <div class="' . implode( ' ', $post_class ) . '">
                                <figure>
                                    ' . get_the_post_thumbnail() . '
                                    <figcaption>
                                        <h4 class="hover-heading">' . get_the_title() . '</h4>
                                        <ul class="hover-btns">
                                            <li><a href="' . get_the_permalink() . '"><i class="fa fa-share"></i></a></li>
                                            ' . $gallery_btn . '
                                        </ul>
                                    </figcaption>
                                </figure>
                            </div>';
                        break;

                        case 'pfolio-light':
                            $post_class = get_post_class( array( 'pfolio-cpt-item portfolio-item', $grid_layout ) );
                            $output .= '
                            <div class="' . implode( ' ', $post_class ) . '">
                                <div class="p-wrapper hover-light">
                                    ' . get_the_post_thumbnail() . '
                                    <div class="p-hover">
                                        <div class="p-content">
                                            <h4>' . get_the_title() . '</h4>
                                            <h6 class="subheading">' . get_field( 'subtitle' ) . '</h6>
                                        </div>
                                    </div>
                                    ' . $open_btn . '
                                </div>
                            </div>';
                        break;
                        
                        default:
                            $post_class = get_post_class( array( 'pfolio-cpt-item portfolio-item', $grid_layout ) );
                            $output .= '
                            <div class="' . implode( ' ', $post_class ) . '">
                                <div class="p-wrapper hover-default">
                                    ' . get_the_post_thumbnail() . '
                                    <div class="p-hover">
                                        <div class="p-content">
                                            <h4>' . get_the_title() . '</h4>
                                            <h6 class="subheading">' . get_field( 'subtitle' ) . '</h6>
                                        </div>
                                    </div>
                                    ' . $open_btn . '
                                </div>
                            </div>';
                        break;
                    } // end switch
                    
                } // end while
            $output .= '</div>';

            wp_reset_postdata();
        }
        return $output;
    } 
    add_shortcode( 'd_pfolio_cpt', 'definity_pfolio_cpt_shortcode' );
}


/* --------------------------------------------------
    Masonry Portfolio (custom post type)
-------------------------------------------------- */
if ( is_plugin_active( 'definity-portfolio/definity-portfolio.php' ) ) {
    function definity_pfolio_masonry_cpt_shortcode( $atts, $content = NULL ) {
         
        extract(
            shortcode_atts(
                array(
                    'posts_number'      => '6',
                    'post_name'         => '',
                    'post_filters'      => '',
                    'post_category'     => '',
                    'filters_on'        => '',
                    'filter_all_txt'    => 'All',
                    'filter_spacing'    => '',
                    'masonry_layout'    => 'portfolio-masonry-3',
                    'hover_effect'      => 'hover-default',
                    'css_class'         => '',
                ), 
                $atts
            )
        );

        global $post;
        $args = array(
            'post_type'           => 'portfolio',
            'posts_per_page'      => absint( $posts_number ),
            'name'                => $post_name,
            'filters'             => $post_filters,
            'categories'          => $post_category,
            'post_status'         => 'publish',
            'ignore_sticky_posts' => true
        );
        $masonry_portfolio_cpt_query = new WP_Query( $args );    

        $output = '';
        if ( $masonry_portfolio_cpt_query->have_posts() ) {

            // Filters
            if ( $filters_on == '1' ) {
                $terms = get_terms( array( 
                    'taxonomy' => 'filters',
                    'parent'   => 0
                ) );
                
                $filter_spacing_el = '';            
                if ( ! empty( $filter_spacing ) ) {
                    $filter_spacing_el = ' style="margin-bottom:' . intval( $filter_spacing ) . 'px;"';
                }

                if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
                    $output .= '<ul id="pfolio-filters" class="portfolio-filters"' . $filter_spacing_el . '>';
                    $output .= '<li class="active"><a href="#" data-filter="*">';
                    $output .= $filter_all_txt;
                    $output .= '</a></li>';
                    foreach ( $terms as $term ) {
                         $output .= '<li><a href="#" data-filter=".filters-' . $term->name . '">' . $term->name . '</a></li>';
                    }
                    $output .= '</ul>';
                }
            }
            
            // Portfolio items
            $output .= '
            <div class="portfolio-layout ' . $masonry_layout . ' ' . $css_class . '">
                <div class="pfolio-items">
                    <div class="grid-sizer"></div>';

                // The loop
                while( $masonry_portfolio_cpt_query->have_posts() ) {
                    $masonry_portfolio_cpt_query->the_post();

                    if ( get_field( 'lightbox_on' ) == 'Lightbox' ) {
                        $open_btn = '
                         <a class="open-btn open-gallery" href="' . get_the_post_thumbnail_url() . '">
                            <i class="fa fa-expand"></i>
                         </a>';
                    } elseif ( get_field( 'lightbox_on' ) == 'Lightbox Video' ) {
                         $open_btn = '
                         <a class="open-btn popup-video" href="' . get_field( 'video_url' ) . '">
                            <i class="fa fa-play"></i>
                         </a>';
                    } else {
                        $open_btn = '
                        <a class="open-btn" href="' . get_the_permalink() . '">
                            <i class="fa fa-expand"></i>
                        </a>';
                    }
                    
                    $post_class = get_post_class( array( 'p-item' ) );
                    $output .= '
                    <div class="' . implode( ' ',$post_class ) . '">
                        <div class="p-wrapper ' . $hover_effect . '">
                            ' . get_the_post_thumbnail() . '
                            <div class="p-hover">
                                <div class="p-content">
                                    <h4>' . get_the_title() . '</h4>
                                    <h6 class="subheading">' . get_field( 'subtitle' ) . '</h6>
                                </div>
                            </div>
                            ' . $open_btn . '
                        </div>
                    </div>';
                    
                } // end while
            $output .= '
                </div>
            </div>';

            wp_reset_postdata();
        }
        return $output;
    } 
    add_shortcode( 'd_pfolio_masonry_cpt', 'definity_pfolio_masonry_cpt_shortcode' );
}